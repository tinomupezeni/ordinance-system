
from django.contrib.auth.models import User
from django.db import models



# =========== Setting Up the User Profile ===========




# Create your models here.
class Userprofile(models.Model):

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    rank= models.CharField(max_length=100)
    last_active = models.DateTimeField(auto_now=True)
    office = models.CharField(max_length=100)

    province = models.CharField(max_length=100)
    station = models.CharField(max_length=100)


    def __str__(self):
        return  self.rank
    




class RequisitionForm(models.Model):
    EXPENSE_TYPE_CHOICES = [
        ('GOVERNMENT', 'Government expense'),
        ('MEMBER', "Member's expense"),
    ]
    
    DISPATCH_METHOD_CHOICES = [
        ('CALLED FOR', 'Called For'),
        ('DESPATCHED', 'Despatched'),
    ]
    
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Basic Information
    ordinance_control_no = models.CharField(max_length=100)
    station = models.CharField(max_length=100)
    branch = models.CharField(max_length=100)
    dispatch_method = models.CharField(max_length=20, choices=DISPATCH_METHOD_CHOICES, default='CALLED FOR')
    date = models.DateField()
    
    # Collected By
    collected_by_no = models.CharField(max_length=50)
    collected_by_rank = models.CharField(max_length=50)
    collected_by_name = models.CharField(max_length=100)
    
    # Officer Recommendations
    officer_recommendation_at = models.CharField(max_length=100)
    officer_recommendation_rank = models.CharField(max_length=50)
    officer_recommendation_expense_type = models.CharField(
        max_length=20, 
        choices=EXPENSE_TYPE_CHOICES, 
        default='GOVERNMENT'
    )
    
    # Checked By
    checked_by_officer_no = models.CharField(max_length=50)
    checked_by_officer_rank = models.CharField(max_length=50)
    checked_by_quartermaster_no = models.CharField(max_length=50)
    checked_by_quartermaster_rank = models.CharField(max_length=50)
    
    # Initials and Dates
    voucher_checked_by_initials = models.CharField(max_length=10)
    voucher_checked_by_date = models.DateField()
    items_selected_by_initials = models.CharField(max_length=10)
    items_selected_by_date = models.DateField()
    items_packed_by_initials = models.CharField(max_length=10)
    items_packed_by_date = models.DateField()
    entered_on_clothing_card_initials = models.CharField(max_length=10)
    entered_on_clothing_card_date = models.DateField()
    ledger_actioned_initials = models.CharField(max_length=10)
    ledger_actioned_date = models.DateField()
    
    # Dispatch Method Details
    dispatch_collected = models.BooleanField(default=False)
    dispatch_rail = models.BooleanField(default=False)
    dispatch_road = models.BooleanField(default=False)
    dispatch_air = models.BooleanField(default=False)
    dispatch_registered_mail = models.BooleanField(default=False)
    dispatch_parcel_post = models.BooleanField(default=False)
    dispatch_parcel_warrant_no = models.CharField(max_length=100, blank=True)
    AUTHORIZATION_STATUS = [
        ('awaiting', 'Awaiting Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    office_in_charge_status = models.CharField(
        max_length=50,
        choices=AUTHORIZATION_STATUS,
        default='awaiting',
    )
    carding_status = models.CharField(
        max_length=10,
        choices=AUTHORIZATION_STATUS,
        default='awaiting',
    )
    OFFICE_FORM_TYPES = [
        ('individual', 'Individual'),
        ('loans', 'Loans'),
        ('stock', 'Stock Transfer')
    ]
    formType = models.CharField(
        max_length=50,
        choices=OFFICE_FORM_TYPES,
        default='individual',
    )
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Requisition Form {self.ordinance_control_no}"

class RequisitionItem(models.Model):
    form = models.ForeignKey(RequisitionForm, related_name='items', on_delete=models.CASCADE)
    force_no = models.CharField(max_length=50)
    rank = models.CharField(max_length=50)
    name = models.CharField(max_length=100)
    article = models.CharField(max_length=100)
    size = models.CharField(max_length=50)
    regd_no = models.CharField(max_length=50)
    date_due = models.DateField()
    issued = models.CharField(max_length=50)
    signature = models.CharField(max_length=100)
    life = models.CharField(max_length=50, blank=True)
    reason = models.CharField(max_length=255, blank=True)
    
    
    def __str__(self):
        return f"{self.force_no} - {self.article}"

class ReplacementItem(models.Model):
    form = models.ForeignKey(RequisitionForm, related_name='replacement_items', on_delete=models.CASCADE)
    force_no = models.CharField(max_length=50)
    life = models.CharField(max_length=50, blank=True)
    date_due = models.DateField()
    issued = models.CharField(max_length=50)
    reason = models.CharField(max_length=255, blank=True)
    
    def __str__(self):
        return f"Replacement for {self.force_no}"
    

    # ---------------------------------
    # Form109
    # ---------------------------------

# models.py
from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Form109ReceiptItem(models.Model):
    description = models.CharField(max_length=255)
    size = models.CharField(max_length=100, blank=True)
    number = models.CharField(max_length=100, blank=True)
    no_taken = models.CharField(max_length=100, blank=True)
    number_received = models.CharField(max_length=100, blank=True)
    number_rejected = models.CharField(max_length=100, blank=True)
    

    received = models.BooleanField(default=False)
    rejected = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Form 109 Receipt Item"
        verbose_name_plural = "Form 109 Receipt Items"

    def __str__(self):
        return self.description

class Form109(models.Model):
    received_from = models.CharField(max_length=255)
    ordinance_voucher_no = models.CharField(max_length=100)
    gcs_reqn_no = models.CharField(max_length=100, blank=True)
    supplier_ref_no = models.CharField(max_length=100, blank=True)
    STOCK_TYPE_CHOICES = [
        ('bulk_stock', 'Bulk Stock'),
        ('made_to_measure', 'Made-to-Measure'),
    ]
    stock_type = models.CharField(
        max_length=100,
        choices=STOCK_TYPE_CHOICES,
        default='bulk_stock',
        verbose_name="Stock Type"
    )
    
    items = models.ManyToManyField(Form109ReceiptItem)
    
    received_by_signature = models.CharField(max_length=255)
    received_by_date = models.DateField()
    
    ledger_actioned_by_signature = models.CharField(max_length=255)
    ledger_actioned_by_date = models.DateField()
    
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='form109_created')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Form 109 - Ordnance Store Receipt Voucher"
        verbose_name_plural = "Form 109 - Ordnance Store Receipt Vouchers"
        ordering = ['-created_at']

    def __str__(self):
        return f"Form 109 - {self.ordinance_voucher_no} - {self.received_from}"    

# ---------------------------------
# Form321
# ---------------------------------



class Form321(models.Model):
    CONDITION_CHOICES = [
        ('new', 'New'),
        ('part_worn', 'Part Worn'),
        ('old', 'Old'),
    ]
    
    AGREEMENT_CHOICES = [
        ('agree', 'Agree'),
        ('do_not_agree', 'Do Not Agree'),
    ]
    
    NEGLIGENCE_CHOICES = [
        ('believe', 'Believe'),
        ('do_not_believe', 'Do Not Believe'),
    ]
    
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Header Info
    report_no = models.CharField(max_length=100)
    province = models.CharField(max_length=100)
    station = models.CharField(max_length=100)
    
    # Part I
    condition = models.CharField(max_length=20, choices=CONDITION_CHOICES, default='new')
    date_of_issue = models.DateField()
    date_of_loss = models.DateField()
    circumstances = models.TextField()
    agree_to_refund = models.CharField(max_length=20, choices=AGREEMENT_CHOICES, default='agree')
    
    # Part II
    officer_comment = models.TextField(blank=True)
    
    # Part III
    negligence = models.CharField(max_length=20, choices=NEGLIGENCE_CHOICES, default='believe')
    await_date = models.DateField(null=True, blank=True)
    government_pay_amount = models.CharField(max_length=100, blank=True)
    
    # Part IV
    depreciated_value = models.CharField(max_length=100, blank=True)
    
    # Part V
    government_pay_percentage = models.CharField(max_length=100, blank=True)
    member_pay_percentage = models.CharField(max_length=100, blank=True)
    
    # Part VII
    board_of_enquiry_received = models.BooleanField(default=False)
    home_affairs_advised = models.BooleanField(default=False)
    equipment_recovered = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Form 321"
        verbose_name_plural = "Form 321 Reports"
    
    def __str__(self):
        return f"Form 321 - {self.report_no}"

class EquipmentItem(models.Model):
    form = models.ForeignKey(Form321, related_name='equipment_items', on_delete=models.CASCADE)
    description = models.CharField(max_length=255)
    number = models.CharField(max_length=100)
    value = models.CharField(max_length=100)
    
    class Meta:
        ordering = ['id']
    
    def __str__(self):
        return f"{self.description} - {self.number}"

class PersonInvolved(models.Model):
    form = models.ForeignKey(Form321, related_name='persons_involved', on_delete=models.CASCADE)
    no = models.CharField(max_length=50)
    rank = models.CharField(max_length=50)
    name = models.CharField(max_length=100)
    home_station = models.CharField(max_length=100)
    
    class Meta:
        ordering = ['id']
    
    def __str__(self):
        return f"{self.rank} {self.name}"
    

    # --------------------------------------
    # 
    # --------------------------------------

    




class Form163(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Form 163"
        verbose_name_plural = "Form 163 Requisitions"

    def __str__(self):
        return f"Form 163 - {self.id}"

class RequisitionItem163(models.Model):
    form = models.ForeignKey(Form163, related_name='items', on_delete=models.CASCADE)
    description = models.CharField(max_length=255)
    size = models.CharField(max_length=100)
    no_regd = models.CharField(max_length=100)
    no_issued = models.CharField(max_length=100)

    class Meta:
        ordering = ['id']

    def __str__(self):
        return f"{self.description} - {self.size}"

class FormSignature(models.Model):
    form = models.OneToOneField(Form163, on_delete=models.CASCADE)
    requested_by_initials = models.CharField(max_length=10)
    requested_by_date = models.DateField()
    issued_by_initials = models.CharField(max_length=10)
    issued_by_date = models.DateField()
    received_by_initials = models.CharField(max_length=10)
    received_by_date = models.DateField()
    ledger_actioned_by_initials = models.CharField(max_length=10)
    ledger_actioned_by_date = models.DateField()

    def __str__(self):
        return f"Signatures for Form 163 - {self.form.id}"
    


    # --------------------------------------
    # Rejection Certificate
    # --------------------------------------

    




class RejectionCertificate(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Header Information
    entry_no = models.CharField(max_length=50)
    certificate_no = models.CharField(max_length=50)
    
    # Inspector Information
    inspector_number = models.CharField(max_length=50)
    inspector_rank = models.CharField(max_length=50)
    inspector_name = models.CharField(max_length=100)
    
    # Supplier Information
    supplier = models.CharField(max_length=255, blank=True)
    
    # Rejection Details
    rejection_reason = models.TextField(blank=True)
    all_accepted = models.BooleanField(default=False)
    all_rejected = models.BooleanField(default=False)
    
    # Inspector Qualification
    qualification = models.CharField(max_length=255, blank=True)
    years_served = models.CharField(max_length=50, blank=True)
    
    # Signature Section
    signature = models.CharField(max_length=100)
    date = models.DateField()
    
    # Witness Information
    witness_f_number = models.CharField(max_length=50)
    witness_rank = models.CharField(max_length=50)
    witness_name = models.CharField(max_length=100)
    witness_office_held = models.CharField(max_length=100)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Rejection Certificate"
        verbose_name_plural = "Rejection Certificates"
    
    def __str__(self):
        return f"Rejection Certificate {self.certificate_no}"

class RejectedItem(models.Model):
    certificate = models.ForeignKey(RejectionCertificate, related_name='items', on_delete=models.CASCADE)
    item = models.CharField(max_length=255)
    quantity = models.CharField(max_length=50)
    delivery_note = models.CharField(max_length=100)
    order_no = models.CharField(max_length=100)
    rejected = models.CharField(max_length=100, blank=True)
    accepted = models.CharField(max_length=100, blank=True)
    value = models.CharField(max_length=100)
    
    class Meta:
        ordering = ['id']
    
    def __str__(self):
        return f"{self.item} - {self.quantity}"
    
    # --------------------------------------
    # Book 2 Issue Voucher
    # --------------------------------------






class Book2IssueVoucher(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Header Information
    issued_by = models.CharField(max_length=255)
    issued_to = models.CharField(max_length=255)
    dispatch_method = models.CharField(max_length=100)
    
    # Recipient Information
    received_by_signature = models.CharField(max_length=100)
    received_date = models.DateField()
    recipient_no = models.CharField(max_length=50)
    recipient_rank = models.CharField(max_length=50)
    recipient_name = models.CharField(max_length=100)
    recipient_station = models.CharField(max_length=100)
    
    # Certification
    certified_by = models.CharField(max_length=100)
    certified_date = models.DateField()
    
    # Voucher Numbers
    iv_no = models.CharField(max_length=50)
    iv_date = models.DateField()
    reqn_no = models.CharField(max_length=50)
    reqn_date = models.DateField()
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Book 2 Issue Voucher"
        verbose_name_plural = "Book 2 Issue Vouchers"
    
    def __str__(self):
        return f"Book 2 Issue Voucher {self.iv_no}"

class IssueItem(models.Model):
    voucher = models.ForeignKey(Book2IssueVoucher, related_name='items', on_delete=models.CASCADE)
    description = models.CharField(max_length=255)
    quantity = models.CharField(max_length=50)
    remarks = models.CharField(max_length=255, blank=True)
    
    class Meta:
        ordering = ['id']
    
    def __str__(self):
        return f"{self.description} - {self.quantity}"    


        # --------------------------------------
        # Exchange Voucher
        # --------------------------------------






class ExchangeVoucher(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE , null= True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Signatures
    returned_by_initials = models.CharField(max_length=10)
    returned_by_date = models.DateField()
    ledger_actioned_by_initials = models.CharField(max_length=10)
    ledger_actioned_by_date = models.DateField()

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Exchange Voucher"
        verbose_name_plural = "Exchange Vouchers"

    def __str__(self):
        return f"Exchange Voucher #{self.id}"

class ExchangeItem(models.Model):
    voucher = models.ForeignKey(ExchangeVoucher, related_name='items', on_delete=models.CASCADE)
    returned_description = models.CharField(max_length=255)
    returned_size = models.CharField(max_length=50)
    returned_no = models.CharField(max_length=50)
    issued_description = models.CharField(max_length=255)
    issued_size = models.CharField(max_length=50)
    issued_no = models.CharField(max_length=50)

    class Meta:
        ordering = ['id']

    def __str__(self):
        return f"{self.returned_description} -> {self.issued_description}"


# --------------------------------------
# Form 226
# --------------------------------------
# from django.db import models
# from django.core.validators import MinValueValidator, MaxValueValidator

# class Form226(models.Model):
#     EXPENSE_TYPE_CHOICES = [
#         ('GOVERNMENT', 'Government'),
#         ('MEMBER', 'Member'),
#     ]
    
#     DISPATCH_METHOD_CHOICES = [
#         ('CALLED_FOR', 'Called For'),
#         ('DESPATCHED', 'Despatched'),
#     ]
    
#     ordinance_control_no = models.CharField(max_length=100)
#     station = models.CharField(max_length=100)
#     branch = models.CharField(max_length=100)
#     dispatch_method = models.CharField(max_length=20, choices=DISPATCH_METHOD_CHOICES)
#     date = models.DateField()
    
#     # Collected By fields
#     collected_by_no = models.CharField(max_length=50)
#     collected_by_rank = models.CharField(max_length=50)
#     collected_by_name = models.CharField(max_length=100)
    
#     # Officer Recommendation fields
#     officer_recommendation_at = models.CharField(max_length=100)
#     officer_recommendation_rank = models.CharField(max_length=50)
#     officer_recommendation_expense_type = models.CharField(
#         max_length=20, 
#         choices=EXPENSE_TYPE_CHOICES,
#         default='GOVERNMENT'
#     )
    
#     # Checked By fields
#     checked_by_officer_no = models.CharField(max_length=50)
#     checked_by_officer_rank = models.CharField(max_length=50)
#     checked_by_quartermaster_no = models.CharField(max_length=50)
#     checked_by_quartermaster_rank = models.CharField(max_length=50)
    
#     # Dispatch Method Details
#     dispatch_collected = models.BooleanField(default=False)
#     dispatch_rail = models.BooleanField(default=False)
#     dispatch_road = models.BooleanField(default=False)
#     dispatch_air = models.BooleanField(default=False)
#     dispatch_registered_mail = models.BooleanField(default=False)
#     dispatch_parcel_post = models.BooleanField(default=False)
#     dispatch_parcel_warrant_no = models.CharField(max_length=100, blank=True)
    
#     # Initials and Dates
#     voucher_checked_by_initials = models.CharField(max_length=10)
#     voucher_checked_by_date = models.DateField()
#     items_selected_by_initials = models.CharField(max_length=10)
#     items_selected_by_date = models.DateField()
#     items_packed_by_initials = models.CharField(max_length=10)
#     items_packed_by_date = models.DateField()
#     entered_on_clothing_card_initials = models.CharField(max_length=10)
#     entered_on_clothing_card_date = models.DateField()
#     ledger_actioned_initials = models.CharField(max_length=10)
#     ledger_actioned_date = models.DateField()
    
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)
    
#     def __str__(self):
#         return f"Form226 - {self.ordinance_control_no}"

# class RequisitionItem226(models.Model):
#     form = models.ForeignKey(Form226, related_name='items', on_delete=models.CASCADE)
#     force_no = models.CharField(max_length=50)
#     rank = models.CharField(max_length=50)
#     name = models.CharField(max_length=100)
#     article = models.CharField(max_length=100)
#     size = models.CharField(max_length=50)
#     regd_no = models.CharField(max_length=50)
#     date_due = models.DateField()
#     issued = models.CharField(max_length=50)
#     signature = models.CharField(max_length=100)
#     life = models.CharField(max_length=100, blank=True)
#     reason = models.CharField(max_length=255, blank=True)
    
#     def __str__(self):
#         return f"{self.article} for {self.name}"

# class ReplacementItem(models.Model):
#     form = models.ForeignKey(Form226, related_name='replacement_items', on_delete=models.CASCADE)
#     force_no = models.CharField(max_length=50)
#     date_due = models.DateField()
#     issued = models.CharField(max_length=50)
#     life = models.CharField(max_length=100, blank=True)
#     reason = models.CharField(max_length=255, blank=True)
    
#     def __str__(self):
#         return f"Replacement for {self.force_no}"


# --------------------------------------
# Discharge Certificate
# --------------------------------------






class DischargeCertificate(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Member Information
    member_no = models.CharField(max_length=50)
    member_rank = models.CharField(max_length=50)
    member_name = models.CharField(max_length=100)
    member_station = models.CharField(max_length=100)
    
    # Discharge Information
    discharge_reasons = models.TextField()
    discharge_date = models.DateField()
    
    # Repayment Information
    repayment_ic_date = models.CharField(max_length=50)
    repayment_iv = models.CharField(max_length=50)
    repayment_iv_date = models.DateField()
    repayment_acv_confirmed = models.BooleanField(default=False)
    repayment_total = models.CharField(max_length=50)
    repayment_no_outstanding = models.BooleanField(default=False)
    
    # Kit Deficiencies
    kit_articles_listed = models.CharField(max_length=255, blank=True)
    kit_date = models.DateField(null=True, blank=True)
    kit_sum = models.CharField(max_length=50, blank=True)
    kit_no_deficiencies = models.BooleanField(default=False)
    
    # Summary
    summary_kit_repayment = models.CharField(max_length=100)
    summary_deficiencies = models.CharField(max_length=100)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Discharge Certificate"
        verbose_name_plural = "Discharge Certificates"
    
    def __str__(self):
        return f"Discharge Certificate - {self.member_no} {self.member_name}"
    
from django.db import models
from django.contrib.auth.models import User
from dateutil.relativedelta import relativedelta

class ClothingCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return self.name

class ClothingItem(models.Model):
    name = models.CharField(max_length=100, unique=True)
    full_name = models.CharField(max_length=200, blank=True, null=True)
    lifespan_months = models.PositiveIntegerField(default=24)
    category = models.ForeignKey(ClothingCategory, on_delete=models.CASCADE, related_name='items')
    is_special_issue = models.BooleanField(default=False)
    is_recruit_issue = models.BooleanField(default=False)
    is_promotion_issue = models.BooleanField(default=False)

    def __str__(self):
        return self.name

class Officer(models.Model):
    # GENDER_CHOICES = [
    #     ('M', 'Male'),
    #     ('F', 'Female'),
    # ]
    
    date_attested = models.DateField()
    branch = models.CharField(max_length=100)
    force_no = models.CharField(max_length=50, unique=True, blank=True, null=True)
    name = models.CharField(max_length=100)
    initials = models.CharField(max_length=10, blank=True, null=True)
    # gender = models.CharField(max_length=1, choices=GENDER_CHOICES, default='M')
    scc_no = models.CharField(max_length=50, blank=True, null=True)
    cert_cl_no = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.force_no or 'No Force Number'})"

class Issuance(models.Model):
    officer = models.ForeignKey(Officer, on_delete=models.CASCADE, related_name='issuances')
    date = models.DateField()
    cl_no = models.CharField(max_length=50, blank=True, null=True)
    serial_no = models.CharField(max_length=50, blank=True, null=True)
    issued_by = models.CharField(max_length=100, blank=True, null=True)
    issued_by_date = models.DateField(blank=True, null=True)
    issued_by_signature = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        ordering = ['-date']
        
    def __str__(self):
        return f"Issuance #{self.cl_no or self.id} for {self.officer.name}"

class IssuedItem(models.Model):
    issuance = models.ForeignKey(Issuance, on_delete=models.CASCADE, related_name='items')
    clothing_item = models.ForeignKey(ClothingItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    date_issued = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.clothing_item.name} issued to {self.issuance.officer.name}"

class ClothingCard(models.Model):
    officer = models.OneToOneField(Officer, on_delete=models.CASCADE, related_name='clothing_card')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Clothing Card for {self.officer.name}"
    
    def get_all_issuances(self):
        return self.officer.issuances.all().order_by('-date')
    
    def get_current_items(self):
        """Returns a list of all items the officer currently has with their issue dates"""
        items = []
        for issuance in self.officer.issuances.all():
            for item in issuance.items.all():
                items.append({
                    'item': item.clothing_item,
                    'date_issued': issuance.date,
                    'issuance': issuance
                })
        return items