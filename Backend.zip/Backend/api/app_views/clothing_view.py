import json
import traceback
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from ..models import ClothingCategory

@require_GET  # Ensure only GET requests are allowed
def clothing_by_category(request):
    data = {}

    # Use prefetch_related for efficiency
    categories = ClothingCategory.objects.prefetch_related('items')

    for category in categories:
        item_names = list(category.items.values_list('name', flat=True))
        data[category.name] = item_names

    return JsonResponse(data, safe=False)

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from ..models import ClothingCategory, ClothingItem

@api_view(['POST'])
def add_clothing_item(request):
    data = request.data
    print(f"Received data: {data}")  # Debugging line to check incoming data
    category_name = data.get("category")
    item_name = data.get("itemName")
    lifespan = data.get("lifespan")

    if not category_name or not item_name or lifespan is None:
        return Response(
            {"error": "Missing required fields"},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        # Get or create the category
        category, _ = ClothingCategory.objects.get_or_create(name=category_name)

        # Check if item with that exact name already exists
        if ClothingItem.objects.filter(name=item_name).exists():
            return Response(
                {"error": "An item with this name already exists. Please use a different name."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Create the new item under the specified category
        new_item = ClothingItem.objects.create(
            name=item_name,
            lifespan_months=lifespan,
            category=category
        )

        return Response(
            {
                "message": "Clothing item created successfully",
                "item_id": new_item.id,
                "category_id": category.id
            },
            status=status.HTTP_201_CREATED
        )

    except Exception as e:
        return Response(
            {"error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# views.py
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from ..models import ClothingCategory, ClothingItem

@api_view(['DELETE'])
def delete_clothing_category(request, category_name):
    try:
        category = ClothingCategory.objects.get(name=category_name)
        category.delete()
        return Response({"message": f"Category '{category_name}' deleted successfully"}, status=status.HTTP_200_OK)
    except ClothingCategory.DoesNotExist:
        return Response({"error": "Category not found"}, status=status.HTTP_404_NOT_FOUND)

# views.py with related object handling
@api_view(['DELETE'])
def delete_clothing_item(request, category_name, item_name):
    try:
        category = ClothingCategory.objects.get(name=category_name)
        item = ClothingItem.objects.get(name=item_name, category=category)
        
        # Check if there are any issued items
        if item.issuedclothing_set.exists():
            return Response({
                "error": "Cannot delete this item because it has been issued to officers",
                "issued_count": item.issuedclothing_set.count()
            }, status=status.HTTP_400_BAD_REQUEST)
            
        item.delete()
        return Response({"message": f"Item '{item_name}' deleted successfully"}, status=status.HTTP_200_OK)
    except ClothingCategory.DoesNotExist:
        return Response({"error": "Category not found"}, status=status.HTTP_404_NOT_FOUND)
    except ClothingItem.DoesNotExist:
        return Response({"error": "Item not found"}, status=status.HTTP_404_NOT_FOUND)
    
from rest_framework import viewsets
from ..models import Officer, Issuance, ClothingItem
from ..serializers import OfficerDataSerializer, OfficerDataSerializer, IssuanceSerializer, ClothingItemSerializer
from rest_framework.response import Response
from rest_framework import status
# your_app_name/views.py

from rest_framework import viewsets, status
from rest_framework.response import Response
from ..models import Officer, Issuance, IssuedItem, ClothingItem, ClothingCategory
from ..serializers import OfficerDataSerializer, IssuanceSerializer, IssuedItemSerializer # Make sure you import all needed serializers
import datetime # Import datetime for date parsing
from django.db import transaction  # Correct import for transaction
from rest_framework.views import APIView  # Correct import for APIView
from rest_framework.permissions import AllowAny # <-- Add this import


class OfficerDataCreateView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        print("\n=== RAW REQUEST DATA ===")
        print(request.data)
        
        try:
            serializer = OfficerDataSerializer(data=request.data)
            
            if serializer.is_valid():
                print("\n=== VALIDATED DATA ===")
                print(serializer.validated_data)
                
                with transaction.atomic():
                    serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                print("\n=== SERIALIZATION ERRORS ===")
                print(json.dumps(serializer.errors, indent=4))
                return Response({
                    "message": "Validation failed",
                    "errors": serializer.errors,
                    "received_data": request.data
                }, status=status.HTTP_400_BAD_REQUEST)
                
        except Exception as e:
            print("\n=== EXCEPTION ===")
            print(traceback.format_exc())
            return Response({
                "message": "Server error",
                "error": str(e),
                "traceback": traceback.format_exc()
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        
class OfficerViewSet(viewsets.ModelViewSet):
    queryset = Officer.objects.all()
    serializer_class = OfficerDataSerializer
    lookup_field = 'force_no'

    def create(self, request, *args, **kwargs):
        # First, print the raw incoming data
        print("\n=== RAW INCOMING REQUEST DATA ===")
        print(request.data)
        
        data = request.data.copy()
        
        try:
            # Your existing data processing code...
            
            # After processing, print the transformed data
            print("\n=== PROCESSED DATA ===")
            print(json.dumps(data, indent=4, default=str))
            
            serializer = self.get_serializer(data=data)
            
            # Print validation errors if any
            if not serializer.is_valid():
                print("\n=== SERIALIZER ERRORS ===")
                print(json.dumps(serializer.errors, indent=4))
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            # If valid, proceed with save
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
            
        except Exception as e:
            print("\n=== EXCEPTION ===")
            print(str(e))
            return Response(
                {"error": "Server error", "details": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
   

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        
        print("\n=== RAW UPDATE REQUEST DATA ===")
        print(json.dumps(request.data, indent=2))

        try:
            # Use the serializer directly for update
            serializer = self.get_serializer(
                instance, 
                data=request.data, 
                partial=partial
            )
            
            serializer.is_valid(raise_exception=True)
            
            with transaction.atomic():
                self.perform_update(serializer)
            
            return Response(serializer.data)
            
        except Exception as e:
            print("\n=== UPDATE ERROR ===")
            print(traceback.format_exc())
            return Response(
                {
                    "message": "Update failed",
                    "error": str(e),
                    "traceback": traceback.format_exc()
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class IssuanceViewSet(viewsets.ModelViewSet):
    queryset = Issuance.objects.all()
    serializer_class = IssuanceSerializer

class ClothingItemViewSet(viewsets.ModelViewSet):
    queryset = ClothingItem.objects.all()
    serializer_class = ClothingItemSerializer