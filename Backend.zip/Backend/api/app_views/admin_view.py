from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from ..models import RequisitionForm
from rest_framework import generics, permissions, status

class ApproveRequisitionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            requisition = RequisitionForm.objects.get(pk=pk)
            requisition.office_in_charge_status = 'approved'
            requisition.save()
            return Response(
                {"success": True, "message": "Requisition approved."},
                status=status.HTTP_200_OK
            )
        except RequisitionForm.DoesNotExist:
            return Response(
                {"success": False, "message": "Requisition not found."},
                status=status.HTTP_404_NOT_FOUND
            )

class CardingApproveRequisitionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            requisition = RequisitionForm.objects.get(pk=pk)
            requisition.carding_status = 'approved'
            requisition.save()
            return Response(
                {"success": True, "message": "Requisition approved."},
                status=status.HTTP_200_OK
            )
        except RequisitionForm.DoesNotExist:
            return Response(
                {"success": False, "message": "Requisition not found."},
                status=status.HTTP_404_NOT_FOUND
            )


class RejectRequisitionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            requisition = RequisitionForm.objects.get(pk=pk)
            requisition.office_in_charge_status = 'rejected'
            requisition.save()
            return Response(
                {"success": True, "message": "Requisition rejected."},
                status=status.HTTP_200_OK
            )
        except RequisitionForm.DoesNotExist:
            return Response(
                {"success": False, "message": "Requisition not found."},
                status=status.HTTP_404_NOT_FOUND
            )