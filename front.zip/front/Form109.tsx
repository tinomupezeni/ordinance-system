import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import Form109Pdf from "@/formPdfs/Form109Pdf";

type ReceiptItem = {
  id: number;
  description: string;
  size: string;
  number: string;
  noTaken: string;
  received: boolean;
  rejected: boolean;
};

type FormData = {
  receivedFrom: string;
  ordinanceVoucherNo: string;
  gcsReqnNo: string;
  supplierRefNo: string;
  items: ReceiptItem[];
  receivedBy: {
    signature: string;
    date: string;
  };
  ledgerActionedBy: {
    signature: string;
    date: string;
  };
};

const Form109 = () => {
  const [formData, setFormData] = useState<FormData>({
    receivedFrom: "",
    ordinanceVoucherNo: "",
    gcsReqnNo: "",
    supplierRefNo: "",
    items: [
      {
        id: 1,
        description: "",
        size: "",
        number: "",
        noTaken: "",
        received: false,
        rejected: false,
      }
    ],
    receivedBy: {
      signature: "",
      date: "",
    },
    ledgerActionedBy: {
      signature: "",
      date: "",
    }
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSignatureChange = (section: 'receivedBy' | 'ledgerActionedBy', field: 'signature' | 'date', value: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleItemChange = (
    id: number,
    field: keyof ReceiptItem,
    value: string | boolean
  ) => {
    setFormData(prev => {
      const updatedItems = prev.items.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      );

      // Add new row if description is filled in the last row
      if (field === 'description' && 
          typeof value === 'string' && 
          value !== "" && 
          id === prev.items[prev.items.length - 1].id) {
        return {
          ...prev,
          items: [
            ...updatedItems,
            {
              id: prev.items.length + 1,
              description: "",
              size: "",
              number: "",
              noTaken: "",
              received: false,
              rejected: false,
            }
          ]
        };
      }

      return {
        ...prev,
        items: updatedItems
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter out empty items (where description is empty)
    const submittedItems = formData.items.filter(item => item.description.trim() !== "");
    
    const completeFormData = {
      ...formData,
      items: submittedItems
    };
    
    console.log("Form data to be sent to PDF:", completeFormData);
    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setFormData({
      receivedFrom: "",
      ordinanceVoucherNo: "",
      gcsReqnNo: "",
      supplierRefNo: "",
      items: [
        {
          id: 1,
          description: "",
          size: "",
          number: "",
          noTaken: "",
          received: false,
          rejected: false,
        }
      ],
      receivedBy: {
        signature: "",
        date: "",
      },
      ledgerActionedBy: {
        signature: "",
        date: "",
      }
    });
    toast.info("Form has been reset");
  };

  return (
    <>
      {!showPreview ? (
        <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm">
          <CardHeader className="pb-0">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
              <p className="text-sm text-gray-600">FORM 109 - ORDNANCE STORE RECEIPT VOUCHER</p>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Header Info */}
              <div className="mb-6">
                <div className="mb-4">
                  <Label>Received from:</Label>
                  <Input
                    value={formData.receivedFrom}
                    onChange={(e) => handleInputChange("receivedFrom", e.target.value)}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <Label>Ordnance Voucher No.</Label>
                    <Input
                      value={formData.ordinanceVoucherNo}
                      onChange={(e) => handleInputChange("ordinanceVoucherNo", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>G.C.S./Tradesman Reqn. No.</Label>
                    <Input
                      value={formData.gcsReqnNo}
                      onChange={(e) => handleInputChange("gcsReqnNo", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Supplier Ref: No.</Label>
                    <Input
                      value={formData.supplierRefNo}
                      onChange={(e) => handleInputChange("supplierRefNo", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Items Table */}
              <div className="mb-6">
                <div className="grid grid-cols-5 gap-2 font-semibold border-b pb-2 mb-2">
                  <div>Description of goods</div>
                  <div>Size</div>
                  <div>Number</div>
                  <div>No. taken</div>
                  <div>Status</div>
                </div>

                {formData.items.map((item) => (
                  <div key={item.id} className="grid grid-cols-5 gap-2 items-center border-b py-2">
                    <Input
                      value={item.description}
                      onChange={(e) => handleItemChange(item.id, "description", e.target.value)}
                    />
                    <Input
                      value={item.size}
                      onChange={(e) => handleItemChange(item.id, "size", e.target.value)}
                    />
                    <Input
                      value={item.number}
                      onChange={(e) => handleItemChange(item.id, "number", e.target.value)}
                    />
                    <Input
                      value={item.noTaken}
                      onChange={(e) => handleItemChange(item.id, "noTaken", e.target.value)}
                    />
                    <div className="flex gap-4">
                      <div className="flex items-center gap-1">
                        <input
                          type="checkbox"
                          id={`received-${item.id}`}
                          checked={item.received}
                          onChange={(e) => handleItemChange(item.id, "received", e.target.checked)}
                        />
                        <Label htmlFor={`received-${item.id}`}>Received</Label>
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="checkbox"
                          id={`rejected-${item.id}`}
                          checked={item.rejected}
                          onChange={(e) => handleItemChange(item.id, "rejected", e.target.checked)}
                        />
                        <Label htmlFor={`rejected-${item.id}`}>Rejected</Label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Signatures Section */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="border p-4 rounded">
                  <h3 className="font-semibold mb-2">Received and taken on Stock</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Signature</Label>
                      <Input
                        value={formData.receivedBy.signature}
                        onChange={(e) => handleSignatureChange("receivedBy", "signature", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={formData.receivedBy.date}
                        onChange={(e) => handleSignatureChange("receivedBy", "date", e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="border p-4 rounded">
                  <h3 className="font-semibold mb-2">Taken on Ledger</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Signature</Label>
                      <Input
                        value={formData.ledgerActionedBy.signature}
                        onChange={(e) => handleSignatureChange("ledgerActionedBy", "signature", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={formData.ledgerActionedBy.date}
                        onChange={(e) => handleSignatureChange("ledgerActionedBy", "date", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-between mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                >
                  Reset Form
                </Button>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      const submittedItems = formData.items.filter(item => 
                        item.description.trim() !== ""
                      );
                      setShowPreview(true);
                    }}
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Print Preview
                  </Button>
                  <Button type="submit">Submit Voucher</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Form109Pdf
          formData={{
            ...formData,
            items: formData.items.filter(item => item.description.trim() !== "")
          }}
          onBack={() => setShowPreview(false)}
          onPrint={handlePrint}
        />
      )}
    </>
  );
};

export default Form109;