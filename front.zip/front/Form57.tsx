import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import Form57Pdf from "@/formPdfs/Form57Pdf";

type LedgerEntry = {
  id: number;
  date: string;
  voucher: string;
  receipts: string;
  issues: string;
  balance: string;
};

type FormData = {
  description: string;
  price: string;
  reorderLevel: string;
  reorderAmount: string;
  ledgerEntries: LedgerEntry[];
};

const Form57 = () => {
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [reorderLevel, setReorderLevel] = useState("");
  const [reorderAmount, setReorderAmount] = useState("");

  const [entries, setEntries] = useState<LedgerEntry[]>([
    {
      id: 1,
      date: "",
      voucher: "",
      receipts: "",
      issues: "",
      balance: "",
    },
  ]);

  const [formData, setFormData] = useState<FormData>({
    description: "",
    price: "",
    reorderLevel: "",
    reorderAmount: "",
    ledgerEntries: [
      {
        id: 1,
        date: "",
        voucher: "",
        receipts: "",
        issues: "",
        balance: "",
      },
    ],
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleEntryChange = (
    id: number,
    field: keyof LedgerEntry,
    value: string
  ) => {
    setEntries((prev) => {
      const updatedEntries = prev.map((entry) =>
        entry.id === id ? { ...entry, [field]: value } : entry
      );

      // Check if we need to add a new row
      if (
        field === "balance" ||
        field === "date" ||
        (field === "voucher" && value !== "" && id === prev[prev.length - 1].id)
      ) {
        return [
          ...updatedEntries,
          {
            id: prev.length + 1,
            date: "",
            voucher: "",
            receipts: "",
            issues: "",
            balance: "",
          },
        ];
      }

      return updatedEntries;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out empty rows (where all fields are empty)
    const submittedEntries = entries.filter(
      (entry) =>
        entry.date ||
        entry.voucher ||
        entry.receipts ||
        entry.issues ||
        entry.balance
    );

    // Log all the form data
    console.log({
      itemDetails: {
        description,
        price,
        reorderLevel,
        reorderAmount,
      },
      ledgerEntries: submittedEntries,
    });

    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <>
      {!showPreview ? (
        <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm">
          <CardHeader className="pb-0">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
              <p className="text-sm text-gray-600">
                FORM 57 - ORDNANCE LEDGER CARD
              </p>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Item Information */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div>
                  <Label>Description</Label>
                  <Input
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Price</Label>
                  <Input
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Re-order Level</Label>
                  <Input
                    value={reorderLevel}
                    onChange={(e) => setReorderLevel(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Re-order Amount</Label>
                  <Input
                    value={reorderAmount}
                    onChange={(e) => setReorderAmount(e.target.value)}
                  />
                </div>
              </div>

              {/* Ledger Table */}
              <div className="mb-6">
                <div className="grid grid-cols-6 gap-2 font-semibold border-b pb-2 mb-2">
                  <div>Date</div>
                  <div>Voucher</div>
                  <div>Receipts</div>
                  <div>Issues</div>
                  <div>Balance</div>
                  <div>Outstanding Orders</div>
                </div>

                {entries.map((entry) => (
                  <div
                    key={entry.id}
                    className="grid grid-cols-6 gap-2 items-center border-b py-2"
                  >
                    <Input
                      type="date"
                      value={entry.date}
                      onChange={(e) =>
                        handleEntryChange(entry.id, "date", e.target.value)
                      }
                    />
                    <Input
                      value={entry.voucher}
                      onChange={(e) =>
                        handleEntryChange(entry.id, "voucher", e.target.value)
                      }
                    />
                    <Input
                      value={entry.receipts}
                      onChange={(e) =>
                        handleEntryChange(entry.id, "receipts", e.target.value)
                      }
                    />
                    <Input
                      value={entry.issues}
                      onChange={(e) =>
                        handleEntryChange(entry.id, "issues", e.target.value)
                      }
                    />
                    <Input
                      value={entry.balance}
                      onChange={(e) =>
                        handleEntryChange(entry.id, "balance", e.target.value)
                      }
                    />
                    <Input />
                  </div>
                ))}
              </div>

              {/* Form Actions */}
              <div className="flex justify-between mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Reset form
                    setDescription("");
                    setPrice("");
                    setReorderLevel("");
                    setReorderAmount("");
                    setEntries([
                      {
                        id: 1,
                        date: "",
                        voucher: "",
                        receipts: "",
                        issues: "",
                        balance: "",
                      },
                    ]);
                    toast.info("Form has been reset");
                  }}
                >
                  Reset Form
                </Button>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowPreview(true)}
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Print Preview
                  </Button>
                  <Button type="submit">Submit Ledger</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Form57Pdf
          // formData={
          //   null
          // }
          onBack={() => setShowPreview(false)}
          onPrint={handlePrint}
        />
      )}
    </>
  );
};

export default Form57;
