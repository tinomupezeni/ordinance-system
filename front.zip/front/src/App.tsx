import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import './components/Styles.css'
import AllForms from "./pages/AllForms";
import Notifications from "./pages/Notifications";
import MainLedgerBulk from "./officeforms/bulkstores/MainLedgerBulk";
import ClothingCardsIssues from "./officeforms/issues/IssuesClothingCards";
import FormPage from "./components/FormPage";
import Settings from "./pages/SettingsPage";
import Users from "./pages/Users";
import Form227Page from "./pages/formpages/Form227Page";

const queryClient = new QueryClient();

const office = localStorage.getItem("office");

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/forms" element={<Index />} />
          <Route path="/all-forms-109" element={<AllForms />} />
          <Route path="/main-ledger-bulk" element={<MainLedgerBulk />} />
          <Route path="/system/users" element={<Users />} />
          <Route path="/issues/clothing-card" element={<ClothingCardsIssues />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/forms/:formId" element={<FormPage />} />
          <Route path="/notifications" element={<Notifications office={office} />} />
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
          {/* form pages */}
          <Route path="/issues/form227" element={<Form227Page />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
