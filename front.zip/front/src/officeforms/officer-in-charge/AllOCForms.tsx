import React, { useEffect, useState } from "react";
import {
  FileText,
  CheckCircle,
  Clock,
  XCircle,
  X,
  ArrowLeftCircle,
} from "lucide-react";
import Form163Pdf from "@/formPdfs/Form163Pdf";
import Form227Pdf from "@/formPdfs/Form227Pdf";
import Form99Pdf from "@/formPdfs/Form99Pdf";
import ClothingCardForm from "@/forms/Form51B"; // Assuming this is Form 51A as per your render function
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
// import { printWithStyles } from "@/utils/print"; // Uncomment if you use it
import Server from "@/server/Server"; // Your API client
import { toast } from "sonner"; // For notifications

// --- Type Definitions ---
// Define a base type for common fields
interface BaseForm {
  id: number;
  created_at?: string; // Optional, as Form227 might use 'date'
  date?: string; // Optional, as Form163 might use 'created_at'
  // Add other common fields if they exist
}

// Specific type for Form163 data received from backend (serializer output)
interface Form163BackendData {
  id: number;
  created_by: string; // From StringRelatedField
  created_at: string;
  updated_at: string;
  officer_in_charge_approved: "WAITING" | "APPROVED" | "REJECTED";
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  items: any[]; // Adjust with actual RequisitionItem163Data type if you have it
  requestedBy: { initials: string; date: string };
  issuedBy: { initials: string; date: string };
  receivedBy: { initials: string; date: string };
  ledgerActionedBy: { initials: string; date: string };
}

// Specific type for Form227 data received from backend (RequisitionForm serializer output)
interface Form227BackendData {
  id: number;
  office_in_charge_status: "awaiting" | "approved" | "rejected";
  collectedBy: { name: string; id: number }; // Assuming collectedBy is an object
  date: string; // Date of the form
  // Add other fields specific to Form 227 (RequisitionForm) as they come from backend
}

// Unified type for state, with consistent display fields
interface CombinedDisplayForm extends BaseForm {
  type: "Form 163" | "Form 227" | "Form 99" | "Form 51A"; // Explicitly tag the type, broadened
  statusDisplay: "awaiting" | "approved" | "rejected"; // Standardized status field for display
  requestedByDisplay: string; // Standardized requester name for display
  dateDisplay: string; // Standardized date for display
  // Include all other properties from both form types
  [key: string]: any; // Allow for other dynamic properties
}

const AllOfficerInCharge = () => {
  const [forms, setForms] = useState<CombinedDisplayForm[]>([]);
  const [formData, setFormData] = useState<CombinedDisplayForm | null>(null);

  const [selectedFormType, setSelectedFormType] = useState<string | null>(null);
  const [selectedFormId, setSelectedFormId] = useState<number | null>(null); // Track ID, not index
  const [showApproveConfirm, setShowApproveConfirm] = useState(false);
  const [showRejectConfirm, setShowRejectConfirm] = useState(false); // For rejection dialog
  const [rejectionReason, setRejectionReason] = useState(""); // State for rejection reason input

  // --- Fetching Forms ---
  const handleFetchAllForms = async () => {
    try {
      // Fetch both types of forms concurrently
      const [response227, response163] = await Promise.all([
        Server.getForms227AdminAuth(), // Adjust this to your RequisitionForm waiting endpoint
        Server.getForms163AdminAuth(), // Adjust this to your Form163 waiting endpoint
      ]);

      // Map and tag Form 227 data for consistent display
      const taggedForms227: CombinedDisplayForm[] = response227.map(
        (form: Form227BackendData) => ({
          ...form,
          type: "Form 227",
          statusDisplay: form.office_in_charge_status, // Use existing status field
          requestedByDisplay: form.collectedBy?.name || "N/A", // Safely access name
          dateDisplay: form.date, // Use 'date' for Form 227
        })
      );

      // Map and tag Form 163 data for consistent display
      const taggedForms163: CombinedDisplayForm[] = response163.map(
        (form: Form163BackendData) => ({
          ...form,
          type: "Form 163",
          // Convert status to lowercase to match 'awaiting', 'approved', 'rejected'
          statusDisplay: form.officer_in_charge_approved.toLowerCase() as
            | "awaiting"
            | "approved"
            | "rejected",
          requestedByDisplay: form.created_by, // Use created_by for Form 163
          dateDisplay: form.created_at
            ? new Date(form.created_at).toLocaleDateString()
            : "N/A", // Format date
        })
      );

      // Combine and sort all forms by creation date (most recent first)
      const combinedAndSortedForms = [...taggedForms227, ...taggedForms163].sort(
        (a, b) => {
          // Use 'created_at' for Form163 and 'date' for Form227 for sorting
          const dateA = new Date(a.created_at || a.date || 0); // Use 0 for invalid dates
          const dateB = new Date(b.created_at || b.date || 0);
          return dateB.getTime() - dateA.getTime(); // Descending order
        }
      );

      setForms(combinedAndSortedForms);
      console.log("Combined and Tagged Forms:", combinedAndSortedForms);
    } catch (error) {
      toast.error(
        "Failed to fetch forms: " + (error?.message || "Unknown error")
      );
      console.error(error);
    }
  };

  useEffect(() => {
    handleFetchAllForms();
  }, []);

  // --- Form Selection ---
  // MODIFIED: Now accepts both id and type to ensure unique selection
  const handleFormSelection = (formId: number, formType: string) => {
    const formToDisplay = forms.find(
      (form) => form.id === formId && form.type === formType
    );

    if (formToDisplay) {
      setFormData(formToDisplay);
      setSelectedFormType(formToDisplay.type);
      setSelectedFormId(formId);
      // Add a console log here to confirm what's selected
      console.log("Selected Form for Display:", formToDisplay);
    } else {
      toast.error("Form data not found for selected ID and Type.");
    }
  };

  // --- Action Handlers (Approve/Reject) ---
  const handleApprove = async () => {
    if (!formData) return; // Should not happen if buttons are properly conditioned

    try {
      if (formData.type === "Form 227") {
        await Server.authorizeForm227(formData.id); // Assuming this is your Form 227 approval endpoint
      } else if (formData.type === "Form 163") {
        await Server.authorizeForm163(formData.id); // Your new Form 163 approval endpoint
      } else {
        toast.error("Unknown form type for approval.");
        return;
      }
      toast.success(`${formData.type} ${formData.id} approved successfully!`);
      setShowApproveConfirm(false);
      handleFetchAllForms(); // Re-fetch all forms to update the table
      handleBackHome(); // Go back to the list view
    } catch (error) {
      toast.error(
        "An error occurred during approval: " +
          (error?.response?.data?.detail || error?.message || "Unknown error")
      );
      console.error(error);
    }
  };

  const handleReject = async () => {
    if (!formData) return;

    try {
      if (formData.type === "Form 163") {
        if (!rejectionReason.trim()) {
          toast.error("Rejection reason is required for Form 163.");
          return;
        }
        await Server.rejectForm163(formData.id, rejectionReason); // Your new Form 163 rejection endpoint
      } else if (formData.type === "Form 227") {
         // Implement Form 227 rejection if needed. For now, it will show an error.
         toast.error("Form 227 rejection is not yet implemented.");
         return;
      } else {
        toast.error("Unknown form type for rejection.");
        return;
      }
      toast.success(`${formData.type} ${formData.id} rejected successfully!`);
      setShowRejectConfirm(false);
      setRejectionReason(""); // Clear rejection reason
      handleFetchAllForms(); // Re-fetch all forms to update the table
      handleBackHome(); // Go back to the list view
    } catch (error) {
      toast.error(
        "An error occurred during rejection: " +
          (error?.response?.data?.detail || error?.message || "Unknown error")
      );
      console.error(error);
    }
  };

  // --- UI State Management ---
  const handleBackHome = () => {
    setSelectedFormType(null);
    setFormData(null);
    setSelectedFormId(null);
    setRejectionReason(""); // Clear rejection reason when navigating back
  };

  // --- Conditional Rendering for Form Content ---
  const renderFormContent = () => {
    if (!formData) return <p>No form data available for display.</p>;

    console.log("Rendering form content. formData.type:", formData.type); // KEEP THIS DEBUG LOG
    console.log("Full formData received by renderFormContent:", formData); // KEEP THIS DEBUG LOG

    switch (formData.type) {
      case "Form 163":
        return (
          <Form163Pdf
            formData={formData as Form163BackendData} // Cast to specific type for the PDF component
            onBack={handleBackHome}
            onPrint={() => {
              // Your print logic for Form 163
              toast.info("Print function not implemented for Form 163 yet.");
            }}
          />
        );
      case "Form 227":
        return (
          <Form227Pdf
            formData={formData as Form227BackendData} // Cast to specific type
            onBack={handleBackHome}
            onPrint={() => {
              // Ensure printWithStyles is available or remove/implement
              // if (typeof printWithStyles !== 'undefined') {
              //   printWithStyles(".formpdf");
              // } else {
              //   console.warn("printWithStyles function not available for Form 227.");
              // }
              toast.info("Print function not implemented for Form 227 yet.");
            }}
          />
        );
      // Case for Form 99, 51A (ClothingCardForm) if they are to be viewed here
      case "Form 99":
        return (
          <Form99Pdf
            formData={formData as any} // Ensure Form99Pdf expects the correct type
            onBack={handleBackHome}
            onPrint={() => {
              toast.info("Print function not implemented for Form 99 yet.");
            }}
          />
        );
      case "Form 51A": // This likely corresponds to ClothingCardForm
        return (
          <ClothingCardForm
            formData={formData as any} // Pass necessary props to ClothingCardForm if it expects any
            onBack={handleBackHome}
            // Add other props if needed
          />
        );
      default:
        return (
          <p>
            Unknown form type or no specific renderer for "{formData.type}".
          </p>
        );
    }
  };

  // --- Status Badge Helper ---
  const getStatusBadge = (status: "awaiting" | "approved" | "rejected" | "Waiting") => { // Added "WAITING" to type for direct use
    switch (status.toLowerCase()) {
      case "approved":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-green-100 text-green-800 capitalize">
            <CheckCircle className="w-4 h-4" />
            {status}
          </span>
        );
      case "rejected":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-red-100 text-red-800 capitalize">
            <XCircle className="w-4 h-4" />
            {status}
          </span>
        );
      case "awaiting":
      case "waiting": // Handle both 'awaiting' and 'WAITING' for Form 163 (already lowercase in statusDisplay)
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-yellow-100 text-yellow-800 capitalize">
            <Clock className="w-4 h-4" />
            awaiting
          </span>
        );
      default:
        return <span className="capitalize">{status}</span>;
    }
  };

  // --- Main Component Render ---
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="p-6">
        <h2 className="text-2xl font-semibold mb-6">
          Officer in Charge - Forms Awaiting Approval
        </h2>
        {!selectedFormType ? (
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <table className="min-w-full table-auto text-sm">
              <thead>
                <tr className="border-b">
                  <th className="py-3 px-4 text-left">Form #</th>
                  <th className="py-3 px-4 text-left">Form </th>
                  <th className="py-3 px-4 text-left">Requested By</th>
                  <th className="py-3 px-4 text-left">Date</th>
                  <th className="py-3 px-4 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {forms.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-gray-500">
                      No forms awaiting approval.
                    </td>
                  </tr>
                ) : (
                  forms.map((form) => (
                    <tr
                      key={`${form.type}-${form.id}`} // Unique key for combined list
                      // MODIFIED: Pass both form.id and form.type to handleFormSelection
                      onClick={() => handleFormSelection(form.id, form.type)}
                      className="border-b hover:bg-gray-50 cursor-pointer"
                    >
                      <td className="py-3 px-4">{form.id}</td>
                      <td className="py-3 px-4 text-blue-600 hover:text-blue-800">
                        {form.type} {/* Display the tagged type */}
                      </td>
                      <td className="py-3 px-4">{form.requestedByDisplay}</td>
                      <td className="py-3 px-4">{form.dateDisplay}</td>
                      <td className="py-3 px-4">
                        {getStatusBadge(form.statusDisplay || form.officer_in_charge_approved)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="mt-6 bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex justify-between items-center mb-4 w-[50%] mx-auto">
              <h3 className="text-xl font-semibold">Form Details</h3>
              <Button
                variant="outline"
                className=" text-gray-500 hover:bg-gray-50 hover:text-gray-600"
                onClick={handleBackHome}
              >
                <ArrowLeftCircle className="w-4 h-4 mr-2" />
                Back
              </Button>
              {/* Conditional rendering for approve/reject buttons based on current form's actual status */}
              {formData &&
              ((formData.type === "Form 163" &&
                (formData as Form163BackendData).officer_in_charge_approved ===
                  "WAITING") ||
                (formData.type === "Form 227" &&
                  (formData as Form227BackendData).office_in_charge_status ===
                    "awaiting")) ? (
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="border-red-500 text-red-500 hover:bg-red-50 hover:text-red-600"
                    onClick={() => setShowRejectConfirm(true)} // Open rejection dialog
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => setShowApproveConfirm(true)}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                </div>
              ) : (
                <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-green-100 text-green-800 capitalize">
                  <CheckCircle className="w-4 h-4" />
                  {formData?.statusDisplay || "Processed"}
                </span>
              )}
            </div>
            {renderFormContent()}
          </div>
        )}
      </div>

      {/* Approval Confirmation Dialog */}
      <AlertDialog
        open={showApproveConfirm}
        onOpenChange={setShowApproveConfirm}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Approval</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to approve this form? This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-green-600 hover:bg-green-700"
              onClick={handleApprove}
            >
              Approve
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Rejection Confirmation Dialog */}
      <AlertDialog
        open={showRejectConfirm}
        onOpenChange={setShowRejectConfirm}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Rejection</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this form? Please provide a reason
              if required.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {formData?.type === "Form 163" && ( // Only show reason input for Form 163
            <div className="mt-4">
              <label
                htmlFor="rejection-reason"
                className="block text-sm font-medium text-gray-700"
              >
                Rejection Reason:
              </label>
              <textarea
                id="rejection-reason"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm"
                rows={3}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="e.g., Missing documentation, incorrect details"
              ></textarea>
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setRejectionReason("")}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={handleReject}
            >
              Reject
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AllOfficerInCharge;