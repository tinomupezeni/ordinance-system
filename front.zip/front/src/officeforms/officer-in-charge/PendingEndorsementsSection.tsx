import { Button } from "@/components/ui/button";

const PendingEndorsementsSection = ({ count = 0, onClick }) => {
  const sampleForms = [
    {
      id: 1,
      formType: "Exchange Voucher",
      submittedBy: "Sgt. Nyathi",
      submittedAt: "2025-05-05",
    },
    {
      id: 2,
      formType: "Request for Supplies",
      submittedBy: "Cst. Moyo",
      submittedAt: "2025-05-04",
    },
  ];

  return (
    <div className="bg-white p-6 rounded-lg border border-blue-100 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-2 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" viewBox="0 0 20 20" fill="currentColor">
              <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
              <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-800">
              Pending Endorsements
            </h2>
            <p className="text-sm text-gray-500">
              {count || 2} forms awaiting your approval
            </p>
          </div>
        </div>
        <Button 
          variant="default"
          size="sm"
          onClick={onClick}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Review All
        </Button>
      </div>
      
      <div className="space-y-3">
        {sampleForms.slice(0, 2).map((form) => (
          <div key={form.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">{form.formType}</p>
              <p className="text-sm text-gray-500">
                Submitted by {form.submittedBy} on {new Date(form.submittedAt).toLocaleDateString()}
              </p>
            </div>
            {/* <Button 
              variant="outline"
              size="sm"
              onClick={() => {/* Handle quick review */}
            {/* >
              Quick Review
            </Button> */} 
          </div>
        ))}
      </div>
    </div>
  );
};
export default PendingEndorsementsSection;
