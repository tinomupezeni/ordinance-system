import {Loader} from 'lucide-react'
import Server from "@/server/Server"; // Make sure this path is correct
import { useEffect, useState } from "react";
import { toast } from "sonner"; // Assuming you have sonner for toasts

const AllUsers = () => {
  const [users, setUsers] = useState([]);
  const [showCreateUserForm, setShowCreateUserForm] = useState(false);
  const [newUser, setNewUser] = useState({
    username: "", // This will be the Force Number
    email: "",
    password: "",
    rank: "",
    first_name: "",
    last_name: "",
    office: "",
    province: "",
    station: "",
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Function to fetch all users
  const fetchUsers = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await Server.getAllSystemUsers();
      console.log("Fetched users:", response);
      setUsers(response);
    } catch (err) {
      console.error("Error fetching users:", err);
      setError("Failed to fetch users. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Function to handle status update
  const handleUpdateStatus = async (userId, newStatus) => {
    try {
      await Server.updateUserStatus(userId, newStatus);
      toast.success(`User status updated to ${newStatus}!`);
      // Re-fetch users to update the UI
      fetchUsers();
    } catch (err) {
      console.error(`Error updating user status to ${newStatus}:`, err);
      toast.error(`Failed to update user status: ${err.message || 'An error occurred'}`);
    }
  };

  // Fetch users when the component mounts
  useEffect(() => {
    fetchUsers();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewUser((prevUser) => ({
      ...prevUser,
      [name]: value,
    }));
  };


  // Helper function to get status badge styling
  const getStatusBadge = (status) => {
    let colorClass = "";
    switch (status) {
      case "pending":
        colorClass = "bg-yellow-100 text-yellow-800";
        break;
      case "active":
        colorClass = "bg-green-100 text-green-800";
        break;
      case "suspended":
        colorClass = "bg-orange-100 text-orange-800";
        break;
      case "rejected":
        colorClass = "bg-red-100 text-red-800";
        break;
      default:
        colorClass = "bg-gray-100 text-gray-800";
    }
    return (
      <span
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${colorClass}`}
      >
        {status.replace('-', ' ')}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* You can uncomment and use Header and Sidebar if they are part of your layout */}
      {/* <Header /> */}
      <div className="flex">
        {/* <Sidebar /> */}
        <main className="flex-1 ">
          <div className="bg-white p-4 shadow rounded mb-6 ">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-lg font-semibold">All System Users</h2> {/* Title added back */}
              
            </div>

            {/* Display Loading/Error State */}
            {loading && <p className="text-center py-4"><Loader className='h-4 w-4 animate'/>Loading users...</p>}
            {error && <p className="text-center py-4 text-red-500">{error}</p>}

            {/* Users Table */}
            {!loading && !error && (
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="py-2 px-4 text-left">Force Number</th>
                    <th className="py-2 px-4 text-left">Name</th>
                    <th className="py-2 px-4 text-left">Rank</th>
                    <th className="py-2 px-4 text-left">Office</th>
                    <th className="py-2 px-4 text-left">Province</th>
                    <th className="py-2 px-4 text-left">Station</th>
                    <th className="py-2 px-4 text-left">Status</th>
                    <th className="py-2 px-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users?.length > 0 ? (
                    users.map((userProfile) => (
                      <tr
                        key={userProfile.id}
                        className="hover:bg-gray-50 border-b "
                      >
                        <td className="py-3 px-4">
                          {userProfile.user.username}
                        </td>
                        <td className="py-2 px-4">
                          {userProfile.user?.first_name}{" "}
                          {userProfile.user?.last_name}
                        </td>
                        <td className="py-2 px-4">{userProfile.rank}</td>
                        <td className="py-2 px-4">{userProfile.office}</td>
                        <td className="py-2 px-4">{userProfile.province}</td>
                        <td className="py-2 px-4">{userProfile.station}</td>
                        <td className="py-2 px-4">
                          {getStatusBadge(userProfile.status)}
                        </td>
                        <td className="py-2 px-4">
                          {userProfile.status === "pending" && (
                            <div className="flex gap-2">
                              <button
                                onClick={() =>
                                  handleUpdateStatus(userProfile.id, "active")
                                }
                                className="bg-green-500 text-white px-3 py-1 rounded text-xs hover:bg-green-600"
                                title="Approve User"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() =>
                                  handleUpdateStatus(userProfile.id, "rejected")
                                }
                                className="bg-red-500 text-white px-3 py-1 rounded text-xs hover:bg-red-600"
                                title="Reject User"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                          {userProfile.status === "active" && (
                            <button
                              onClick={() =>
                                handleUpdateStatus(userProfile.id, "suspended")
                              }
                              className="bg-orange-500 text-white px-3 py-1 rounded text-xs hover:bg-orange-600"
                              title="Suspend User"
                            >
                              Suspend
                            </button>
                          )}
                          {userProfile.status === "suspended" && (
                            <button
                              onClick={() =>
                                handleUpdateStatus(userProfile.id, "active")
                              }
                              className="bg-blue-500 text-white px-3 py-1 rounded text-xs hover:bg-blue-600"
                              title="Reactivate User"
                            >
                              Reactivate
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={8} className="text-center py-4">
                        No users found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AllUsers;