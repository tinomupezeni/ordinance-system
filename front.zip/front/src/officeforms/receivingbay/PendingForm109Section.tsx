// components/PendingForm109Section.tsx
const PendingForm109Section = ({forms}) => {
    const pendingForms = [
      { id: "109-001", supplier: "Gweru Stores", date: "2025-05-05", items: 4 },
      { id: "109-002", supplier: "Harare Central", date: "2025-05-06", items: 7 },
    ];
  
    return (
      <div className="bg-white p-4 rounded-xl shadow mb-6">
        <h2 className="text-lg font-semibold mb-4">📥 Pending Form 109</h2>
        <ul className="space-y-3">
          {pendingForms.map((form) => (
            <li
              key={form.id}
              className="flex justify-between items-center border p-3 rounded-md"
            >
              <div>
                <p className="font-medium">{form.id}</p>
                <p className="text-sm text-gray-600">
                  From {form.supplier} – {form.items} items
                </p>
                <p className="text-xs text-gray-500">Received: {form.date}</p>
              </div>
              {/* <button className="bg-green-600 text-white px-4 py-1 rounded-md hover:bg-green-700 text-sm">
                Record Stock
              </button> */}
            </li>
          ))}
        </ul>
      </div>
    );
  };
  
  export default PendingForm109Section;
  