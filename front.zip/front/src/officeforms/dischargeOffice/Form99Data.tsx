const mockForm99Data = [
    { id: 1, officerName: "Constable John M.", dischargeDate: "2025-05-05", reason: "Retirement" },
    { id: 2, officerName: "Sergeant Clara Z.", dischargeDate: "2025-05-01", reason: "Medical" },
  ];
  
  const Form99Discharges = () => (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Form 99 - Discharge Records</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Officer</th>
            <th className="py-2 px-4">Discharge Date</th>
            <th className="py-2 px-4">Reason</th>
            <th className="py-2 px-4">Action</th>
          </tr>
        </thead>
        <tbody>
          {mockForm99Data.map((item) => (
            <tr key={item.id} className="hover:bg-gray-50">
              <td className="py-2 px-4">{item.officerName}</td>
              <td className="py-2 px-4">{item.dischargeDate}</td>
              <td className="py-2 px-4">{item.reason}</td>
              <td className="py-2 px-4 text-blue-600 cursor-pointer">View</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  export default Form99Discharges;
  