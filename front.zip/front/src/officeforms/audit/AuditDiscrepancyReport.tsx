import React, { useState, useMemo } from "react";
import { AlertTriangle, CheckCircle, FileText, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner"; // Assuming you have toast for notifications

// Re-using formatDateTime from your Dashboard or utility file
const formatDateTime = (isoString) => {
  if (!isoString) return "";
  try {
    const date = new Date(isoString);
    const options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    };
    return date.toLocaleDateString("en-GB", options);
  } catch (error) {
    console.error("Error formatting date:", error);
    return isoString;
  }
};

const AuditDiscrepancyReport = ({ forms163, forms227 }) => {
  const [searchTerm, setSearchTerm] = useState("");

  // Example simplified discrepancy detection (highly depends on your data model)
  // This is just a conceptual example. Actual discrepancy logic is complex.
  const potentialDiscrepancies = useMemo(() => {
    const discrepancies = [];
    // Example: Check if a Form 163 item has a corresponding issue on Form 227
    // This would require a sophisticated matching algorithm based on item, quantity, date, etc.

    // Placeholder for real discrepancy logic:
    // For now, let's just create some dummy discrepancies to show the table structure
    if (forms163.length > 0 && forms227.length > 0) {
      discrepancies.push({
        type: "Form 163 vs 227 Mismatch",
        form1Id: forms163[0]?.id,
        form2Id: forms227[0]?.id,
        description: `Quantity requested on Form 163 #${forms163[0]?.id} doesn't match issued on Form 227 #${forms227[0]?.id}.`,
        date: new Date().toISOString(),
        status: "Unresolved",
      });
    }
    if (forms163.length > 1) {
      discrepancies.push({
        type: "Form 163 with no matching 227",
        form1Id: forms163[1]?.id,
        form2Id: "N/A",
        description: `Form 163 #${forms163[1]?.id} seems to have no corresponding Form 227 issue.`,
        date: new Date().toISOString(),
        status: "Unresolved",
      });
    }

    // Filter discrepancies based on search term
    return discrepancies.filter(
      (d) =>
        d.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        d.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        String(d.form1Id).includes(searchTerm) ||
        String(d.form2Id).includes(searchTerm)
    );
  }, [forms163, forms227, searchTerm]);

  const handleResolveDiscrepancy = (discrepancyId) => {
    // In a real application, this would mark the discrepancy as resolved in your backend
    toast.success(`Discrepancy ${discrepancyId} marked as resolved.`);
    // You'd typically re-fetch or update the state to remove it from the list
  };

  return (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3 flex items-center">
        <AlertTriangle className="w-5 h-5 mr-2 text-red-500" /> Discrepancy
        Reports
      </h2>

      <div className="mb-4 flex items-center space-x-2">
        <Input
          type="text"
          placeholder="Search discrepancies..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
        <Button variant="outline" className="text-gray-600">
          <Search className="w-4 h-4 mr-2" /> Search
        </Button>
      </div>

      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4 text-left">Type</th>
            <th className="py-2 px-4 text-left">Form 1 ID</th>
            <th className="py-2 px-4 text-left">Form 2 ID</th>
            <th className="py-2 px-4 text-left">Description</th>
            <th className="py-2 px-4 text-left">Date Identified</th>
            <th className="py-2 px-4 text-left">Status</th>
            <th className="py-2 px-4 text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {potentialDiscrepancies.length === 0 ? (
            <tr>
              <td colSpan="7" className="py-8 text-center text-gray-500">
                No discrepancies found (or all resolved).
              </td>
            </tr>
          ) : (
            potentialDiscrepancies.map((d, index) => (
              <tr key={index} className="hover:bg-gray-50 border-b">
                <td className="py-2 px-4 font-medium">{d.type}</td>
                <td className="py-2 px-4">{d.form1Id}</td>
                <td className="py-2 px-4">{d.form2Id}</td>
                <td className="py-2 px-4">{d.description}</td>
                <td className="py-2 px-4">{formatDateTime(d.date)}</td>
                <td className="py-2 px-4">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                      d.status === "Resolved"
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {d.status === "Resolved" ? (
                      <CheckCircle className="w-3 h-3" />
                    ) : (
                      <AlertTriangle className="w-3 h-3" />
                    )}
                    {d.status}
                  </span>
                </td>
                <td className="py-2 px-4 text-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleResolveDiscrepancy(index)} // Use unique ID for actual item
                    className="text-green-600 hover:text-green-800 hover:bg-green-50"
                  >
                    Resolve
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AuditDiscrepancyReport;
