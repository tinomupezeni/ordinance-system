import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import Form57Pdf from "@/formPdfs/Form57Pdf";
import { useState } from "react";

const mainledgerForms = [
  {
    formNumber: "163/2025/011",
    date: "2025-05-05",
    requestedBy: "Cap STU",
    size: 40,
    status: "Pending",
  },
  {
    formNumber: "163/2025/010",
    date: "2025-05-04",
    requestedBy: "Trouser Pawn",
    size: 120,
    status: "Approved",
  },
  {
    formNumber: "163/2025/011",
    date: "2025-05-05",
    requestedBy: "Cap STU",
    size: 43,
    status: "Pending",
  },
  {
    formNumber: "163/2025/010",
    date: "2025-05-04",
    requestedBy: "Trouser Pawn",
    size: 120,
    status: "Approved",
  },
  {
    formNumber: "163/2025/011",
    date: "2025-05-05",
    requestedBy: "Cap STU",
    size: 45,
    status: "Pending",
  },
  {
    formNumber: "163/2025/010",
    date: "2025-05-04",
    requestedBy: "Trouser Pawn",
    size: 120,
    status: "Approved",
  },
];

const MainLedgerBulk = () => {
  const [filters, setFilters] = useState({
    date: "",
    requestedBy: "",
    size: "",
  });

  const uniqueItems = Array.from(
    new Set(mainledgerForms.map((f) => f.requestedBy))
  );

  const filteredForms = mainledgerForms.filter((form) => {
    const matchesDate = filters.date === "" || form.date === filters.date;
    const matchesItem =
      filters.requestedBy === "" || form.requestedBy === filters.requestedBy;
    const matchesSize =
      filters.size === "" || form.size === Number(filters.size);
    return matchesDate && matchesItem && matchesSize;
  });

  const [showLedger, setShowLedger] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 ml-72 mt-20">
          <div className="bg-white p-4 shadow rounded mb-6 ">
            <div className="flex justify-between">
              <h2 className="text-lg font-semibold mb-3">
                Form 57 - Main Ledger Forms
              </h2>

              {/* Filter section */}
              <div className="flex gap-4 mb-4">
                <input
                  type="date"
                  className="border rounded px-2 py-1"
                  value={filters.date}
                  onChange={(e) =>
                    setFilters({ ...filters, date: e.target.value })
                  }
                />

                <select
                  className="border rounded px-2 py-1"
                  value={filters.requestedBy}
                  onChange={(e) =>
                    setFilters({ ...filters, requestedBy: e.target.value })
                  }
                >
                  <option value="">All Items</option>
                  {uniqueItems.map((item, index) => (
                    <option key={index} value={item}>
                      {item}
                    </option>
                  ))}
                </select>

                <input
                  type="number"
                  className="border rounded px-2 py-1"
                  placeholder="Filter by Size"
                  value={filters.size}
                  onChange={(e) =>
                    setFilters({ ...filters, size: e.target.value })
                  }
                />
              </div>
            </div>

            {!showLedger ? (
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="py-2 px-4">Ledger #</th>
                    <th className="py-2 px-4">Date</th>
                    <th className="py-2 px-4">Items</th>
                    <th className="py-2 px-4">Size</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredForms.length > 0 ? (
                    filteredForms.map((req, i) => (
                      <tr key={i} className="hover:bg-gray-50 cursor-pointer border-b " onClick={() => setShowLedger(true)}>
                        <td className="py-3 px-4">{req.formNumber}</td>
                        <td className="py-2 px-4">{req.date}</td>
                        <td className="py-2 px-4">{req.requestedBy}</td>
                        <td className="py-2 px-4">{req.size}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="text-center py-4">
                        No results found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            ) : (
              <Form57Pdf
                formData={undefined}
                onBack={() => setShowLedger(false)}
                onPrint={function (): void {
                  throw new Error("Function not implemented.");
                }}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default MainLedgerBulk;
