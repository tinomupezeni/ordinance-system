import React from "react";

const PendingForm163Requests = ({requests}) => {
  return (
    <div className="bg-white p-4 shadow rounded mb-6">
      <h2 className="text-lg font-semibold mb-3">Form 163 - Requisition Requests</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Form #</th>
            <th className="py-2 px-4">Date</th>
            <th className="py-2 px-4">Station</th>
            <th className="py-2 px-4">Items</th>
            <th className="py-2 px-4">Status</th>
          </tr>
        </thead>
        <tbody>
          {requests?.map((req, i) => (
            <tr key={i} className="hover:bg-gray-50">
              <td className="py-2 px-4">{req.formNumber}</td>
              <td className="py-2 px-4">{req.date}</td>
              <td className="py-2 px-4">{req.requestedBy}</td>
              <td className="py-2 px-4">{req.itemsRequested}</td>
              <td className="py-2 px-4">{req.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PendingForm163Requests;
