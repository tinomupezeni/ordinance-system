import { Button } from "@/components/ui/button";
import TallySheetPdf from "@/formPdfs/TallySheetPdf";
import { ClipboardList, Eye, X } from "lucide-react";
import { useState } from "react";

const TallySheetRecord = () => {
  const [records, setRecords] = useState([
    {
      id: 1,
      formNumber: "TALLY/2025/010",
      date: "2025-05-05",
      stockChecked: "Jacket Mat",
      quantityChecked: 250,
      condition: "Good",
      status: "Completed",
    },
    {
      id: 2,
      formNumber: "TALLY/2025/009",
      date: "2025-05-04",
      stockChecked: "Shirt Grey",
      quantityChecked: 473,
      condition: "Good",
      status: "Completed",
    },
    {
      id: 3,
      formNumber: "TALLY/2025/008",
      date: "2025-05-03",
      stockChecked: "Trousers Mat",
      quantityChecked: 320,
      condition: "Damaged (2 items)",
      status: "Pending Review",
    },
  ]);

  const [openForm, setOpenForm] = useState(false);
  const [currentRecord, setCurrentRecord] = useState(null);

  const viewForm = (record) => {
    setCurrentRecord(record);
    setOpenForm(true);
  };

  return (
    <div className="bg-white p-4 shadow rounded-lg mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <ClipboardList className="text-blue-500" /> Tally Sheet Records
        </h2>
        <Button variant="outline">View All</Button>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setOpenForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  <X className="w-4 h-4" />
                  Back to list
                </Button>
              </div>
              {currentRecord?.status === "Pending Review" && (
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Flag Discrepancy
                  </Button>
                  <Button
                    variant="default"
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Approve Tally
                  </Button>
                </div>
              )}
            </div>

            <div className="mt-4">
              <TallySheetPdf
                formData={currentRecord}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b">
                <th className="py-3 px-4 text-left">Form #</th>
                <th className="py-3 px-4 text-left">Date</th>
                <th className="py-3 px-4 text-left">Stock Checked</th>
                <th className="py-3 px-4 text-left">Quantity</th>
                <th className="py-3 px-4 text-left">Condition</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {records.map((record) => (
                <tr key={record.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium">{record.formNumber}</td>
                  <td className="py-3 px-4">{record.date}</td>
                  <td className="py-3 px-4">{record.stockChecked}</td>
                  <td className="py-3 px-4">{record.quantityChecked}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded text-xs ${
                        record.condition.includes("Good")
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {record.condition}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        record.status === "Completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {record.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewForm(record)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default TallySheetRecord;