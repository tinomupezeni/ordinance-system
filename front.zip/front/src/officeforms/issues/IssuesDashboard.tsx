import { useEffect, useState } from "react";
import SummaryCard from "@/components/SummaryCard";
import { Button } from "@/components/ui/button";
import Form227 from "@/forms/Form227";
import Form163 from "@/forms/Form163";
import PendingForm51Requests from "@/officeforms/issues/PendingForm51Requests";
import Book2Register from "@/officeforms/issues/Book2Register";
import TransferHistory157 from "@/officeforms/cadex/TransferHistory157";
import Form57Ledger from "@/officeforms/loans/Form57Ledger";
import Form163Dispatches from "@/officeforms/dispatch/Form163Dispatches";
import Server from "@/server/Server";
import Form227IssuanceLog from "./Form227Issuance";
import Forms109Issue from "./Forms109Issue";
import Form57 from "@/forms/Form57";
import Form157 from "@/forms/Form157";
import { BookOpenCheck, FileCheck, FileText } from "lucide-react";
import Book2 from "@/forms/Book2";

export default function IssuesOfficerDashboard({ dashboardData }) {
  // Use a single state for which form to show
  const [activeForm, setActiveForm] = useState("Form227Input"); // Default to Form227
  const [form57, setForms57] = useState([]);
  const [forms163, setForms163] = useState([]);

  const issuesSummary = [
    {
      title: "Book2 /I.V",
      count: dashboardData?.book2?.total,
      icon: <BookOpenCheck />,
      color: "bg-purple-50",
      forms: "Book2",
    },
    {
      title: "Form 227",
      count: dashboardData?.form227?.total,
      icon: <FileText />,
      color: "bg-blue-50",
      forms: "Form227",
      notify: 2,
    },
    {
      title: "Form 51",
      count: dashboardData?.clothing_cards?.total,
      icon: <FileCheck />,
      color: "bg-green-50",
      forms: "Form51",
    },
    {
      title: "Form 109",
      count: dashboardData?.form109?.total,
      icon: <FileCheck />,
      color: "bg-red-50",
      forms: "Form109",
    },
    {
      title: "Form 163",
      count: dashboardData?.form163?.total,
      icon: <FileCheck />,
      color: "bg-yellow-50",
      forms: "Form163Dispatches",
    },
    {
      title: "Form 57",
      count: 3,
      icon: <FileCheck />,
      color: "bg-red-50",
      forms: "Form57",
    },
    {
      title: "Form 157",
      count: 3,
      icon: <FileCheck />,
      color: "bg-blue-50",
      forms: "Form157",
    },
  ];

  const getForm57 = (office) => {
    Server.getAllForm57s(office)
      .then((response) => {
        console.log(response);

        setForms57(response);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const getForm163s = () => {
    Server.getAllForm163s().then((response) => {
      console.log(response);
      setForms163(response);
    });
  };

  // state variable
  useEffect(() => {
    getForm57("ISSUES"); // Fetch Form 57 data for Issues Officer
    getForm163s();
  }, []);
  // method to fetch 163 data

  // Map form keys to components
  const formComponents = {
    Form227Input: (
      <>
        <h1 className="font-bold uppercase mb-5">
          Individual Officers Form 227
        </h1>
        <Form227
        // onBack={() => setActiveForm("Form227")}
        />
      </>
    ),
    Form57Input: (
      <>
        <h1 className="font-bold uppercase mb-5">Ledger Card Form 57</h1>
        <Form57
          formId={undefined}
          onSubmissionSuccess={undefined}
          formType={"ISSUES"} // onBack={() => setActiveForm("Form227")}
        />
      </>
    ),
    Form157Input: (
      <>
        <h1 className="font-bold uppercase mb-5">Ledger Card Form 57</h1>
        <Form157
          office={"ISSUES"} // onBack={() => setActiveForm("Form227")}
        />
      </>
    ),
    Book2Input: (
      <>
        <h1 className="font-bold uppercase mb-5">Ledger Card Form 57</h1>
        <Book2
          office={"ISSUES"} // onBack={() => setActiveForm("Form227")}
        />
      </>
    ),
    Form163: (
      <>
        <h1 className="font-bold uppercase mb-5">Requisition Form 163</h1>
        <Form163
          formType="Request from Issues"
          // onBack={() => setActiveForm("Form227")}
        />
      </>
    ),
    Form51: <PendingForm51Requests />,
    Book2: <Book2Register office={"ISSUES"} />,
    Form227: <Form227IssuanceLog />,
    Form157: <TransferHistory157 />,
    Form57: <Form57Ledger form57={form57} />,
    Form163Dispatches: <Form163Dispatches forms163={forms163} />,
    Form109: <Forms109Issue />,
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6 mt-5">
        {issuesSummary.map((item, idx) => (
          <SummaryCard
            key={idx}
            title={item.title}
            count={item.count}
            color={item.color}
            icon={item.icon}
            forms={item.forms}
            // notify={item.notify}
            onViewAll={() => setActiveForm(item.forms)}
          />
        ))}
      </div>

      <div className="space-x-4 my-5">
        <Button
          variant={activeForm === "Form227Input" ? "default" : "outline"}
          onClick={() => setActiveForm("Form227Input")}
        >
          Issue Voucher [Form 227]
        </Button>
        <Button
          variant={activeForm === "Form163" ? "default" : "outline"}
          onClick={() => setActiveForm("Form163")}
        >
          Requisition Voucher [Form 163]
        </Button>
        <Button
          variant={activeForm === "Form57Input" ? "default" : "outline"}
          onClick={() => setActiveForm("Form57Input")}
        >
          Ledger Card [Form 57]
        </Button>
        <Button
          variant={activeForm === "Form157Input" ? "default" : "outline"}
          onClick={() => setActiveForm("Form157Input")}
        >
          Exchange Voucher [Form 157]
        </Button>
        <Button
          variant={activeForm === "Book2Input" ? "default" : "outline"}
          onClick={() => setActiveForm("Book2Input")}
        >
          Book 2
        </Button>
      </div>

      <div className="mt-5">{formComponents[activeForm]}</div>
    </>
  );
}
