import { Button } from "@/components/ui/button";
import Book2Pdf from "@/formPdfs/Book2Pdf";
import Server from "@/server/Server";
import { Edit, Trash2, Eye, Plus, Check } from "lucide-react";
import { useEffect, useState } from "react";
import { format } from "date-fns"; // Import date-fns for date formatting

const Book2Register = ({ office }) => {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true); // Add loading state
  const [error, setError] = useState(null); // Add error state

  const [showForm, setShowForm] = useState(false);
  const [currentEntry, setCurrentEntry] = useState(null);

  // Function to format the status for display
  const getStatusBadge = (status) => {
    let colorClass = "";
    let displayText = "";
    switch (status) {
      case "pending":
        colorClass = "bg-yellow-100 text-yellow-800";
        displayText = "Pending";
        break;
      case "completed": // Assuming 'completed' is a possible status
        colorClass = "bg-green-100 text-green-800";
        displayText = "Completed";
        break;
      case "rejected":
        colorClass = "bg-red-100 text-red-800";
        displayText = "Rejected";
        break;
      default:
        colorClass = "bg-gray-100 text-gray-800";
        displayText = "Unknown";
    }
    return (
      <span
        className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${colorClass}`}
      >
        {displayText}
      </span>
    );
  };


  const viewEntry = (entry) => {
    setCurrentEntry(entry);
    setShowForm(true);
  };

  const handleEdit = (entryId) => {
    // In a real app, this would likely open a form for editing
    console.log("Editing entry:", entryId);
    // You'd probably navigate to an edit form or open a modal with the currentEntry data
  };

  const handleDelete = (entryId) => {
    // In a real app, this would send a DELETE request to your backend
    // and then re-fetch entries or remove from state upon success
    if (window.confirm("Are you sure you want to delete this entry?")) {
      console.log("Deleting entry:", entryId);
      // Example: Server.deleteBook2Entry(entryId).then(fetchEntries);
      setEntries((prev) => prev.filter((entry) => entry.id !== entryId));
    }
  };

  const handleApprove = (entry) => {
    // In a real app, this would send a PATCH/PUT request to update status on backend
    // e.g., Server.updateBook2EntryStatus(entry.id, 'completed').then(fetchEntries);
    console.log("Approving entry:", entry.id);
    setEntries((prev) =>
      prev.map((e) =>
        e.id === entry.id ? { ...e, status: "completed" } : e
      )
    );
    // After approval, you might want to hide the form or update it
    setCurrentEntry((prev) => ({ ...prev, status: "completed" }));
  };

  const fetchEntries = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await Server.getBook2(office); // Ensure Server.getBook2 sends the 'office' param
      console.log("Fetched Book2 data:", data);
      setEntries(data);
    } catch (err) {
      console.error("Error fetching Book2 entries:", err);
      setError("Failed to fetch records. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEntries();
  }, [office]); // Re-fetch when 'office' prop changes

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          Book 2 Dispatch Register ({office})
        </h2>
      
      </div>

      <div className="overflow-x-auto">
        {showForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setShowForm(false);
                    setCurrentEntry(null); // Clear current entry when going back to list
                  }}
                  className="flex items-center gap-2 text-gray-600"
                >
                  Back to list
                </Button>
              </div>
              {/* Ensure currentEntry has a 'status' field for this to work */}
              {/* If your backend doesn't return 'status', this will need adjustment */}
              {currentEntry?.status === "pending" && ( // Check for 'pending' status
                <div className="flex gap-3">
                  <Button
                    variant="destructive"
                    onClick={() => handleDelete(currentEntry.id)}
                    className="flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Reject
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => handleApprove(currentEntry)} // Pass the whole entry
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </Button>
                </div>
              )}
            </div>
            <div className="mt-4 p-4">
              {/* Pass the specific currentEntry to Book2Pdf */}
              {/* If currentEntry is null (for new entry), Book2Pdf should handle it */}
              <Book2Pdf
                formData={currentEntry}
                onBack={() => setShowForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <>
            {loading && (
              <div className="text-center py-8 text-gray-500">
                Loading records...
              </div>
            )}
            {error && (
              <div className="text-center py-8 text-red-500">
                Error: {error}
              </div>
            )}
            {!loading && !error && entries.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No records found for Book 2 Registers in {office} office.</p>
                <p className="mt-2">Start by adding a new entry.</p>
              </div>
            ) : (
              !loading && !error && (
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        IV No.
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Item Summary
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Issued To
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {entries.map((entry) => (
                      <tr key={entry.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {entry.created_at ? format(new Date(entry.created_at), 'PPP') : 'N/A'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {entry.ivNo}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {/* Displaying first item's name and quantity, or a count */}
                          {entry.items && entry.items.length > 0 ? (
                            <span>
                              {entry.items[0].item_name} ({entry.items[0].quantity})
                              {entry.items.length > 1 && ` +${entry.items.length - 1} more`}
                            </span>
                          ) : (
                            "No items"
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {entry.issuedTo}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                           {/* Assuming 'status' is a field directly on Book2IssueVoucher */}
                           {getStatusBadge(entry.status || 'pending')} {/* Default to pending if not present */}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => viewEntry(entry)}
                            className="flex items-center gap-1"
                          >
                            <Eye className="w-4 h-4" />
                            View
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(entry.id)}
                            className="flex items-center gap-1"
                          >
                            <Edit className="w-4 h-4" />
                            Edit
                          </Button>
                          {/* Conditionally render delete/reject button based on status */}
                          {entry.status === "pending" && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-red-600 border-red-200 hover:bg-red-50"
                              onClick={() => handleDelete(entry.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Book2Register;