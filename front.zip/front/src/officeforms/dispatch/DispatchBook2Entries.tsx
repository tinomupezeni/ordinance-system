import { Button } from "@/components/ui/button";
import { Eye, Printer, Plus } from "lucide-react";
import { useState } from "react";

const Book2DispatchLog = () => {
  const [entries, setEntries] = useState([
    { 
      id: 1, 
      formNumber: "B2/2025/001",
      item: "Batons", 
      unit: "ZRP Avondale", 
      action: "Dispatched", 
      date: "2025-04-05",
      quantity: 15,
      officer: "Sgt. Moyo",
      status: "Completed"
    },
    { 
      id: 2, 
      formNumber: "B2/2025/002",
      item: "Gloves", 
      unit: "ZRP Southerton", 
      action: "Dispatched", 
      date: "2025-04-07",
      quantity: 25,
      officer: "Inspector Chuma",
      status: "Completed"
    },
    { 
      id: 3, 
      formNumber: "B2/2025/003",
      item: "Flashlights", 
      unit: "ZRP Mbare", 
      action: "Pending Dispatch", 
      date: "2025-04-08",
      quantity: 10,
      officer: "Cst. Ndlovu",
      status: "Processing"
    }
  ]);

  const [openEntry, setOpenEntry] = useState(false);
  const [currentEntry, setCurrentEntry] = useState(null);

  const viewEntry = (entry) => {
    setCurrentEntry(entry);
    setOpenEntry(true);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          Book 2 - Dispatch Records
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Printer className="w-4 h-4 mr-1" />
            Print Log
          </Button>
          <Button className="flex items-center gap-1">
            <Plus className="w-4 h-4" />
            New Entry
          </Button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr className="border-b">
              <th className="py-3 px-4 text-left">Form #</th>
              <th className="py-3 px-4 text-left">Item</th>
              <th className="py-3 px-4 text-left">Quantity</th>
              <th className="py-3 px-4 text-left">Unit</th>
              <th className="py-3 px-4 text-left">Officer</th>
              <th className="py-3 px-4 text-left">Action</th>
              <th className="py-3 px-4 text-left">Date</th>
              <th className="py-3 px-4 text-left">Status</th>
              <th className="py-3 px-4 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((entry) => (
              <tr key={entry.id} className="border-b hover:bg-gray-50">
                <td className="py-3 px-4 font-medium">{entry.formNumber}</td>
                <td className="py-3 px-4">{entry.item}</td>
                <td className="py-3 px-4">{entry.quantity}</td>
                <td className="py-3 px-4">{entry.unit}</td>
                <td className="py-3 px-4">{entry.officer}</td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded text-xs ${
                    entry.action === "Dispatched" 
                      ? "bg-green-100 text-green-800" 
                      : "bg-yellow-100 text-yellow-800"
                  }`}>
                    {entry.action}
                  </span>
                </td>
                <td className="py-3 px-4">{entry.date}</td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    entry.status === "Completed" 
                      ? "bg-green-100 text-green-800" 
                      : "bg-blue-100 text-blue-800"
                  }`}>
                    {entry.status}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => viewEntry(entry)}
                    className="flex items-center gap-1"
                  >
                    <Eye className="w-4 h-4" />
                    View
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Entry Detail View Modal */}
      {openEntry && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-2xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">
                Dispatch Record: {currentEntry?.formNumber}
              </h3>
              <Button 
                variant="ghost" 
                onClick={() => setOpenEntry(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                Close
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-500">Item</p>
                <p className="font-medium">{currentEntry?.item}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Quantity</p>
                <p className="font-medium">{currentEntry?.quantity}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Unit</p>
                <p className="font-medium">{currentEntry?.unit}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Officer</p>
                <p className="font-medium">{currentEntry?.officer}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Date</p>
                <p className="font-medium">{currentEntry?.date}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Status</p>
                <p className="font-medium">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    currentEntry?.status === "Completed" 
                      ? "bg-green-100 text-green-800" 
                      : "bg-blue-100 text-blue-800"
                  }`}>
                    {currentEntry?.status}
                  </span>
                </p>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end gap-3">
              <Button variant="outline" onClick={() => setOpenEntry(false)}>
                Close
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Printer className="w-4 h-4 mr-2" />
                Print Record
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Book2DispatchLog;