import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button"; // Assuming you have this Button component
import Form57Pdf from "@/formPdfs/Form57Pdf"; // Import your Form57Pdf component
import Server from "@/server/Server"; // Import your Server API client
import { Eye, Printer, X } from "lucide-react"; // Icons for buttons
import { toast } from "sonner"; // For notifications

// Helper function to format date/time (reused from your previous code)
const formatDateTime = (isoString) => {
  if (!isoString) return "";
  try {
    const date = new Date(isoString);
    const options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false, // Use 24-hour format
    };
    return date.toLocaleDateString("en-GB", options);
  } catch (error) {
    console.error("Error formatting date:", error);
    return isoString;
  }
};

const Form57Ledger = ({ initialForm57s, office }) => {
  // State to hold the list of all Form 57s (or filtered ones)
  const [form57Logs, setForm57Logs] = useState([]);
  // State to control whether the PDF preview for a single form is open
  const [openForm, setOpenForm] = useState(false);
  // State to hold the currently selected Form 57 object for preview
  const [currentForm57, setCurrentForm57] = useState(null);
  // State to hold the data specifically formatted for the PDF component
  const [formDataForPdf, setFormDataForPdf] = useState(null);
  // State for loading indicator
  const [isLoading, setIsLoading] = useState(true);

  // Function to fetch Form 57 logs from the backend
  const getForm57Logs = async () => {
    setIsLoading(true);
    try {
      // Use Server.getAllForm57s with the optional office
      const response = await Server.getAllForm57s(office);
      console.log("Fetched Form 57s:", response);
      // Assuming response has a 'results' field if it's paginated, or is directly the array
      setForm57Logs(response.results || response);
    } catch (error) {
      console.error("Failed to fetch Form 57 logs:", error);
      toast.error("Failed to load Form 57 logs.");
    } finally {
      setIsLoading(false);
    }
  };

  // Effect to fetch logs when the component mounts or filter changes
  useEffect(() => {
    getForm57Logs();
  }, [office]); // Re-fetch if the office prop changes

  // Function to handle viewing a specific Form 57
  const viewForm57 = (id) => {
    const foundForm = form57Logs.find((item) => item.id === id);
    if (foundForm) {
      setCurrentForm57(foundForm);
      setFormDataForPdf(foundForm); // The entire object is typically passed to PDF
      setOpenForm(true); // Open the PDF preview
    } else {
      console.error(`No Form 57 found with id: ${id}`);
      toast.error("Could not find the selected Form 57.");
    }
  };

  // Function to handle printing the current previewed form
  const handlePrint = () => {
    // Form57Pdf component should handle window.print() internally from its onPrint prop
    // We just need to trigger it if the PDF component has an onPrint handler
    if (formDataForPdf) {
      // Assuming Form57Pdf's onPrint calls window.print()
      // If not, you might need to call window.print() directly here
      console.log("Triggering print for Form 57:", formDataForPdf.id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <p>Loading Form 57 logs...</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">
        Form 57 - Ordnance Ledger Cards
      </h2>

      <div className="overflow-x-auto">
        {openForm ? (
          // Render the PDF preview if openForm is true
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <Button
                variant="ghost"
                onClick={() => setOpenForm(false)}
                className="flex items-center gap-2 text-gray-600"
              >
                <X className="w-4 h-4" />
                Back to list
              </Button>
              <Button
                variant="default"
                onClick={handlePrint} // Calls the handlePrint function
                className="flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                Print Form
              </Button>
            </div>

            <div className="mt-4">
              {/* Pass the form data to your PDF component */}
              {formDataForPdf && (
                <Form57Pdf
                  formData={formDataForPdf}
                  onBack={() => setOpenForm(false)} // Allows PDF to signal back
                  onPrint={() => window.print()} // PDF component might use this
                />
              )}
            </div>
          </div>
        ) : (
          // Render the table if openForm is false
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Office
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created At
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {form57Logs.length === 0 ? (
                <tr>
                  <td
                    colSpan="5"
                    className="px-6 py-4 text-center text-gray-500"
                  >
                    No Form 57 entries found.
                  </td>
                </tr>
              ) : (
                form57Logs.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {entry.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {entry.office}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm capitalize text-gray-900">
                      {entry.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatDateTime(entry.created_at)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => viewForm57(entry.id)}
                        className="flex items-center gap-1"
                      >
                        <Eye className="w-4 h-4" />
                        View
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Form57Ledger;
