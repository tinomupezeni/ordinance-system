const form227Returns = [
    { id: 1, officer: "Constable B. Ncube", item: "Helmet", returnedOn: "2025-04-15" },
    { id: 2, officer: "Sergeant L. Dube", item: "Shield", returnedOn: "2025-04-16" },
  ];
  
  const Form227Returns = () => (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Form 227 - Item Returns</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Officer</th>
            <th className="py-2 px-4">Item</th>
            <th className="py-2 px-4">Returned On</th>
          </tr>
        </thead>
        <tbody>
          {form227Returns.map((entry) => (
            <tr key={entry.id} className="hover:bg-gray-50">
              <td className="py-2 px-4">{entry.officer}</td>
              <td className="py-2 px-4">{entry.item}</td>
              <td className="py-2 px-4">{entry.returnedOn}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  export default Form227Returns;
  