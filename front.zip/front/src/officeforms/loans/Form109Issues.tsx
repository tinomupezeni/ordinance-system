import { Button } from "@/components/ui/button";
import Form109Pdf from "@/formPdfs/Form109Pdf";
import { Ban, Check, X } from "lucide-react";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const Form109Issues = () => {
  const [displayRequests, setDisplayRequests] = useState([
    { 
      id: 1, 
      officer: "Constable S. Moyo", 
      item: "Cap STU", 
      dateIssued: "2025-04-10", 
      dueDate: "2025-05-10",
      status: "Pending"
    },
    { 
      id: 2, 
      officer: "Sergeant T. Mutsvangwa", 
      item: "Trousers Pawn", 
      dateIssued: "2025-04-08", 
      dueDate: "2025-05-08",
      status: "Pending"
    },
  ]);

  const [openForm, setOpenForm] = useState(false);
  const [currentForm, setCurrentForm] = useState(null);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showProcessDialog, setShowProcessDialog] = useState(false);
  const [pendingActionId, setPendingActionId] = useState(null);

  const viewForm = (form) => {
    setCurrentForm(form);
    setOpenForm(true);
  };

  const confirmReject = (formId) => {
    setPendingActionId(formId);
    setShowRejectDialog(true);
  };

  const confirmProcess = (formId) => {
    setPendingActionId(formId);
    setShowProcessDialog(true);
  };

  const handleProcess = () => {
    setDisplayRequests(prev =>
      prev.map(req =>
        req.id === pendingActionId ? { ...req, status: "Processed" } : req
      )
    );
    setShowProcessDialog(false);
    setOpenForm(false);
  };

  const handleReject = () => {
    setDisplayRequests(prev =>
      prev.map(req =>
        req.id === pendingActionId ? { ...req, status: "Rejected" } : req
      )
    );
    setShowRejectDialog(false);
    setOpenForm(false);
  };

  return (
    <div className="bg-white p-4 shadow rounded mb-6">
      {/* Confirmation Dialogs */}
      <AlertDialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Rejection</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this stock request? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleReject}
              className="bg-red-600 hover:bg-red-700"
            >
              Confirm Reject
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showProcessDialog} onOpenChange={setShowProcessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Processing</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to process this stock request? Please verify all details before proceeding.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleProcess}
              className="bg-green-600 hover:bg-green-700"
            >
              Confirm Process
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">
          Form 109 - Receipt Voucher
        </h2>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setOpenForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  <X className="w-4 h-4" />
                  Back to list
                </Button>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="destructive"
                  onClick={() => confirmReject(currentForm.id)}
                  className="flex items-center gap-2"
                >
                  <Ban className="w-4 h-4" />
                  Reject Stock
                </Button>
                <Button
                  variant="default"
                  onClick={() => confirmProcess(currentForm.id)}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <Check className="w-4 h-4" />
                  Process Requisition
                </Button>
              </div>
            </div>

            <div className="mt-4">
              <Form109Pdf
                formData={currentForm}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b">
                <th className="py-3 px-4 text-left">Officer</th>
                <th className="py-3 px-4 text-left">Item</th>
                <th className="py-3 px-4 text-left">Issued On</th>
                <th className="py-3 px-4 text-left">Due Date</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayRequests.map((req) => (
                <tr key={req.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{req.officer}</td>
                  <td className="py-3 px-4">{req.item}</td>
                  <td className="py-3 px-4">{req.dateIssued}</td>
                  <td className="py-3 px-4">{req.dueDate}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        req.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : req.status === "Rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {req.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewForm(req)}
                    >
                      View
                    </Button>
                    {req.status === "Pending" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => confirmReject(req.id)}
                        >
                          Reject
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => confirmProcess(req.id)}
                        >
                          Process
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Form109Issues;