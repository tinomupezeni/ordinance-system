import { cn } from "@/lib/utils";
import { Button } from "./ui/button";
import { useEffect, useState } from "react";

interface SummaryCardProps {
  title: string;
  count: number;
  color?: string;
  icon?: React.ReactNode;
  forms?: string;
  notify?: number;
  onViewAll?: () => void;
}

const SummaryCard = ({
  title,
  count,
  color = "bg-gray-100 text-gray-900 border border-gray-300",
  icon,
  forms,
  notify = 0,
  onViewAll,
}: SummaryCardProps) => {
  return (
    <div
      className={cn(
        "p-4 rounded-lg shadow-lg flex items-center justify-between gap-4 min-h-[100px] relative overflow-hidden"
      )}
    >
      <div className="flex items-center z-10">
        {icon && <div className="text-4xl">{icon}</div>}
        <div className="p-5">
          <h2 className="text-normal font-medium uppercase tracking-wide text-gray-600 font-bold">
            {title}
          </h2>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-semibold">{count}</p>
          </div>
        </div>
      </div>
      <Button onClick={onViewAll} className="z-10">
        View All
      </Button>
    </div>
  );
};

export default SummaryCard;
