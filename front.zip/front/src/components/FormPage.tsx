// src/components/FormPage.tsx
import { useParams } from "react-router-dom";
import Form227 from "@/forms/Form227";
import Form163 from "@/forms/Form163";
import MainLedger from "@/forms/Form51B";
import Form321 from "@/forms/Form321";
import Form157 from "@/forms/Form157";
import Form109 from "@/forms/Form109";
import Form99 from "@/forms/Form99";
import Book2 from "@/forms/Book2";
import Form57 from "@/forms/Form57";
import RejectionCertificate from "@/forms/RejectionCertificate";
import DischargeCertificate from "@/forms/DischargeCertificate";
import NotFound from "@/pages/NotFound";
import Form226 from "@/forms/Form226";

const FormPage = () => {
  const { formId } = useParams();

  switch (formId) {
    case "tally-sheet":
      return <MainLedger />;
    case "227":
      return <Form227 />;
    case "226":
        return <Form226 />;
    case "163":
      return <Form163 />;
    case "157":
      return <Form157 />;
    case "57":
      return <Form57 />;
    case "109":
      return <Form109 />;
    case "321":
      return <Form321 />;
    case "99":
      return <Form99 />;
    case "book-2":
      return <Book2 />;
    case "rejection-certificate":
      return <RejectionCertificate />;
    case "discharge-certificate":
      return <DischargeCertificate />;
    default:
      return <NotFound />;
  }
};

export default FormPage;

// RequisitionForm