export const printFormWithStyles = (selector: string) => {
    const element = document.querySelector(selector);
    if (!element) return;
  
    // Create a deep clone of the element including all children
    const clone = element.cloneNode(true) as HTMLElement;
  
    // Get all styles from the document
    const styles = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
      .map(style => {
        if (style.tagName === 'STYLE') {
          return style.innerHTML;
        } else {
          // For external stylesheets, we can try to inline them
          const href = style.getAttribute('href');
          if (href?.endsWith('.css')) {
            return `/* External CSS: ${href} */`;
          }
          return '';
        }
      })
      .join('\n');
  
    // Get computed Tailwind classes
    const tailwindStyles = Array.from(clone.querySelectorAll('*'))
      .map(el => {
        const classes = el.className.split(' ').filter(c => c.startsWith('[') || c.includes(':'));
        return classes.length ? `${el.tagName.toLowerCase()}.${el.className.split(' ').join('.')} { ${window.getComputedStyle(el).cssText} }` : '';
      })
      .filter(Boolean)
      .join('\n');
  
    // Create print window
    const printWindow = window.open('', '_blank', 'width=1000,height=800');
    if (!printWindow) return;
  
    // Write the document content
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print Form</title>
          <style>
            ${styles}
            ${tailwindStyles}
            @page {
              size: A4;
              margin: 0;
            }
            body {
              margin: 0;
              padding: 0;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            ${selector} {
              all: initial;
              display: block !important;
              width: 210mm !important;
              min-height: 297mm !important;
            }
          </style>
        </head>
        <body>
          ${clone.outerHTML}
        </body>
      </html>
    `);
  
    printWindow.document.close();
  
    // Wait for resources to load
    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
        // printWindow.close(); // Uncomment to auto-close after printing
      }, 1000);
    };
  };