import React from "react";

interface StampProps {
  office: string;
}

export const Stamp = ({
  office,
}: StampProps) => {
  const getCurrentDateStamp = () => {
    const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", 
                   "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
    const today = new Date();
    const day = today.getDate();
    const month = months[today.getMonth()];
    const year = today.getFullYear();
    return `${day} ${month} ${year}`;
  };

  return (
   <div className="w-full text-center">
            <div className="relative inline-block border-2 border-blue-600 p-3 ">
              {/* Main stamp content */}
              <div className="text-center">
                <p className="font-bold text-blue-800 uppercase text-sm">
                  Zimbabwe Republic Police
                </p>
                <p className="font-bold text-blue-800 uppercase text-sm">
                  Ordnance
                </p>
                <p className="font-bold text-blue-800 uppercase text-sm mb-2">
                  {office}
                </p>

               
                <p className="font-bold text-blue-800 text-lg">
                  {getCurrentDateStamp()}
                </p>

                <p className="text-blue-800 text-xs mt-1">BAG 123, CAUSEWAY</p>
                <p className="text-blue-800 text-xs">ZIMBABWE</p>
              </div>

              {/* Bottom disclaimer */}
              <p className="text-[6px] text-blue-800 mt-1 italic">
                amended from time to time
              </p>

              {/* Optional stamp effect */}
              <div
                className="absolute inset-0 border-2 border-blue-300 opacity-20 pointer-events-none rounded-md"
                style={{
                  transform: "rotate(2deg)",
                }}
              />
            </div>
          </div>
  );
};