import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { Menu, Printer } from "lucide-react";
import "../css/Form99.css";

// Preview Component (matches PDF layout exactly)
const Form99Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  const row1 = [
    "Aigulette, Gold, Band",
    "Badge Flag Police",
    "Badge Flag Zim",
    " Badge Police G/B",
    "Badges of Rank",
    "Badges, Arm S/cst",
    "Badges, Arm S/cst",
    "Badges, Cap, Emb W/P",
    "Badges, Cap, Shako",
    "Bag, Kit",
    "Bag, Sleeping",
    "Baton",
    "Belt Stable",
    "Belt Stable Chaplain",
    "Belt, Leather",
    "Belt, Web",
    "Blanket",
    "Blouse, Terylene",
    "Boots, Black",
    "Boots, Brown",
    "Boots, Canvas",
    "Boots Greep Sole",
    "Boots riding",
    "Boots Veldskoen",
    "Boots,Combat",
    "Bottle Oil",
    "Breeches Riding",
    "Brooches Force No.",
    "Brush, Cleaning",
    "Buckle",
    "Buttons, Large",
    "Buttons, Medium",
    "Buttons, Small",
    "Cane, Leather",
    "Cap Nurse",
    "Cap, Combat",
    "Cap, Drab",
    "Cap Drab Chaplain",
    "Cap, Dispatch",
    "Cap, F.D. Blue",
    "Cap, Poncho",
    "Cap, STU",
    "Cardigan Blue",
    "Case Pistol Web",
    "Chest Web",
    "Coat rain",
    "Coat Trench",
    "Coat Trench W/P",
    "Coat, Dust White",
    "Cover, Pocket Book",

    "Curtain, Mosquito",
  ];

  const row2 = [
    "Drawers",
    "Dress, W/P, Winter",
    "Dress, W/P., Summer",
    " Epaulettes",
    " Epaulettes, W/P.",
    " Fork, Table",
    " Frog, Bayonet",
    " Frog, Sword",
    " Gauntlets, M/C.",
    " Gloves, Blue, W/P",
    " Gloves, Driving, W/P",
    " Gloves, Leather, Khaki",
    " Gloves, Leather, Unlined",
    " Gloves, White",
    " Gloves Doe Skin",
    " Gloves Nylon",
    " Gloves PVC",
    " Grip canvas",
    " Halyard",
    " Hand cuffs",
    " Hat Blue Chaplain",
    " Hat Blue W/PA",
    "Hat, Soft Blue",
    " Helmet, Crash",
    " Housewife",
    " Identity Card",
    " Jacket and Slack",
    "Jacket Combat",
    " Jacket FD",
    " Jacket Patrol STU",
    " Jacket Riding",
    " Jacket Riot",
    " Jacket riot FPU",
    " Jersey Grey",
    " Kit Cleaning FN",
    " Knife Table",
    " Lamp Police",
    " Lanyard Pistol",
    " Lanyard Purple",
    " Lanyard Whistle",
    " Leggings Leather",
    " Manual First Aid",
  ];

  const row3 = [
    "Mug Steel",
    " Overalls Black",
    " Overalls Blue",
    " Overalls Grey",
    " Overalls Special STU",
    " Overalls White",
    " Pack Back Small",
    " Pantaloons Blue Drill",
    " Pantihose",
    " Peak S/R",
    " Pillow Leather",
    " Plate Steel",
    " Police Investigation Manual",
    " Pouches Magazine",
    " Pull Through Rifle",
    " Puttees Pair",
    " Rifle",
    " Sash S/M",
    "Satchel Blue W/P",
    " Shako Band",
    " Sheet Bed",
    " Shelter Light Weight",
    " Shirt Blue Band",
    " Shirt Combat",
    " Shirt Combat S/S",
    " Shirt, Drab",
    " Shirt, Drab S/S",
    " Shirt, Grey",
    " Shirt, Khaki",
    " Shirt, Tech",
    " Shirt, Tee",
    " Shoes, black",
    " Shoes, Brown",
    " Shoes, Canvas",
    " Shoes, Court",
    " Shorts PT",
    " Shorts, Terylene",
    " Skirt blue CIV",
    " Skirt Summer",
    " Sleeves Traffic",
    " Slips Pillow",
    " Socks Black Pair",
    " Socks Khaki Pair",
    " Spoon Table",
    " Spurs Jack Pair",
    " Stars Gilded",
    " Stars Gilt Embro",
    " Stars Gilt Min",
    " Stairs Min Embro",
    " Stockings BT",
  ];

  const row4 = [
    " Stockings Khaki",
    " Stockings W/P",
    " Suit 3 piece",
    " Suit Bag",
    " Suit Eton",
    " Suit FD",
    " Suit rain jungle green",
    " Suit rain jungle green",
    " Suit riot",
    " Suit Terylene",
    " Suit Track",
    " Suit work",
  ];

  const row5 = [
    " Tabard reflective",
    " Tie Black",
    " Tie Blue",
    " Tin Mess",
    " Titles “A”",
    " Titles Airwing",
    " Titles Z.R.P.",
    " Towel, Hand",
    " Trousers, Combat",
    " Trousers riding",
    " Trousers riot",
    " Trousers riot FPU",
    " Trousers Tetrex",
    " Uniform Grey Nurse",
  ];

  const row6 = [
    " Uniform, F.D., Band",
    " Veil Face",
    " Vest",
    " Visor",
    " Web. Equip. Set 69 patt",
    " Whistle",
  ];

  return (
    <div className="w-[210mm] min-h-[297mm] border border-black mx-auto bg-white p-6 print:p-0 text-black form99pdf">
      {/* Form Header */}
      <div className="text-center mb-4 w-full">
        <div className="flex justify-between align-center w-full ">
          <p className="flex right-0 font-bold">Z.R.P</p>
          <p className="flex right-0 font-bold">FORM 99</p>
        </div>
        <div className="flex">
          <div className="right-head">
            <h1 className="text-xxl font-bold flex justify-center w-[100%] ml-6">
              KIT HANDED IN ON DISCHARGE
            </h1>
            <div className="head-text">
              <p>
                SEE Section 34 OF Chapter 4 and Appendix 21 of Standing Orders
                and <br /> section 52 and Appendix "A"f Special Constabulary
                Orders
              </p>
              <div className="text-start">
                <p>Column "A" Number of Items Handed In.</p>
                <p>Column "B" Number of Items Deficient.</p>
                <p>Column "C" Cost of Deficient Items.</p>
                <p>Column "A" Ordinance Use Only.</p>
              </div>
            </div>
          </div>
          <div className="left-head">
            <div className="flex top">
              <p className="w-[30%]">Force No.</p>
              <p className="w-[40%]">Rank</p>
              <p className="w-[30%]">Name</p>
            </div>
            <div className="flex bottom">
              <p>Station</p>
              <p>Branch</p>
            </div>
          </div>
        </div>
      </div>

      {/* Items Table */}
      <table className="w-full text-xs form227">
        <thead>
          <tr className="">
            <th className="">Description</th>
            <th className="">A</th>
            <th className="">B</th>
            <th className="">C</th>
            <th className="">D</th>
            <th className="">Description</th>
            <th className="">A</th>
            <th className="">B</th>
            <th className="">C</th>
            <th className="">D</th>
            <th className="">Description</th>
            <th className="">A</th>
            <th className="">B</th>
            <th className="">C</th>
            <th className="">D</th>
          </tr>
        </thead>
        <tbody>
          {formData?.items &&
          formData?.items.some((item: any) => item.article !== "")
            ? formData?.items?.map((item: any) => (
                <tr key={item.id}>
                  <td className="h-5">{item?.description}</td>
                  <td className="">{item?.size}</td>
                  <td className="">{item?.noRegd}</td>
                  <td className="">{item?.noIssued}</td>
                  <td className="h-5">{item?.description}</td>
                  <td className="">{item?.size}</td>
                  <td className="">{item?.noRegd}</td>
                  <td className="">{item?.noIssued}</td>
                  <td className="h-5">{item?.description}</td>
                  <td className="">{item?.size}</td>
                  <td className="">{item?.noRegd}</td>
                  <td className="">{item?.noIssued}</td>
                </tr>
              ))
            : Array.from({ length: 15 }).map((_, index) => (
                <tr key={`empty-row-${index}`} className="form-rows">
                  <td className="h-5"></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className=""></td>
                  <td className=""></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className=""></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                  <td className="w-8"></td>
                </tr>
              ))}
        </tbody>
      </table>

      {/* Collection Confirmation */}
      <div className="grid grid-cols-2 w-full ">
        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Requested By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.requestedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.requestedBy?.date}
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Issued By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.issuedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.issuedBy?.date}
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Received By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.receivedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.receivedBy?.date}
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black ">
          <p className="font-bold flex justify-center border-b border-black">
            Ledger Actioned By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.ledgerActionedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.ledgerActionedBy?.date}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form99Pdf;
