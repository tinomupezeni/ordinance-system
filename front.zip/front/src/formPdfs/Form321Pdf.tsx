import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";
import "../css/Form321.css";

// Preview Component (matches PDF layout exactly)
const Form321Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  return (
    <div className="w-[210mm] min-h-[297mm] mx-auto bg-white p-6 print:p-0 text-black form321pdf text-sm">
      {/* Form Header */}
      <div className="text-center mb-4">
        <div className="flex justify-between align-center w-full mb-4 font-bold">
          <p className="flex ">Z.R.P</p>
          <p className="flex font-bold">FORM 321</p>
        </div>
        <div className="flex">
          <h1 className="text-xl font-bold flex  w-[100%] ml-6">
            Initial Report of Missing, <br /> Damaged or Destroyed Equipment
          </h1>
          <div className="border-2 border-black w-[80%] font-sm">
            <p className="text-center">For Use of Prov. Q.</p>
            <p className="align-start">Report No. ............</p>
          </div>
        </div>
      </div>
      <div className="border-b-2 border-black text-sm">
        <div className="mb-4">
          <p className="">
            1. Refer to Section 5 of Part Q1 of Standing Orders Volume II.
          </p>
          <p className="text">
            2. Complete in quadruplicate. Original and two copies to O.C.
            District. One copy to be filed on site.
          </p>
          <p className="text">
            3. Where alternative answers are given, delete inapplicable.
          </p>
        </div>
      </div>

      {/* Header Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 py-4">
        <div>
          <span>
            Province..............................................................................
          </span>
        </div>
        <div>
          <span>
            Station.............................................................................
          </span>
        </div>
      </div>

      <div className="border-b-2 border-black pb-3">
        <p>
          PART I.{" "}
          <span className="font-bold">
            To be completed by person to whom equipment was issue.
          </span>
        </p>
        <div className="ml-12">
          <p>The following equipment has been lost/damaged/destroyed.</p>
          {/* Items Table */}
          <table className="w-full text-xs form321">
            <thead>
              <tr className="">
                <th className="">Description</th>
                <th className="">Number</th>
                <th className="">Value</th>
              </tr>
            </thead>
            <tbody>
              {formData?.items &&
              formData?.items.some((item: any) => item.article !== "")
                ? formData?.items.map((item: any) => (
                    <tr key={item.id}>
                      <td className="">{item.forceNo}</td>
                      <td className="">{item.rank}</td>
                      <td className="">{item.name}</td>
                    </tr>
                  ))
                : Array.from({ length: 4 }).map((_, index) => (
                    <tr key={`empty-row-${index}`} className="">
                      <td className="h-5"></td>
                      <td className="w-28 mx-5"></td>
                      <td className="w-28"></td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between ml-12 pt-2">
          <p>Condition was new/part worn/old</p>
          <p>
            Date of original issue{" "}
            <span>
              ............................................................
            </span>
          </p>
        </div>
        <div className="flex justify-between  pt-2">
          <p>Particulars of person or personas involved:-</p>
          <p>
            Date of loss (approx.){" "}
            <span>
              ...........................................................
            </span>
          </p>
        </div>

        <div>
          <table className="w-full text-xs form321">
            <thead>
              <tr className="">
                <th className="">No.</th>
                <th className="">Rank</th>
                <th className="">Name</th>
                <th className="">Home Station</th>
              </tr>
            </thead>
            <tbody>
              {formData?.items &&
              formData?.items.some((item: any) => item.article !== "")
                ? formData?.items.map((item: any) => (
                    <tr key={item.id}>
                      <td className="">{item.forceNo}</td>
                      <td className="">{item.rank}</td>
                      <td className="">{item.name}</td>
                      <td className="">{item.name}</td>
                    </tr>
                  ))
                : Array.from({ length: 4 }).map((_, index) => (
                    <tr key={`empty-row-${index}`} className="form321-rows">
                      <td className="h-5 w-14"></td>
                      <td className="w-20"></td>
                      <td className="w-30"></td>
                      <td className="w-20"></td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>

        <div className="py-5">
          <p className="ml-12">
            Brief circumstances (concerning loss/damage/destruction; give map
            reference where applicable)
          </p>
          <p>
            ....................................................................................................................................................................................................................................................
          </p>
        </div>
        <div className="ml-12 ">
          {" "}
          <p>I agree/do not agree to refund the value of the equipment</p>
          <p className="flex justify-between">
            <span>
              Date <span>..............................</span>
            </span>
            <span>
              Signed{" "}
              <span>
                ...............................................................
              </span>
            </span>
          </p>
        </div>
      </div>

      <div className="border-b-2 border-black py-5">
        <p>
          PART II.{" "}
          <span className="font-bold">To be completed by an officer.</span>
        </p>
        <div className="ml-12 mt-2">
          <p>
            (a) The circumstances described above are known by me to be true
          </p>
          <p>
            (b) I have no reason to doubt the truth of the circumstances as
            described above.
          </p>
          <p>
            (c) I wish to make the following comment:{" "}
            <span>
              .............................................................................................................................................
            </span>
          </p>
        </div>
        <div className="ml-10">
          <p className="flex justify-between">
            <span>
              Date <span>...................................</span>
            </span>
            <span>
              Signed{" "}
              <span>
                ...............................................................................
              </span>
            </span>
          </p>
          <p className="flex justify-between">
            <span>
              Post held <span>........................</span>
            </span>
            <span>
              Rank{" "}
              <span>
                ..................................................................................
              </span>
            </span>
          </p>
        </div>
      </div>

      <div className="border-b-2 border-black py-5">
        <p>
          PART III.{" "}
          <span className="font-bold">
            To be completed by the O.C. District
          </span>
        </p>
        <div className="ml-12">
          <p>
            (a) I believe/do not believe that there has been a degree of
            negligence in this matter
          </p>
          <p>
            (b) I recommmend the equipment be written off as a minor loss, if
            the depreciated value of the equipment is less than $65
          </p>
          <p>
            (c) I recommend a period of 1 month be awaited as from (date)
            <span>
              .....................................................................................................................................................
            </span>
          </p>
          <p>
            (c) Notwithstanding the members involved agree to refund the value
            of the equipment, I<br /> recommend the Government should pay
            <span>
              .......................................................................
            </span>
          </p>
        </div>
        <div className="pt-3 flex justify-between">
          <p>
            Signed{" "}
            <span>.................................................</span>
          </p>
          <p>
            Date{" "}
            <span>
              .................................................................................................................
            </span>
          </p>
        </div>
      </div>
      <div className="border-b-2 border-black pt-5">
        <p>
          PART IV.{" "}
          <span className="font-bold">
            To be completed by the Provincial Quartermaster.
          </span>
        </p>
        <div className="ml-12">
          <p>
            The depreciated value of the equipment is $
            <span>......................</span>
          </p>
          <p>Arrangements have been made to replace the equipment</p>
          <div className="flex justify-between py-3">
            <p>
              Date <span>........................................</span>
            </p>
            <p>
              Signed{" "}
              <span>
                ...........................................................................................................
              </span>
            </p>
          </div>
        </div>
      </div>
      <div className="border-b-2 border-black pt-5">
        <p>
          PART V.{" "}
          <span className="font-bold">
            To be completed by the O.C. Province.
          </span>
        </p>
        <div className="ml-12">
          <p>(a) It is recommended:-</p>
          <div className="ml-5">
            <p>
              (i) The equipment to be written off as a minor loss (where the
              depreciated value is less than $65).
            </p>
            <p>
              (ii) Loss should be borne by Government to{" "}
              <span>......................</span>%.
            </p>
            <p>
              (iii) <span>.....................</span>% should be borne by
              responsible member/s whp agree to refund the value of the
              equipment.
            </p>
          </div>
          <p>*(b) I have directed that no action be taken for 1 month</p>
          <p> (c) I have convened a Board of Enquiry</p>
        </div>
        <div className="ml-12 pt-4">
          <div className="flex justify-between">
            <p>
              Date <span>............................................</span>
            </p>
            <p>
              Signed{" "}
              <span>
                ...........................................................................................................
              </span>
            </p>
          </div>
          <p>
            * If property not recovered SSO (Q) to be notified by signal of
            action taken
          </p>
        </div>
      </div>
      <div className="border-b-2 border-black pt-5">
        <p>
          PART VI.{" "}
          <span className="font-bold">
            To be completed by SSO (Q). (Tick appropriate instruction)
          </span>
        </p>
        <div className="ml-12 pt-4">
          <p>
            <input type="checkbox" /> Authority is given write off as a minor
            loss
          </p>
          <p>
            <input type="checkbox" /> Return to O.C. Province for convening of
            Board of Enquiry
          </p>
          <p>
            <input type="checkbox" /> Await Board of Equiry. Follow up in 1
            month
          </p>
          <p>
            <input type="checkbox" /> Advice Home Affairs of the loss
          </p>
        </div>
        <div className="ml-10 flex justify-between pt-2">
          <p>
            Date <span>..............................................</span>
          </p>
          <p>
            Signed{" "}
            <span>...............................................................................</span>
          </p>
        </div>
      </div>
      <div className="pt-3">
        <p>
          PART VII.{" "}
          <span className="font-bold">
            To be completed by Quartermaster's Staff
          </span>
        </p>
        <div className="pt-3 ml-12">
          <p>
            (a) Board of Enquiry received <span>......................</span>{" "}
            Home Affairs Advised <span>...........................</span>
          </p>
          <p>
            (b) 1 month period has elapsed. O.C. Prov. requests{" "}
            <span>(i) Equipment be written off;</span>
            <span>(ii) has convened a Board of Enquiry;</span>
            <span>(iii) has notified property has been recovered.</span>
          </p>
        </div>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form321Pdf;
