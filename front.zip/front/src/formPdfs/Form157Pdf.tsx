import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const Form157Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  // In Form157Pdf component
  const items = formData?.items || [];
  const returnedBy = formData?.returnedBy || { initials: "", date: "" };
  const ledgerActionedBy = formData?.ledgerActionedBy || {
    initials: "",
    date: "",
  };

  return (
    <div className="w-[210mm] min-h-[297mm] mx-auto bg-white p-6 print:p-0 text-black form163pdf border border-black mx-auto bg-white text-black">
      {/* Form Header */}
      <div className="text-center mb-4">
        <div className="flex justify-between align-center w-full ">
          <p className="flex right-0">Z.R.P</p>
          <p className="flex right-0">FORM 157</p>
        </div>
        <div className="flex">
          <h1 className="text-xxl font-bold flex justify-center w-[100%] ml-6">
            EXCHANGE VOUCHER
          </h1>
        </div>
      </div>

      {/* Items Table */}
      <table className="w-full text-sm form227">
        <thead>
          <tr className="">
            <th className="">Description</th>
            <th className="">Size</th>
            <th className="">No.</th>
            <th className="">Description</th>
            <th className="">Size</th>
            <th className="">No</th>
          </tr>
        </thead>
        <tbody>
          {formData?.items &&
          formData?.items.some((item: any) => item.article !== "")
            ? formData?.items.map((item: any) => (
                <tr key={item.id} className="form-rows capitalize">
                  <td className="h-10">{item.returnedDescription}</td>
                  <td className="">{item.returnedSize}</td>
                  <td className="">{item.returnedNo}</td>
                  <td className="">{item.issuedDescription}</td>
                  <td className="">{item.issuedSize}</td>
                  <td className="">{item.issuedNo}</td>
                </tr>
              ))
            : Array.from({ length: 15 }).map((_, index) => (
                <tr key={`empty-row-${index}`} className="form-rows">
                  <td className="h-10"></td>
                  <td className="w-14"></td>
                  <td className="w-14"></td>
                  <td className=""></td>
                  <td className="w-14"></td>
                  <td className="w-14"></td>
                </tr>
              ))}
        </tbody>
      </table>

      {/* Collection Confirmation */}
      <div className="grid grid-cols-2 w-full mt-10">
        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Items Returned By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials
                <br /><span className="font-bold uppercase">{formData?.returnedBy?.initials}</span> 
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> <span className="font-bold uppercase">{formData?.returnedBy?.date}</span>
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Ledger Auctioned By
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> <span className="font-bold uppercase">{formData?.ledgerActionedBy?.initials}</span>
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> <span className="font-bold uppercase">{formData?.ledgerActionedBy?.date}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form157Pdf;
