import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const DischargeCertificate = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  return (
    <div className="w-[210mm] min-h-[297mm] mx-auto bg-white p-6 print:p-0 text-black form109pdf">
      {/* Form Header */}
      <div className="text-center mb-4">
        <div className="flex justify-between align-center w-full ">
          <p className="flex right-0 font-bold">Z.R.P Certificate</p>
        </div>
      </div>

      <div className="spacing-2">
        <div className="flex">
          No.{" "}
          {formData.memberInfo.no ? (
            <span className="form-entry">{formData.memberInfo.no}</span>
          ) : (
            <p>...............................</p>
          )}
          <p>
            RANK{" "}
            {formData.memberInfo.rank ? (
              <span className="form-entry">{formData.memberInfo.rank}</span>
            ) : (
              <span>..........................................</span>
            )}
          </p>
          <p>
            NAME{" "}
            {formData.memberInfo.name ? (
              <span className="form-entry">{formData.memberInfo.name}</span>
            ) : (
              <span>.....................................................</span>
            )}
          </p>
        </div>
        <div className="flex-col">
          <p>
            STATION{" "}
            {formData.memberInfo.station ? (
              <span className="form-entry">{formData.memberInfo.station}</span>
            ) : (
              <span>.....................................................</span>
            )}
          </p>
          <p>
            REASON FOR DISCHARGE{" "}
            {formData.dischargeInfo.reasons ? (
              <span className="form-entry">
                {formData.dischargeInfo.reasons}
              </span>
            ) : (
              <span>.....................................................</span>
            )}
          </p>
          <p>
            DATE OF DISCHARGE{" "}
            {formData.dischargeInfo.date ? (
              <span className="form-entry">{formData.dischargeInfo.date}</span>
            ) : (
              <span>.....................................................</span>
            )}
          </p>
        </div>
      </div>

      <div className="t-10">
        <p className="pt-5 pl-10">
          1. <span className="underline">REPAYMENT</span>
        </p>
        <p>
          Certified that recovery is necessary in respect of articles issued on
          repayment to the above meber and which credit voucher had been passed
          to Staff Officer (Finance) as detailed below
        </p>
      </div>
      <div className="w-[50%] ml-10 flex justify-between">
        <span>I.C </span>
        <span>DATE</span>
      </div>
      <div className="w-[65%] ml-10 flex justify-between">
        <span>
          I.V{" "}
          {formData.repaymentInfo.iv ? (
            <span className="form-entry">{formData.repaymentInfo.iv}</span>
          ) : (
            <span>
              ........................................................................................
            </span>
          )}
        </span>
        <span>
          DATE{" "}
          {formData.repaymentInfo.ivDate ? (
            <span className="form-entry">{formData.repaymentInfo.ivDate}</span>
          ) : (
            <span>..................</span>
          )}
        </span>
      </div>

      <div className="ml-20">
        <p>
          a) A.C.V. passed to Staff Officer (Finance) that required confirmation
          that deduction has been effected.
        </p>
        <p className="flex justify-between w-[100%]">
          b)
          <span>
            I.V{" "}
            {formData.repaymentInfo.iv ? (
              <span className="form-entry">{formData.repaymentInfo.iv}</span>
            ) : (
              <span>..................</span>
            )}
          </span>
          <span>
            DATE{" "}
            {formData.repaymentInfo.ivDate ? (
              <span className="form-entry">
                {formData.repaymentInfo.ivDate}
              </span>
            ) : (
              <span>............................................. </span>
            )}
          </span>
          <span>
            TOTAL{" "}
            {formData.repaymentInfo.total ? (
              <span className="form-entry">{formData.repaymentInfo.total}</span>
            ) : (
              <span>............................................. </span>
            )}
          </span>
        </p>
        <p>
          Certified that there are no outstanding issue on repayment to above
          member for which credit voucher has not been passed to Staff Officer
          (Finance)
        </p>
        <p className="py-5 text-center">I/C CLOTHING SECTION</p>
      </div>

      <div>
        <p className="pl-10">
          2. <span className="underline">KIT DEFICIENCES</span>
        </p>
        <p>
          I have been advised by Officer In charge Ordnance that the above
          member has handed in kit and equipment in terms of appendices 19, 20,
          21 Standing orders and that:
        </p>
        <div className="ml-20">
          <p className="flex">
            a).{" "}
            <span className="ml-10">
              THE ARTICLES LISTED ....................................
            </span>
            <span>DATE...............................................</span>
          </p>
          <p className="ml-14">
            For the sum of $<span>...........................</span>are
            deficiencies or unserviceable
          </p>
          <p>
            b).
            <span className="ml-10">
              There are no deficiencies. No recovery action therefore required.
            </span>
          </p>
          <p>
            Certified that there are no outstanding issue on repayment to above
            member for which credit voucher has not been passed to Staff Officer
            (Finance)
          </p>
        </div>
        <p>DATE..........................</p>
      </div>

      <div>
        <p className="underline">SUMMARY</p>
        <div className="flex justify-between">
          <p>KIT ON REPAYMENTS STOPPAGE VIDE PARA 1</p>
          <p>
            $<span>.................</span>C
          </p>
        </div>
        <div className="flex justify-between">
          <p>DEFICIENCES VIDE PARA 2</p>
          <p>.....................</p>
        </div>
      </div>

      {/* Collection Confirmation */}

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default DischargeCertificate;
