import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const Form163Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);


  return (
    <div className="w-[210mm] min-h-[297mm] border border-black mx-auto bg-white p-6 print:p-0 text-black form163pdf">
      {/* Form Header */}
      <div className="text-center mb-4">
        <div className="flex space-between align-center w-full ">
          {/* <p className="flex right-0">Z.R.P</p> */}
          <p className="flex right-0">FORM 163</p>
        </div>
        <div className="flex">
          <h1 className="text-xxl font-bold flex justify-center w-[100%] ml-6">
            REQUISITION ON BULK STORE
          </h1>
        </div>
      </div>

      {/* Items Table */}
      <table className="w-full text-sm form227">
        <thead>
          <tr className="">
            <th className="">Description</th>
            <th className="">Size</th>
            <th className="">
              No <br />
              Reqd.
            </th>
            <th className="">
              No <br /> Issued
            </th>
          </tr>
        </thead>
        <tbody>
          {formData?.items &&
          formData?.items.some((item: any) => item.article !== "")
            ? formData?.items?.map((item: any) => (
                <tr key={item.id} className="form-rows">
                  <td className="h-5">{item?.description}</td>
                  <td className="">{item?.size}</td>
                  <td className="">{item?.noRegd}</td>
                  <td className="">{item?.noIssued}</td>
                </tr>
              ))
            : Array.from({ length: 15 }).map((_, index) => (
                <tr key={`empty-row-${index}`} className="form-rows">
                  <td className="h-5"></td>
                  <td className="w-14"></td>
                  <td className="w-14"></td>
                  <td className="w-14"></td>
                </tr>
              ))}
        </tbody>
      </table>

      {/* Collection Confirmation */}
      <div className="grid grid-cols-2 w-full text-sm">
        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Requested By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.requestedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.requestedBy?.date}
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Issued By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.issuedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.issuedBy?.date}
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black">
          <p className="font-bold flex justify-center border-b border-black">
            Received By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.receivedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.receivedBy?.date}
              </span>
            </div>
          </div>
        </div>

        <div className="border border-black ">
          <p className="font-bold flex justify-center border-b border-black">
            Ledger Actioned By:
          </p>
          <div className="flex h-20">
            <div className="w-[60%] border-r border-black">
              <span className="px-4 py-1 block">
                Initials:
                <br /> {formData?.ledgerActionedBy?.initials}
              </span>
            </div>
            <div className="w-[40%]">
              <span className="px-4 py-1 block">
                Date
                <br /> {formData?.ledgerActionedBy?.date}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form163Pdf;
