import { printWithTailwind } from "react-tailwind-printer";
import Form227Pdf from "./Form227Pdf";

const ParentComponent = ({ formData }) => {
  const printWithTailwind = printWithTailwind();

  return (
    <>
      <Form227Pdf formData={formData} onBack={function (): void {
              throw new Error("Function not implemented.");
          } } onPrint={function (): void {
              throw new Error("Function not implemented.");
          } } />
      <button
        onClick={() =>
          printWithTailwind({
            title: "Form 227",
            component: <Form227Pdf formData={formData} />,
          })
        }
      >
        Print
      </button>
    </>
  );
};

export default ParentComponent