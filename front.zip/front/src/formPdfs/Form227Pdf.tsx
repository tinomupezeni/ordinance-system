import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { Menu, Printer } from "lucide-react";
import { useRef } from "react";
import { Stamp } from "./Stamp";

// Preview Component (matches PDF layout exactly)
const Form227Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData?: any;
  onBack: () => void;
  onPrint: () => void;
}) => {

  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    onPrint?.();
    const printWindow = window.open("", "_blank");
    if (printWindow && printRef.current) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Print Form</title>
            <style>
              @page {
                size: A4;
                margin: 0;
              }
              body {
                margin: 0;
                padding: 0;
              }
            </style>
          </head>
          <body>
            ${printRef.current.innerHTML}
          </body>
        </html>
      `);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
        printWindow.close();
      }, 500);
    }
  };

  return (
    <>
      <div>
        <div className="w-[210mm] min-h-[297mm] border border-black mx-auto bg-white p-6 print:p-0 text-black formpdf">
          {/* Form Header */}
          <div className="text-center mb-4">
            <div className="w-full flex justify-between">
              <p></p>
              <p className="flex right-0">FORM 227</p>
            </div>
            <div className="flex">
              <h1 className="text-xl font-bold flex justify-between w-[100%] ml-6">
                POLICE ORDINANCE STORE <br />
                REQUISITION — ISSUE VOUCHER
              </h1>
              <div className="flex justify-between mt-2 text-sm right-0 border border-4 border-black w-[400px]">
                <span className="border-r border-black w-[50px]"></span>
                <span className="px-4 py-1">
                  Ordinance Control No.
                  <br /> {formData?.ordinance_control_no}
                </span>
              </div>
            </div>
          </div>

          {/* Station and Branch */}
          <div className="flex justify-between mb-4 text-sm-custom w-full">
            <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[40%] mr-4">
              <span className="px-4 py-1 mx-auto">
                Station:
                <br /> {formData?.station}
              </span>
            </div>
            <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[30%] mr-4">
              <span className="px-4 py-1 mx-auto">
                Branch:
                <br /> {formData?.branch}
              </span>
            </div>
            <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[40%] mr-4">
              <span className="px-4 py-1 mx-auto text-center">
                To be
                <br />
                <span className="font-bold">{formData?.dispatch_method}</span>
              </span>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full text-sm form227">
            <thead>
              <tr className="">
                <th className="">Force No.</th>
                <th className="">Rank</th>
                <th className="">NAME</th>
                <th className="">
                  Articles Required (One line for <br /> each item in
                  alphabetical order)
                </th>
                <th className="">
                  Size <br /> Reqd.
                </th>
                <th className="">
                  No <br />
                  Reqd.
                </th>
                <th className="reqdNo reqdHead">
                  Apprvd. <br /> or date <br /> due
                </th>
                <th className="issued issuedHead">
                  No <br /> Issued
                </th>
                <th className="last-column">
                  Signature of <br />
                  Individual <br /> Members
                </th>
              </tr>
            </thead>
            <tbody>
              {formData?.items &&
              formData?.items.some((item: any) => item.article !== "")
                ? formData?.items.map((item: any, index) => (
                    <tr key={item.id} className="form-rows">
                      <td className="">{item.force_no}</td>
                      <td className="">{item.rank}</td>
                      <td className="">{item.name}</td>
                      <td className="">
                        {index + 1}. {item.article}
                      </td>
                      <td className="">{item.size}</td>
                      <td className="">{item.regd_no}</td>
                      <td className="reqdNoBorder w-[59px]">{item.date_due}</td>
                      <td className="issued">{item.issued}</td>
                      <td className="last-column">{item.signature}</td>
                    </tr>
                  ))
                : Array.from({ length: 15 }).map((_, index) => (
                    <tr key={`empty-row-${index}`} className="form-rows">
                      <td className=""></td>
                      <td className=""></td>
                      <td className=""></td>
                      <td className="">{index + 1}</td>{" ."}
                      {/* Numbered articles */}
                      <td className=""></td>
                      <td className=""></td>
                      <td className="reqdNo"></td>
                      <td className="issued"></td>
                      <td className="last-column"></td>
                    </tr>
                  ))}
            </tbody>
          </table>

          {/* Collection Confirmation */}
          <div className="flex top-input-field">
            <div>
              <div className="mr-3">
                <div className="text-sm ">
                  <p className="mb-2 font-bold right-p">
                    ALL ITEMS LISTED ABOVE HAVE BEEN COLLECTED FROM THE
                    ORDINANCE STORE
                  </p>
                  <div className="">
                    <span className="dotted">
                      ............................................................................................................................................
                    </span>
                    <span>
                      BY <br />
                      No.{" "}
                      {formData?.collectedBy?.no ? (
                        formData?.collectedBy?.no
                      ) : (
                        <span>.............................</span>
                      )}{" "}
                      Rank{" "}
                      {formData?.collectedBy?.rank ? (
                        formData?.collectedBy?.rank
                      ) : (
                        <span>...........................</span>
                      )}{" "}
                      Name{" "}
                      {formData?.collectedBy?.name ? (
                        formData?.collectedBy?.name
                      ) : (
                        <span>
                          ............................................................
                        </span>
                      )}
                    </span>
                  </div>
                </div>

                {/* Replacement Section */}
                <div className="replacement_section border border-gray-800 mb-4 mt-2 text-sm">
                  <h2 className="font-bold text-center w-full py-0">
                    REPLACEMENT BEFORE EXPIRY OF PERIOD OF SERVICEABILITY
                  </h2>
                  <table className="w-full text-sn form227">
                    <thead>
                      <tr className="">
                        <th className="">Item No.</th>
                        <th className="">Life</th>
                        <th className="">Date of Issue</th>
                        <th className="">Brief Reasons for Unserviceability</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formData?.replacement_items &&
                      formData?.replacement_items.some(
                        (item: any) => item.article !== ""
                      )
                        ? formData?.replacement_items.map((item: any) => (
                            <tr key={item.id} className="form-rows">
                              <td className="">{item.id}</td>
                              <td className="">{item.life}</td>
                              <td className="">{item.date_due}</td>
                              <td className="">{item.reason}</td>
                            </tr>
                          ))
                        : Array.from({ length: 5 }).map((_, index) => (
                            <tr
                              key={`empty-row-${index}`}
                              className="form-rows"
                            >
                              <td className="h-5"></td>
                              <td className=""></td>
                              <td className=""></td>
                              <td className="last-column"></td>
                            </tr>
                          ))}
                    </tbody>
                  </table>
                  <div className="pt-1 text-sm">
                    <h2 className="font-bold text-center text-xs">
                      Recommendations of Officer/Member-in-Charge
                    </h2>
                    <p className="mb-1 px-1">
                      Items referred to in this part to be replaced at
                      Government expense / at Member's expense <br />
                      at{" "}
                      {formData?.OfficerRecommendation?.expenseType ? (
                        formData?.OfficerRecommendation.expenseType
                      ) : (
                        <span>............................</span>
                      )}
                      % of cost*
                    </p>
                    <div className="flex justify-between px-1">
                      <span>
                        No. <span>............................</span>Rank{" "}
                        <span>{formData?.OfficerRecommendation?.rank}</span>
                      </span>
                      <span>
                        Signature{" "}
                        <span>
                          ..................................................
                        </span>
                      </span>
                    </div>
                    <p className="text-xs mt-1 text-center">
                      *Delete inapplicable
                    </p>
                  </div>
                </div>
              </div>

              {/* Verification Section */}
              <div className="flex text-sm w-[100%]">
                <div className="border border-black  w-[50%]">
                  <div className="text-center">
                    <p className="font-bold">
                      Checked by Officer/Member-in-Charge{" "}
                    </p>
                    <span className="text-xs">(All Requisitions)</span>
                  </div>
                  <div className="flex flex-col justify-between mt-1">
                    <span>
                      Signed
                      ........................................................
                    </span>
                    <span>
                      No.{" "}
                      <span>
                        {formData?.checkedByOfficer?.no || (
                          <span>..........................</span>
                        )}
                      </span>{" "}
                      Rank{" "}
                      <span>
                        {formData?.checkedByOfficer?.rank || (
                          <span>.........................</span>
                        )}
                      </span>
                    </span>
                  </div>
                  {/* Date Stamps */}
                  <div className="pb-2 text-center text-sm">
                    <div className="pt-2 ">
                      <p className="font-bold">
                        DATE STAMP <br />{" "}
                      </p>
                     
                      <Stamp office=""/>
                    </div>
                  </div>
                </div>
                <div className="border border-black w-[50%] py-1">
                  <div className="text-center">
                    <p className="font-bold">
                      Checked by Quartermaster's Representative
                    </p>
                    <span className="text-xs">
                      (Items on Station Charge Only)
                    </span>
                  </div>
                  <div className="flex flex-col justify-between mt-1">
                    <span>
                      Signed <span>{}</span>
                      .............................................................
                    </span>
                    <span>
                      No.{" "}
                      <span>
                        {formData?.checkedByQuartermaster?.no || (
                          <span>..........................</span>
                        )}
                      </span>{" "}
                      Rank{" "}
                      {formData?.checkedByQuartermaster?.rank || (
                        <span>..........................</span>
                      )}
                    </span>
                  </div>
                  <div className="pb-2 text-center text-sm">
                    <div className="pt-2 ">
                      <p className="font-bold">
                        DATE STAMP <br />{" "}
                      </p>
                      <Stamp office=""/>
                      {/* <span className="test-sm">(Top Copy Only)</span> */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* {right box inputs} */}
            <div className=" right-fields">
              {/* Right section */}
              <div className="flex items-center justify-between total-cost px-2">
                <div className="text-start">
                  <p className="font-bold">Total</p>
                  <p className="flex">
                    Issued:{" "}
                    <span className="ml-3">{formData?.items?.length}</span>
                  </p>
                </div>
                <p className="w-24 "></p>
                <div className="flex flex-col items-center gap-1">
                  <span className="h-1 bg-black w-20"></span>
                  <span className="h-1 bg-black w-20"></span>
                  <span className="h-1 bg-black w-20"></span>
                </div>
              </div>
              <div className=" flex-1 ">
                <div className="right-field-groups">
                  <div className="right-box">
                    <p>Voucher Checked By</p>
                    <div className="field-group">
                      <div>
                        <span>
                          Initials:
                          <br />
                          {formData?.voucherCheckedBy?.initials}
                        </span>
                      </div>
                      <div>
                        <span>
                          Date
                          <br />
                          {formData?.voucherCheckedBy?.date}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="right-box">
                    <p>Items Selected By</p>
                    <div className="field-group">
                      <div>
                        <span>
                          Initials:
                          <br />
                          {formData?.itemsSelectedBy?.initials}
                        </span>
                      </div>
                      <div>
                        <span>
                          Date
                          <br />
                          {formData?.itemsSelectedBy?.date}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="right-box">
                    <p>Method of Issue/Despatch</p>
                    <div className="field-group">
                      <div className="grid grid-cols-2 gap-2 w-full">
                        {formData?.methodOfIssue ? (
                          <label>
                            {formData?.methodOfIssue}
                            <input
                              type="checkbox"
                              className="ml-1"
                              checked
                              readOnly
                            />
                          </label>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  <div className="right-box">
                    <p className="text-start border-none">Parcel/Warrant No.</p>
                    <div className="field-group">
                      <div>
                        <span>{formData?.collectedByNo}</span>
                      </div>
                    </div>
                  </div>

                  <div className="right-box">
                    <p>Items Packed By</p>
                    <div className="field-group">
                      <div>
                        <span>
                          Initials:
                          <br />
                          {formData?.itemsPackedBy?.initials}
                        </span>
                      </div>
                      <div>
                        <span>
                          Date
                          <br />
                          {formData?.itemsPackedBy?.date}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="right-box">
                    <p>Entered on Clothing Card</p>
                    <div className="field-group">
                      <div>
                        <span>
                          Initials:
                          <br />
                          {formData?.enteredOnClothingCard?.initials}
                        </span>
                      </div>
                      <div>
                        <span>
                          Date
                          <br />
                          {formData?.enteredOnClothingCard?.date}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="right-box">
                    <p>Ledger Actioned</p>
                    <div className="field-group">
                      <div>
                        <span>
                          Initials
                          <br />
                          {formData?.ledgerActioned?.initials}
                        </span>
                      </div>
                      <div>
                        <span>
                          Date
                          <br />
                          {formData?.ledgerActioned?.date}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Action Buttons (hidden when printing) */}
        <div className="flex justify-between mt-6 no-print w-[50%] mx-auto">
          <Button variant="outline" onClick={onBack}>
            Back to Edit
          </Button>
          <Button onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" />
            Print Form
          </Button>
        </div>
      </div>
    </>
  );
};

export default Form227Pdf;
