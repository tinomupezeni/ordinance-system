import api from "../lib/axiosInstance";
import { BASE_URL } from "../constants";

async function refreshTokenHandler(refreshToken: string) {
  const response = await fetch(`${BASE_URL}/api/refresh/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ refreshToken }),
  });

  if (!response.ok) {
    throw new Error("Failed to refresh token");
  }

  const data = await response.json();
  localStorage.setItem("accessToken", data.accessToken);
  localStorage.setItem("refreshToken", data.refreshToken);
  return data.accessToken;
}

// Generic request function
async function request(endpoint: string, method = "GET", body?: any) {
  let accessToken = localStorage.getItem("accessToken");
  const refreshToken = localStorage.getItem("refreshToken");

  const makeRequest = async (token: string) => {
    const headers: HeadersInit = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };

    const options: RequestInit = {
      method,
      headers,
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    return fetch(`${BASE_URL}${endpoint}`, options);
  };

  try {
    let response = await makeRequest(accessToken || "");

    // Handle 401 by trying refresh token
    if (response.status === 401 && refreshToken) {
      try {
        const newAccessToken = await refreshTokenHandler(refreshToken);
        localStorage.setItem("accessToken", newAccessToken);
        response = await makeRequest(newAccessToken);
      } catch (refreshError) {
        // Clear tokens and redirect if refresh fails
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        window.location.href = "/login"; // Redirect to login page
        throw new Error("Session expired. Please login again.");
      }
    }

    // Handle other error cases
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));

      if (response.status === 401) {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        window.location.href = "/login";
        throw new Error("Authentication failed. Please login again.");
      }

      throw new Error(
        errorData.message ||
          errorData.detail ||
          `Request failed with status ${response.status}`
      );
    }

    return response.json();
  } catch (error) {
    console.error("API request failed:", error);
    throw error;
  }
}

console.log(BASE_URL);
const Server = {
  //   addForm157: (formDataToPass: any) => request("/api/form157/", "POST", formDataToPass),
  getAllSystemUsers: () => request("/api/users/", "GET"),
  updateUserStatus: (userId: string, newStatus: string) =>
    api.patch(`/users/${userId}/status/`, { status: newStatus }),

  addForm163: (completeformData: any) =>
    api.post("/form163/", completeformData),
  addForm157: (formDataToPass: any) => api.post("/form157/", formDataToPass),
  getForm157: (office) => api.post(`/form157/list/${office}`),
  addForm321: (completeFormData: any) =>
    api.post("/form321/", completeFormData),
  addForm109: (completeFormData: any) =>
    api.post("/form109/", completeFormData),
  addForm227: (completeFormData: any) =>
    api.post("/form227/", completeFormData),
  // addForm226: (completeFormData: any) => api.post('/form226/', completeFormData),
  // Sure
  addDischargeCertificate: (formData: any) =>
    api.post("/discharge-certificate/", formData),
  addRejectionCertificate: (formData: any) =>
    api.post("/rejection-certificate/", formData),
  addBook2: (formData: any) => api.post("/book2-issue-voucher/", formData),
  getBook2: (office) => request(`/api/book2-issue-voucher/${office}/`, "GET"),

  getStats: () => request("/api/stats/", "GET"),
  getForms227AdminAuth: () =>
    request("/api/requisition-voucher/list/admin-authorization/", "GET"),
  getForms163AdminAuth: () =>
    request("/api/form163/list/admin-authorization/", "GET"),
  addAnotherForm: (anotherFormData: any) =>
    request("/api/another-form/", "POST", anotherFormData),
  getUserProfile: () => request("/api/profile/", "GET"),
  getForm227: (formId: any) => request("/form227/", "POST", formId),
  getIssuesFormCount: () => request("/api/forms/counts/", "GET"),
  getStockCount: () => request("/api/clothing-items-stock/", "GET"),
  getForms: (forms: any) => request(`/api/forms/${forms}/`, "GET"),
  getAllForm163s: () => request(`/api/form163/list/`, "GET"),
  authorizeForm227: (formId: any) =>
    request(`/api/form227/admin-authorization/${formId}/`, "PATCH", {
      status: "approved",
    }),
  authorizeForm163: (formId: any) =>
    request(`/api/form163/admin-authorization/${formId}/`, "PATCH", {
      status: "approved",
    }),
  rejectForm163: (formId: any, reason) =>
    request(`/form163/${formId}/reject/`, "PATCH", {
      rejection_reason: reason,
    }),
  cardingAuthorizeForm227: (formId: any) =>
    request(`/api/form227/carding-authorization/${formId}/`, "PATCH", {
      status: "approved",
    }),
  // Add more endpoints easily

  // Clothing items
  addNewClothingItem: (anotherFormData: any) =>
    request("/api/add-clothing-item/", "POST", anotherFormData),
  getAllClothingItem: () => request("/api/all-clothing-items/", "GET"),

  // In your Server module (where cardingAuthorizeForm227 is defined)
  deleteClothingItem(category: string, item?: string) {
    if (item) {
      // Delete specific item from category
      return request(
        `/api/clothing-items/${category}/items/${item}/`,
        "DELETE"
      );
    } else {
      // Delete entire category
      return request(`/api/clothing-items/${category}/`, "DELETE");
    }
  },

  // --- New Officer and related APIs ---

  /**
   * Adds a new Officer with nested issuances and issued items.
   * @param {object} officerData - The data for the officer, including nested issuances.
   * Example: { forceNo: 'rees', gender: 'M', dateAttested: '2025-06-13', branch: 're', name: 'erd', ... }
   * Make sure keys like 'forceNo', 'dateAttested', 'sccNo', 'certClNo' are used as per the backend's expected input.
   * For issuances, ensure 'issuedBy', 'issuedByDate', 'issuedBySignature' and 'items' (with 'item' for clothing item name) are correctly structured.
   */
  addOfficer: (officerData: any) =>
    // request("/api/officers/", "POST", officerData),
    request("/api/officer-data/", "POST", officerData),

  /**
   * Retrieves all officers.
   */
  getAllOfficers: () => request("/api/officers/", "GET"),

  /**
   * Retrieves a single officer by their force number.
   * @param {string} forceNo - The force number of the officer to retrieve.
   */
  getOfficerByForceNo: (forceNo: string) =>
    request(`/api/officers/${forceNo}/`, "GET"),

  /**
   * Updates an existing officer by their force number.
   * @param {string} forceNo - The force number of the officer to update.
   * @param {object} officerData - The updated data for the officer.
   */
  updateOfficer: (forceNo: string, officerData: any) =>
    request(`/api/officers/${forceNo}/`, "PUT", officerData),

  /**
   * Partially updates an existing officer by their force number.
   * @param {string} forceNo - The force number of the officer to partially update.
   * @param {object} officerData - The partial updated data for the officer.
   */
  patchOfficer: (forceNo: string, officerData: any) =>
    request(`/api/officers/${forceNo}/`, "PATCH", officerData),

  /**
   * Deletes an officer by their force number.
   * @param {string} forceNo - The force number of the officer to delete.
   */
  deleteOfficer: (forceNo: string) =>
    request(`/api/officers/${forceNo}/`, "DELETE"),

  // Issuance specific endpoints (if you need to manage them independently)
  /**
   * Retrieves all issuances.
   */
  getAllIssuances: () => request("/api/issuances/", "GET"),

  /**
   * Retrieves a single issuance by its ID.
   * @param {number} issuanceId - The ID of the issuance to retrieve.
   */
  getIssuanceById: (issuanceId: number) =>
    request(`/api/issuances/${issuanceId}/`, "GET"),

  // ClothingItem specific endpoints (if you need to manage them independently,
  // beyond what addNewClothingItem and getAllClothingItem provide)
  /**
   * Retrieves all clothing items.
   * (This might overlap with getAllClothingItem depending on your exact backend setup for that endpoint)
   */
  getAllClothingItemsDRF: () => request("/api/clothing_items/", "GET"),

  /**
   * Retrieves a single clothing item by its ID.
   * @param {number} itemId - The ID of the clothing item to retrieve.
   */
  getClothingItemByIdDRF: (itemId: number) =>
    request(`/api/clothing_items/${itemId}/`, "GET"),

  // Create a new Form 57
  createForm57: async (formData: any) =>
    request(`/api/form57/`, "POST", formData), // Corrected: Added "POST" method

  // Get a single Form 57 by ID
  getForm57: async (formId: number) => request(`/api/form57/${formId}/`, "GET"), // Corrected: Added "GET" method explicitly, removed redundant body arg

  // Update an existing Form 57 by ID
  updateForm57: async (formId: number, formData: any) =>
    request(`/api/form57/${formId}/`, "PUT", formData), // Corrected: Added "PUT" method

  // (Optional) Get all Form 57s
  getAllForm57s: async (office?: string) => {
    // Modified to accept an optional 'office' parameter
    let endpoint = `/api/form57/`;
    if (office) {
      endpoint += `?office=${encodeURIComponent(office)}`; // Append as query parameter
    }
    return request(endpoint, "GET");
  },
};

export default Server;
