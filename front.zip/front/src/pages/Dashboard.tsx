import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import InventoryCard from "@/components/InventoryCard";
import { formatDate } from "@/lib/utils";
import IncomingStockEntryForm from "@/officeforms/receivingbay/IncomingStockEntryForm";
import Book2Register from "@/officeforms/issues/Book2Register";
import Form227IssuanceLog from "@/officeforms/issues/Form227Issuance";
import {
  FileText,
  BookOpenCheck,
  FileClock,
  FileCheck,
  ClipboardList,
  Truck,
  AlertTriangle,
  Search,
  Plus,
  X,
} from "lucide-react";
import PendingForm51Requests from "@/officeforms/issues/PendingForm51Requests";
import Book2Entries from "@/officeforms/loans/Book2Entries";
import Form227Returns from "@/officeforms/loans/Form227Returns";
import Form109Issues from "@/officeforms/loans/Form109Issues";
// import Form57Ledger from "@/officeforms/loans/Form57Ledger";
import Form57 from "@/forms/Form57";
import SummaryCard from "@/components/SummaryCard";
import PendingForm163s from "@/officeforms/cadex/PendingForm163";
import { useEffect, useMemo, useState } from "react";
import Form227Transactions from "@/officeforms/cadex/DamagedStock227";
import PendingForm109s from "@/officeforms/cadex/PendingForm109s";
import TallySheetRecord from "@/officeforms/cadex/TallySheetRecord";
import TransferHistory157 from "@/officeforms/cadex/TransferHistory157";
import { Button } from "@/components/ui/button";
import Form57Ledger from "@/officeforms/loans/Form57Ledger";
import TransferLog157 from "@/officeforms/bulkstores/TransferLog157";
import Form163Dispatches from "@/officeforms/dispatch/Form163Dispatches";
import Form227 from "@/forms/Form227";
import Form163 from "@/forms/Form163";
import Server from "@/server/Server";
import Form227DispatchReturns from "@/officeforms/dispatch/Form227DispatchReturns";
import Forms109Issue from "@/officeforms/issues/Forms109Issue";
// --- NEW IMPORTS FOR AUDIT OFFICE ---
import AuditDiscrepancyReport from "@/officeforms/audit/AuditDiscrepancyReport"; // We'll create this component
// --- END NEW IMPORTS ---
import CardingDash from "@/officeforms/carding/CardingDash";
import Form157 from "@/forms/Form157";
import IssuesDashboard from "@/officeforms/issues/IssuesDashboard";

const Dashboard = () => {
  // Current date
  const today = new Date();

  const [activeForm, setActiveForm] = useState<string | null>(null);
  const [dashboardData, setDashboardData] = useState();
  const [forms227, setForms227] = useState([]);
  const [forms163, setForms163] = useState([]);
  const [allClothingItems, setAllClothingItems] = useState([]);
  const [form57, setForms57] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);

  const handleViewAll = (formType: string) => {
    setActiveForm(formType);
  };

  const handleFetchForm227 = () => {
    Server.getIssuesFormCount()
      .then((response) => {
        setDashboardData(response);
        console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getForm163s = () => {
    Server.getAllForm163s().then((response) => {
      console.log(response);
      setForms163(response);
    });
  };

  const getForm227 = () => {
    Server.getForms("form227")
      .then((response) => {
        setForms227(response.results);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getForm57 = (office) => {
    Server.getAllForm57s(office)
      .then((response) => {
        console.log(response);

        setForms57(response);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getAllClothingItem = () => {
    Server.getAllClothingItem()
      .then((response) => {
        setAllClothingItems(response);
        // console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // --- NEW FUNCTION TO FETCH INVENTORY ITEMS WITH STOCK ---
  const getInventoryItemsWithStock = async () => {
    try {
      // Assuming Server.get is configured to handle the new API endpoint
      // You might need to adjust the path based on your DRF setup (e.g., 'api/clothing-items-stock/')
      const response = await Server.getStockCount();
      setInventoryItems(response); // Assuming response is directly the array of items
      console.log("Fetched inventory items with stock:", response);
    } catch (error) {
      console.error("Error fetching inventory items with stock:", error);
    }
  };

  useEffect(() => {
    getForm227();
    handleFetchForm227();
    getAllClothingItem();
    getForm163s();
    getInventoryItemsWithStock();
  }, []);

  // const updateDashboardData = () => {
  //   getAllClothingItem();
  // };

  const updateDashboardData = () => {
    getAllClothingItem();
    getInventoryItemsWithStock(); // Also update stock when dashboard data is updated
  };

  // --- MODIFIED: Dynamic inventoryRows based on fetched data ---
  // Use useMemo to prevent re-creating this array on every render if data hasn't changed
  const displayInventoryRows = useMemo(() => {
    // Determine the color based on quantity thresholds (customize as needed)
    const getItemColor = (count: number) => {
      if (count < 200) return "red"; // Low stock
      if (count < 500) return "yellow"; // Medium stock
      return "green"; // Good stock
    };

    // Determine a simple icon based on item name (this is a basic example, ideally use a mapping)
    const getItemIcon = (name: string) => {
      if (name.toLowerCase().includes("trouser")) return "pants";
      if (name.toLowerCase().includes("jacket")) return "jacket";
      if (name.toLowerCase().includes("cap")) return "cap";
      if (name.toLowerCase().includes("shirt")) return "shirt";
      if (name.toLowerCase().includes("jersey")) return "jersey";
      return "default"; // Fallback icon
    };

    // Transform fetched inventoryItems into rows of 3 for display
    const rows = [];
    for (let i = 0; i < inventoryItems.length; i += 3) {
      rows.push(
        inventoryItems.slice(i, i + 3).map((item) => ({
          title: item.name,
          count: item.total_stock, // Use the total_stock from the API
          color: getItemColor(item.total_stock),
          icon: getItemIcon(item.name),
        }))
      );
    }
    return rows;
  }, [inventoryItems]); // Re-calculate only when inventoryItems changes

  const dispatchSummary = [
    {
      title: "Book2",
      count: 12,
      icon: <BookOpenCheck />,
      color: "bg-blue-50",
    },
    {
      title: "Form 163",
      count: dashboardData?.form163?.total,
      icon: <FileClock />,
      color: "bg-green-50",
    },
    {
      title: "Form 227",
      count: dashboardData?.form227?.total,
      icon: <FileText />,
      color: "bg-purple-50",
      notify: 2,
    },
  ];

  const dischargeSummary = [
    {
      title: "ZRP Certificate Entries",
      count: 7,
      icon: <FileText />,
      color: "bg-gray-50",
    },
    {
      title: "Pending Form 51",
      count: 2,
      icon: <FileCheck />,
      color: "bg-gray-50",
    },
    {
      title: "Book2 Entries",
      count: 4,
      icon: <BookOpenCheck />,
      color: "bg-gray-50",
    },
  ];

  const bulkSummary = [
    {
      title: "Form 163 - Requisition Requests",
      count: dashboardData?.form163?.total,
      icon: <FileText />,
      color: "bg-green-50",
      forms: "Form163Dispatches",
    },
    {
      title: "Form 109 - Incoming New Stock",
      count: dashboardData?.form109?.total,
      icon: <FileCheck />,
      color: "bg-purple-50",
      forms: "Form109",
    },
    {
      title: "Form 57",
      count: 2,
      icon: <FileCheck />,
      color: "bg-blue-50",
      forms: "Form57",
    },
    {
      title: "Form 157",
      count: 2,
      icon: <FileCheck />,
      color: "bg-yellow-50",
      forms: "Form157",
    },
  ];

  const auditSummary = [
    {
      title: "Form 163 (Requisitions)",
      count: dashboardData?.form163?.total,
      icon: <FileClock />,
      color: "bg-blue-50",
      forms: "Form163",
    },
    {
      title: "Form 227 (Issue/Return Vouchers)",
      count: dashboardData?.form227?.total,
      icon: <FileText />,
      color: "bg-green-50",
      forms: "Form227",
    },
    {
      title: "Form 109 (Receipt Vouchers)",
      count: dashboardData?.form109?.total,
      icon: <FileCheck />,
      color: "bg-purple-50",
      forms: "Form109",
    },
    {
      title: "Form 57 (Ledger Cards)",
      count: dashboardData?.form57?.total || 0,
      icon: <ClipboardList />,
      color: "bg-yellow-50",
      forms: "Form57",
    },
  ];

  const loansSummary = [
    {
      title: "Book2 Entries",
      count: 8,
      icon: <BookOpenCheck />,
      color: "bg-purple-50",
      forms: "Book2",
    },
    {
      title: "Form 227 Returns",
      count: 5,
      icon: <FileText />,
      color: "bg-blue-50",
      forms: "Form227",
    },
    {
      title: "Form 57 - Ledger Cards",
      count: 3,
      icon: <FileCheck />,
      color: "bg-green-50",
      forms: "Form57",
    },
    {
      title: "Form 109 - Receipt Voucher",
      count: 4,
      icon: <FileClock />,
      color: "bg-yellow-50",
      forms: "Form109",
    },
    {
      title: "Overdue Items",
      count: 2, // This will be dynamically calculated
      icon: <AlertTriangle className="text-red-500" />,
      color: "bg-red-50",
      forms: "Overdue",
      isOverdue: true, // Flag to indicate this is the overdue card
    },
  ];

  const office = localStorage.getItem("office");

  const renderDashboardContent = (office: string | null) => {
    switch (office) {
      case "Officer in Charge":
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-2"></div>
            <h1 className="font-bold text-lg">Current Stock levels</h1>
            {/* Use displayInventoryRows which is populated from API */}
            {displayInventoryRows.length === 0 ? (
              <p className="text-center py-8 text-gray-500">
                Loading inventory data or no items found...
              </p>
            ) : (
              displayInventoryRows.map((row, rowIndex) => (
                <div
                  key={rowIndex}
                  className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6"
                >
                  {row.map((item, itemIndex) => (
                    <InventoryCard
                      key={itemIndex}
                      title={item.title}
                      count={item.count}
                      color={item.color}
                      lastUpdated="24 Hours" // You might want to get this from API too
                      icon={item.icon}
                    />
                  ))}
                </div>
              ))
            )}
          </>
        );
      case "Receiving Bay":
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6 mt-5"></div>
            <IncomingStockEntryForm />
          </>
        );

      case "Bulk Officer":
        // Map form keys to components
        const [activeBulkForm, setActiveBulkForm] = useState("Form57Input");

        const formComponents = {
          Form57Input: (
            <>
              <h1 className="font-bold uppercase mb-5">Ledger Card Form 57</h1>
              <Form57
                formId={undefined}
                onSubmissionSuccess={undefined}
                formType={"BULK"}
              />
            </>
          ),

          Form51: <PendingForm51Requests />,
          Book2: <Book2Register />,
          Form227: <Form227IssuanceLog />,
          Form157: <TransferHistory157 />,
          Form57: <Form57Ledger office={"BULK"} form57={form57} />,
          Form163Dispatches: <Form163Dispatches forms163={forms163} />,
          Form109: <Forms109Issue />,
        };

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6 mt-5">
              {bulkSummary.map((item, idx) => (
                <SummaryCard
                  key={idx}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  forms={item.forms}
                  onViewAll={() => setActiveBulkForm(item.forms)}
                />
              ))}
            </div>
            <Button
              variant={activeBulkForm === "Form57Input" ? "default" : "outline"}
              onClick={() => setActiveBulkForm("Form57Input")}
            >
              Ledger Card [Form 57]
            </Button>
            {/* Conditionally render forms based on activeForm */}
            <div className="mt-5">{formComponents[activeBulkForm]}</div>
          </>
        );

      case "Issues Officer":
        return (
          <>
            <IssuesDashboard dashboardData={dashboardData}/>
          </>
        );

      case "Discharge Officer":
        const [activeDischargeForm, setActiveDischargeForm] = useState<
          string | null
        >(null);

        const handleDischargeViewAll = (formType: string) => {
          setActiveDischargeForm(formType);
        };

        const dischargeForms = {
          "ZRP Certificate Entries": <div>ZRP Certificate Form</div>, // Replace with actual component
          "Pending Form 51": <PendingForm51Requests />,
          "Book2 Entries": <Book2Register />,
        };

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
              {dischargeSummary.map((item, idx) => (
                <SummaryCard
                  key={idx}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  onViewAll={() => handleDischargeViewAll(item.title)}
                />
              ))}
            </div>

            {activeDischargeForm && dischargeForms[activeDischargeForm]}
          </>
        );

      case "Loans Officer":
        const [activeLoansForm, setActiveLoansForm] = useState<string | null>(
          null
        );

        // Sample data for overdue items - in a real app this would come from your API
        const overdueItems = [
          {
            id: 101,
            officer: "Constable T. Banda",
            item: "Jacket Mat",
            dueDate: "2025-05-01",
            daysOverdue: 18,
          },
          {
            id: 102,
            officer: "Sergeant K. Ndlovu",
            item: "Trousers Mat",
            dueDate: "2025-05-05",
            daysOverdue: 14,
          },
        ];

        const loansSummaryWithOverdue = loansSummary.map((item) => {
          if (item.isOverdue) {
            return {
              ...item,
              count: overdueItems.length, // Update count with actual overdue items
            };
          }
          return item;
        });

        const handleLoansViewAll = (formType: string) => {
          setActiveLoansForm(formType);
        };

        const loansForms = {
          Book2: <Book2Entries />,
          Form227: <Form227Returns />,
          Form57: <Form57 />,
          Form109: <Form109Issues />,
          Overdue: (
            <div className="bg-white p-4 shadow rounded">
              <h2 className="text-lg font-semibold mb-4">Overdue Loan Items</h2>
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr className="border-b">
                    <th className="py-3 px-4 text-left">Officer</th>
                    <th className="py-3 px-4 text-left">Item</th>
                    <th className="py-3 px-4 text-left">Due Date</th>
                    <th className="py-3 px-4 text-left">Days Overdue</th>
                  </tr>
                </thead>
                <tbody>
                  {overdueItems.map((item) => (
                    <tr key={item.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">{item.officer}</td>
                      <td className="py-3 px-4">{item.item}</td>
                      <td className="py-3 px-4">{item.dueDate}</td>
                      <td className="py-3 px-4 text-red-600">
                        {item.daysOverdue}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ),
        };

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-6 mt-5">
              {loansSummaryWithOverdue.map((item, idx) => (
                <SummaryCard
                  key={idx}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  forms={item.forms}
                  onViewAll={() => handleLoansViewAll(item.forms)}
                />
              ))}
            </div>

            {/* Conditionally render forms based on activeLoansForm */}
            {activeLoansForm && loansForms[activeLoansForm]}
          </>
        );

      case "Dispatch Officer":
        const [activeDispatchForm, setActiveDispatchForm] = useState<
          string | null
        >(null);

        const handleDispatchViewAll = (formType: string) => {
          setActiveDispatchForm(formType);
        };

        const dispatchForms = {
          "Book2 Entries": <Book2Entries />,
          "Form 163": <PendingForm163s />,
          "Form 227": <Form227DispatchReturns items={forms227} />,
        };

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
              {dispatchSummary.map((item, idx) => (
                <SummaryCard
                  key={idx}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  notify={item.notify}
                  onViewAll={() => handleDispatchViewAll(item.title)}
                />
              ))}
            </div>
            <div>
              {activeDispatchForm ? (
                <Button
                  onClick={() => setActiveDispatchForm(null)}
                  className="my-5"
                >
                  Requisition Voucher [Form 163]
                </Button>
              ) : (
                <>
                  <h1 className="font-bold uppercase my-5 ">
                    Requisition Form 163
                  </h1>

                  <Form163
                    formType="Request from Dispatch"
                    // onBack={() => setActiveForm("Form227")}
                  />
                </>
              )}
            </div>
            {activeDispatchForm && dispatchForms[activeDispatchForm]}
          </>
        );

      case "Kardex Officer":
        const [activeCadexForm, setActiveCadexForm] = useState<string | null>(
          null
        );

        const handleCadexViewAll = (formType: string) => {
          setActiveCadexForm(formType);
        };

        const cadexData = [
          {
            title: "Form 227",
            count: dashboardData?.form227?.total,
            icon: <FileText />,
            color: "bg-purple-50",
            notify: 2,
          },
          {
            title: "Form 109",
            count: dashboardData?.form109?.total,
            color: "bg-yellow-100 border border-yellow-200",
            icon: <FileClock className="text-yellow-500" />,
            formType: "Pending Form 109s",
          },
          {
            title: "Form 163",
            count: dashboardData?.form163?.total,
            color: "bg-orange-100 border border-orange-200",
            icon: <FileCheck className="text-orange-500" />,
            formType: "Pending Form 163s",
          },
          {
            title: "Tally Sheets",
            count: 2,
            color: "bg-green-100 border border-green-200",
            icon: <ClipboardList className="text-green-500" />,
            formType: "Tally Sheet Records",
          },
          {
            title: "Form 57",
            count: 2,
            color: "bg-purple-100 border border-purple-200",
            icon: <Truck className="text-purple-500" />,
            formType: "Transfer History (Form 157)",
          },
        ];

        const cadexForms = {
          Form57Input: (
            <>
              <h1 className="font-bold uppercase mb-5">Ledger Card Form 57</h1>
              <Form57
                formId={undefined}
                onSubmissionSuccess={undefined}
                formType={"KARDEX"}
              />
            </>
          ),
          "Form 227": <Form227Transactions items={forms227} />,
          "Form 109": <PendingForm109s />,
          "Form 163": <Form163Dispatches forms163={forms163} />,
          "Tally Sheet Records": <TallySheetRecord />,
          "Transfer History (Form 157)": <TransferHistory157 />,
        };

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-6 mt-5">
              {cadexData.map((item, index) => (
                <SummaryCard
                  key={index}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  notify={item.notify}
                  onViewAll={() => handleCadexViewAll(item.title)}
                />
              ))}
            </div>
            <Button
              variant={
                activeCadexForm === "Form57Input" ? "default" : "outline"
              }
              onClick={() => setActiveCadexForm("Form57Input")}
            >
              Ledger Card [Form 57]
            </Button>

            {activeCadexForm && cadexForms[activeCadexForm]}
          </>
        );

      case "Stores Officer":
        const [activeStoresForm, setActiveStoresForm] = useState<string | null>(
          null
        );

        const handleStoresViewAll = (formType: string) => {
          setActiveStoresForm(formType);
        };

        const [selectedOption, setSelectedOption] = useState("loans");

        const storesForms = {
          "Form 227": <Form227Transactions items={undefined} />,
          Book2: <Book2Entries />,
          "Form 57": <Form57 />,
        };

        const storesData = [
          {
            title: "Form 227",
            count: dashboardData?.form227?.total,
            color: "bg-blue-100 border border-blue-200",
            icon: <FileText className="text-blue-500" />,
            formType: "Form 227",
          },
          {
            title: "Book 2/ I.V",
            count: 8,
            color: "bg-purple-100 border border-purple-200",
            icon: <BookOpenCheck className="text-purple-500" />,
            formType: "Book2",
          },
          {
            title: "Form 57",
            count: 12,
            color: "bg-green-100 border border-green-200",
            icon: <FileCheck className="text-green-500" />,
            formType: "Form 57",
          },
        ];

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6 mt-5">
              {storesData.map((item, index) => (
                <SummaryCard
                  key={index}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  onViewAll={() => handleStoresViewAll(item.formType)}
                />
              ))}
            </div>
            <div>
              {activeStoresForm ? (
                <Button
                  onClick={() => setActiveStoresForm(null)}
                  className="my-5"
                >
                  Issue Voucher [Form 227]
                </Button>
              ) : (
                <>
                  <div className="p-4">
                    <h1 className="font-bold uppercase text-xl mb-6 text-gray-800">
                      Stock Transfer Form 227
                    </h1>

                    <div className="flex space-x-4">
                      <button
                        className={`px-4 py-2 rounded-md font-medium transition-colors
        ${
          selectedOption === "loans"
            ? "bg-blue-600 text-white"
            : "bg-gray-200 text-gray-700 hover:bg-gray-300"
        }`}
                        onClick={() => setSelectedOption("loans")}
                      >
                        Loans
                      </button>

                      <button
                        className={`px-4 py-2 rounded-md font-medium transition-colors
        ${
          selectedOption === "stock"
            ? "bg-blue-600 text-white"
            : "bg-gray-200 text-gray-700 hover:bg-gray-300"
        }`}
                        onClick={() => setSelectedOption("stock")}
                      >
                        Stock Transfer
                      </button>
                    </div>
                  </div>
                  <Form227 formType={selectedOption} />
                </>
              )}
            </div>

            {activeStoresForm && storesForms[activeStoresForm]}
          </>
        );

      case "Carding Officer":
        return (
          <CardingDash
            allClothingItems={allClothingItems}
            dashboardData={dashboardData}
            forms227={forms227}
            updateDashboardData={updateDashboardData}
          />
        );
      // --- NEW CASE FOR AUDIT OFFICE ---
      case "Audit Office": {
        const [activeAuditForm, setActiveAuditForm] = useState<string | null>(
          null
        );

        const auditFormComponents = {
          Form163: <Form163Dispatches forms163={forms163} />, // All Form 163s
          Form227: <Form227IssuanceLog items={forms227} />, // All Form 227s
          Form109: <PendingForm109s />, // All Form 109s (incoming)
          Form57: <Form57Ledger />, // All Form 57s (ledger)
          DiscrepancyReport: (
            <AuditDiscrepancyReport forms163={forms163} forms227={forms227} />
          ), // New component for discrepancy reporting
        };

        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-6 mt-5">
              {auditSummary.map((item, idx) => (
                <SummaryCard
                  key={idx}
                  title={item.title}
                  count={item.count}
                  color={item.color}
                  icon={item.icon}
                  onViewAll={() => setActiveAuditForm(item.forms)}
                />
              ))}
            </div>

            <div className="space-x-4 my-5">
              {/* Optional: Add quick access buttons for common audit tasks */}
              <Button
                variant={
                  activeAuditForm === "DiscrepancyReport"
                    ? "default"
                    : "outline"
                }
                onClick={() => setActiveAuditForm("DiscrepancyReport")}
              >
                <AlertTriangle className="w-4 h-4 mr-2" /> Review Discrepancies
              </Button>
              {/* You could add more buttons here like "Compare Forms" */}
            </div>

            <div className="mt-5">
              {activeAuditForm ? (
                <>
                  <Button
                    onClick={() => setActiveAuditForm(null)}
                    className="my-5"
                  >
                    <X className="w-4 h-4 mr-2" /> Back to Audit Dashboard
                  </Button>
                  {auditFormComponents[activeAuditForm]}
                </>
              ) : (
                <p className="text-gray-600">
                  Select a section above to start auditing.
                </p>
              )}
            </div>
          </>
        );
      }
      // --- END NEW CASE
      default:
        return <p>You are all good!</p>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex top-20">
        <Sidebar />
        <main className="flex-1 flex-1 p-6 ml-72 mt-20">
          <div className="flex-col justify-between items-center mb-6">
            <h1 className="text-xl font-semibold mb-4">
              {formatDate(today, "MMM d, yyyy")}
            </h1>
            <h1 className="text-xl font-bold bg-yellow-200 text-gray-800 px-4 py-2 rounded shadow inline-block">
              {office} Dashboard
            </h1>
          </div>
          {renderDashboardContent(office)}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
