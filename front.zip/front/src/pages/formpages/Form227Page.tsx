import { Loader } from "lucide-react";
import Server from "@/server/Server"; // Make sure this path is correct
import { useEffect, useState } from "react";
import { toast } from "sonner"; // Assuming you have sonner for toasts
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import Form227 from "@/forms/Form227";

const Form227Page = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* You can uncomment and use Header and Sidebar if they are part of your layout */}
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 ml-64 mt-20">
          <h1 className="font-bold uppercase mb-5">
            Individual Officers Form 227
          </h1>
          <Form227 formType={undefined} />
        </main>
      </div>
    </div>
  );
};

export default Form227Page;
