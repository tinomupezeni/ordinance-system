import React from 'react'

export default function MainLayout() {
  return (
    <div>
        
    </div>
  )
}
