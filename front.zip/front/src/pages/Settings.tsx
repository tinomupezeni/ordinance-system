import { Settings, User, Lock, Bell, Database, Users, Key } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SettingsPage = () => {
  return (
    <div className="">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-blue-950 flex items-center">
            <Settings className="mr-2" size={24} />
            System Settings
          </h1>
          <p className="text-gray-600 mt-1">
            Manage your account preferences and system configuration
          </p>
        </div>

        <div className="space-y-6">
          {/* Profile Settings */}
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <User className="mr-2 text-blue-600" size={20} />
              <h2 className="text-lg font-semibold">Profile Settings</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" defaultValue="John" />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" defaultValue="Doe" />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue="john.doe@zrp.gov" />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" defaultValue="+263 77 123 4567" />
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <Button variant="outline" className="mr-2">
                Cancel
              </Button>
              <Button className="bg-blue-950 hover:bg-blue-900">
                Update Profile
              </Button>
            </div>
          </Card>

          {/* Security Settings */}
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <Lock className="mr-2 text-blue-600" size={20} />
              <h2 className="text-lg font-semibold">Security</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Two-Factor Authentication</Label>
                  <p className="text-sm text-gray-500">
                    Add an extra layer of security to your account
                  </p>
                </div>
                <Switch id="2fa" />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Password</Label>
                  <p className="text-sm text-gray-500">
                    Last changed 3 months ago
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Change Password
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Session Timeout</Label>
                  <p className="text-sm text-gray-500">
                    Automatically log out after period of inactivity
                  </p>
                </div>
                <Select defaultValue="30">
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Select timeout" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>

          {/* Notification Preferences */}
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <Bell className="mr-2 text-blue-600" size={20} />
              <h2 className="text-lg font-semibold">Notifications</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>System Notifications</Label>
                  <p className="text-sm text-gray-500">
                    Important updates about the system
                  </p>
                </div>
                <Switch id="system-notifications" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-gray-500">
                    Receive notifications via email
                  </p>
                </div>
                <Switch id="email-notifications" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>SMS Alerts</Label>
                  <p className="text-sm text-gray-500">
                    Critical alerts via SMS
                  </p>
                </div>
                <Switch id="sms-alerts" />
              </div>
            </div>
          </Card>

          {/* System Configuration (Admin Only) */}
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <Database className="mr-2 text-blue-600" size={20} />
              <h2 className="text-lg font-semibold">System Configuration</h2>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label>Data Retention Policy</Label>
                <Select defaultValue="365">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select retention period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                    <SelectItem value="180">180 days</SelectItem>
                    <SelectItem value="365">1 year</SelectItem>
                    <SelectItem value="730">2 years</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500 mt-1">
                  How long to keep historical records
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Audit Logging</Label>
                  <p className="text-sm text-gray-500">
                    Record all system activities
                  </p>
                </div>
                <Switch id="audit-logging" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Maintenance Mode</Label>
                  <p className="text-sm text-gray-500">
                    Temporarily disable system access
                  </p>
                </div>
                <Switch id="maintenance-mode" />
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <Button className="bg-blue-950 hover:bg-blue-900">
                Save System Configuration
              </Button>
            </div>
          </Card>

          {/* Dangerous Zone */}
          <Card className="p-6 border-red-200 bg-red-50">
            <div className="flex items-center mb-4">
              <Key className="mr-2 text-red-600" size={20} />
              <h2 className="text-lg font-semibold text-red-800">Danger Zone</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <Label className="text-red-800">Delete Account</Label>
                  <p className="text-sm text-red-600">
                    Permanently remove your account and all data
                  </p>
                </div>
                <Button variant="destructive">Delete Account</Button>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <Label className="text-red-800">Reset System</Label>
                  <p className="text-sm text-red-600">
                    Wipe all data and restore to factory settings
                  </p>
                </div>
                <Button variant="destructive">Reset System</Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;