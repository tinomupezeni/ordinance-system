import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form57Pdf from "@/formPdfs/Form57Pdf";
import Server from "@/server/Server"; // Make sure this import is correct

// --- Re-iterating Type Definitions (from previous successful interaction) ---
type LedgerEntry = {
  id?: number; // Optional for new entries, required for existing ones
  date: string;
  voucher: string;
  receipts: string | number | null; // Allow string from input, convert to number or null for API
  issues: string | number | null;
  balance: string | number | null;
  outstanding_orders: string; // Match backend field name
};

type FormDataForAPI = {
  description: string;
  price: number | null; // Changed to number | null as we convert strings
  reorder_level: number | null;
  reorder_amount: number | null;
  office: string; // Match backend field name
  ledger_entries: LedgerEntry[]; // Match backend field name
};

type Form57DataFromAPI = {
  id: number;
  description: string;
  price: number;
  reorder_level: number;
  reorder_amount: number;
  office: string;
  ledger_entries: LedgerEntry[];
  created_by: number;
  created_at: string;
  updated_at: string;
};

// Define a type for your clothing item (as transformed)
type TransformedClothingItem = {
  id: string; // Unique ID for each item, e.g., "Badges-Hat-Emb."
  name: string; // The actual article name, e.g., "Hat Emb."
  category: string; // The category, e.g., "Badges"
  sizes: string[]; // Placeholder for sizes, can be empty if not provided by backend
};

const Form57 = ({ formId, onSubmissionSuccess, formType }) => {
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [reorderLevel, setReorderLevel] = useState("");
  const [reorderAmount, setReorderAmount] = useState("");
  const [entries, setEntries] = useState<LedgerEntry[]>([
    {
      id: 1, // Frontend local ID for unique keying
      date: "",
      voucher: "",
      receipts: "",
      issues: "",
      balance: "",
      outstanding_orders: "",
    },
  ]);

  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState<Form57DataFromAPI | null>(null);

  const [isEditMode, setIsEditMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // --- States for Article Search Functionality ---
  const [allClothingItems, setAllClothingItems] = useState<TransformedClothingItem[]>([]);
  const [articleSuggestions, setArticleSuggestions] = useState<TransformedClothingItem[]>([]);
  const [isArticleInputFocused, setIsArticleInputFocused] = useState(false); // To control dropdown visibility

  // --- Effect to Fetch All Clothing Items and Load Form Data ---
  useEffect(() => {
    // Function to fetch and transform clothing items
    const fetchAndTransformClothingItems = async () => {
      try {
        const response = await Server.getAllClothingItem(); // Assuming this fetches the nested object
        if (response && typeof response === 'object' && !Array.isArray(response)) {
          const transformedData: TransformedClothingItem[] = Object.entries(response).flatMap(
            ([category, itemsArray]) => {
              if (Array.isArray(itemsArray)) {
                return itemsArray.map((itemName, index) => ({
                  id: `${category}-${itemName.replace(/\s+/g, '-')}-${index}`, // Generate unique ID
                  name: itemName,
                  category: category,
                  sizes: [], // Placeholder; if backend provides sizes, add them here
                }));
              }
              return [];
            }
          );
          setAllClothingItems(transformedData);
        } else {
          console.warn("API response for clothing items was not an object:", response);
          setAllClothingItems([]); // Fallback to empty array
        }
      } catch (error) {
        console.error("Error fetching all clothing items:", error);
        setAllClothingItems([]); // Ensure it's an array even on error
      }
    };

    fetchAndTransformClothingItems(); // Call it immediately when component mounts

    // Logic for loading existing form data if formId is present
    if (formId) {
      setIsEditMode(true);
      setIsLoading(true);
      Server.getForm57(formId)
        .then((response: Form57DataFromAPI) => {
          setDescription(response.description);
          setPrice(response.price.toString());
          setReorderLevel(response.reorder_level.toString());
          setReorderAmount(response.reorder_amount.toString());

          const loadedEntries = response.ledger_entries.map((entry, index) => ({
            ...entry,
            id: entry.id || (index + 1),
          }));

          if (loadedEntries.length > 0 && Object.values(loadedEntries[loadedEntries.length - 1]).some(v => v !== "" && v !== null)) {
            setEntries([...loadedEntries, { id: loadedEntries.length + 1, date: "", voucher: "", receipts: "", issues: "", balance: "", outstanding_orders: "" }]);
          } else if (loadedEntries.length > 0) {
            setEntries(loadedEntries);
          } else {
            setEntries([{ id: 1, date: "", voucher: "", receipts: "", issues: "", balance: "", outstanding_orders: "" }]);
          }

          setPreviewData(response);
          setIsLoading(false);
        })
        .catch((error) => {
          toast.error("Failed to load Form 57 for editing.");
          console.error("Error loading Form 57:", error);
          setIsLoading(false);
          setIsEditMode(false);
        });
    } else {
      setIsEditMode(false);
      setEntries([
        {
          id: 1,
          date: "",
          voucher: "",
          receipts: "",
          issues: "",
          balance: "",
          outstanding_orders: "",
        },
      ]);
    }
  }, [formId]); // Depend on formId to refetch if it changes

  // --- Article Search Handlers (adapted from previous example) ---
  const handleDescriptionInputChange = (value: string) => {
    setDescription(value); // Update the description state

    if (value.trim() === "") {
      setArticleSuggestions([]); // Clear suggestions if input is empty
      return;
    }

    // Filter allClothingItems based on user input for description
    const filtered = allClothingItems.filter((clothingItem) =>
      clothingItem.name.toLowerCase().includes(value.toLowerCase())
    );
    setArticleSuggestions(filtered);
  };

  const handleArticleSelect = (selectedArticle: TransformedClothingItem) => {
    setDescription(selectedArticle.name); // Set the description to the selected article name
    setArticleSuggestions([]); // Clear suggestions after selection
    setIsArticleInputFocused(false); // Hide the dropdown
  };

  // --- Other existing handlers (handleEntryChange, handleSubmit, etc.) ---
  const handleEntryChange = (
    id: number,
    field: keyof LedgerEntry,
    value: string
  ) => {
    setEntries((prev) => {
      const updatedEntries = prev.map((entry) =>
        entry.id === id ? { ...entry, [field]: value } : entry
      );

      const lastEntry = updatedEntries[updatedEntries.length - 1];
      const isLastEntryCompleteEnoughToAddNew =
        (lastEntry.date && lastEntry.date !== "") ||
        (lastEntry.voucher && lastEntry.voucher !== "") ||
        (lastEntry.receipts !== "" && lastEntry.receipts !== null) ||
        (lastEntry.issues !== "" && lastEntry.issues !== null) ||
        (lastEntry.balance !== "" && lastEntry.balance !== null) ||
        (lastEntry.outstanding_orders && lastEntry.outstanding_orders !== "");

      if (isLastEntryCompleteEnoughToAddNew && id === lastEntry.id) {
        return [
          ...updatedEntries,
          {
            id: prev.length > 0 ? (prev[prev.length - 1].id! + 1) : 1, // Use `!` for non-null assertion or add a check
            date: "",
            voucher: "",
            receipts: "",
            issues: "",
            balance: "",
            outstanding_orders: "",
          },
        ];
      }
      return updatedEntries;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const submittedEntries = entries.filter(
      (entry) =>
        entry.date ||
        entry.voucher ||
        entry.receipts ||
        entry.issues ||
        entry.balance ||
        entry.outstanding_orders
    ).map(entry => ({
      id: entry.id,
      date: entry.date,
      voucher: entry.voucher,
      receipts: entry.receipts === "" ? null : Number(entry.receipts),
      issues: entry.issues === "" ? null : Number(entry.issues),
      balance: entry.balance === "" ? null : Number(entry.balance),
      outstanding_orders: entry.outstanding_orders,
    }));

    const payload: FormDataForAPI = {
      description,
      price: price === "" ? null : Number(price),
      reorder_level: reorderLevel === "" ? null : Number(reorderLevel),
      reorder_amount: reorderAmount === "" ? null : Number(reorderAmount),
      office: formType,
      ledger_entries: submittedEntries,
    };

    console.log("Payload being sent to backend:", payload);

    try {
      let response: Form57DataFromAPI;
      if (isEditMode && formId) {
        response = await Server.updateForm57(formId, payload);
        toast.success("Form 57 updated successfully!");
      } else {
        response = await Server.createForm57(payload);
        toast.success("Form 57 submitted successfully!");
      }
      setPreviewData(response);
      setShowPreview(true);
      if (onSubmissionSuccess) {
        onSubmissionSuccess(response.id);
      }
    } catch (error) {
      toast.error("Failed to submit Form 57. Please try again.");
      console.error("Form 57 submission error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleResetForm = () => {
    setDescription("");
    setPrice("");
    setReorderLevel("");
    setReorderAmount("");
    setEntries([
      {
        id: 1,
        date: "",
        voucher: "",
        receipts: "",
        issues: "",
        balance: "",
        outstanding_orders: "",
      },
    ]);
    setShowPreview(false);
    setPreviewData(null);
    setIsEditMode(false);
    toast.info("Form has been reset");
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-96">Loading Form 57...</div>;
  }

  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 57 - ORDNANCE LEDGER CARD
                </p>
                {formType && <p className="text-md text-gray-700 mt-2">Office: {formType}</p>}
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Item Information */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <Label htmlFor="description">Description</Label>
                    {/* Article Input with Suggestions */}
                    <div className="relative">
                      <Input
                        id="description" // Keep original ID for label association
                        value={description}
                        onChange={(e) => handleDescriptionInputChange(e.target.value)}
                        onFocus={() => setIsArticleInputFocused(true)}
                        onBlur={() =>
                          setTimeout(() => setIsArticleInputFocused(false), 100)
                        } // Delay to allow click on suggestion
                      />
                      {isArticleInputFocused && articleSuggestions.length > 0 && (
                        <ul className="absolute z-10 w-full bg-white border border-gray-200 rounded-md shadow-lg max-h-48 overflow-y-auto mt-1">
                          {articleSuggestions.map((suggestion) => (
                            <li
                              key={suggestion.id}
                              className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                              onMouseDown={() => handleArticleSelect(suggestion)}
                            >
                              {suggestion.name} ({suggestion.category})
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="price">Price</Label>
                    <Input
                      id="price"
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reorderLevel">Re-order Level</Label>
                    <Input
                      id="reorderLevel"
                      type="number"
                      value={reorderLevel}
                      onChange={(e) => setReorderLevel(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reorderAmount">Re-order Amount</Label>
                    <Input
                      id="reorderAmount"
                      type="number"
                      value={reorderAmount}
                      onChange={(e) => setReorderAmount(e.target.value)}
                    />
                  </div>
                </div>

                {/* Ledger Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-6 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Date</div>
                    <div>Voucher</div>
                    <div>Receipts</div>
                    <div>Issues</div>
                    <div>Balance</div>
                    <div>Outstanding Orders</div>
                  </div>

                  {entries.map((entry) => (
                    <div
                      key={entry.id}
                      className="grid grid-cols-6 gap-2 items-center border-b py-2"
                    >
                      <Input
                        type="date"
                        value={entry.date}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "date", e.target.value)
                        }
                      />
                      <Input
                        value={entry.voucher}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "voucher", e.target.value)
                        }
                      />
                      <Input
                        type="number"
                        value={entry.receipts || ""}
                        onChange={(e) =>
                          handleEntryChange(
                            entry.id!,
                            "receipts",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        type="number"
                        value={entry.issues || ""}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "issues", e.target.value)
                        }
                      />
                      <Input
                        type="number"
                        value={entry.balance || ""}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "balance", e.target.value)
                        }
                      />
                      <Input
                        value={entry.outstanding_orders}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "outstanding_orders", e.target.value)
                        }
                      />
                    </div>
                  ))}
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleResetForm}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        const currentFormData: Form57DataFromAPI = {
                          id: formId || 0,
                          description,
                          price: Number(price),
                          reorder_level: Number(reorderLevel),
                          reorder_amount: Number(reorderAmount),
                          office: formType,
                          ledger_entries: entries.filter(e => Object.values(e).some(v => v !== "" && v !== null)).map(entry => ({
                            ...entry,
                            receipts: entry.receipts === "" ? null : Number(entry.receipts),
                            issues: entry.issues === "" ? null : Number(entry.issues),
                            balance: entry.balance === "" ? null : Number(entry.balance),
                          })),
                          created_by: 0,
                          created_at: new Date().toISOString(),
                          updated_at: new Date().toISOString(),
                        };
                        setPreviewData(currentFormData);
                        setShowPreview(true);
                      }}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? "Submitting..." : (isEditMode ? "Update Ledger" : "Submit Ledger")}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          previewData && (
            <Form57Pdf
              formData={previewData}
              onBack={() => setShowPreview(false)}
              onPrint={handlePrint}
            />
          )
        )}
      </div>
    </>
  );
};

export default Form57;