import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form157Pdf from "@/formPdfs/Form157Pdf";
import Server from "@/server/Server";

type ExchangeItem = {
  id: number;
  returnedDescription: string;
  returnedSize: string;
  returnedNo: string;
  issuedDescription: string;
  issuedSize: string;
  issuedNo: string;
};

const Form157 = ({office}) => {
  const [items, setItems] = useState<ExchangeItem[]>([
    {
      id: 1,
      returnedDescription: "",
      returnedSize: "",
      returnedNo: "",
      issuedDescription: "",
      issuedSize: "",
      issuedNo: "",
    },
  ]);

  const [returnedBy, setReturnedBy] = useState({
    initials: "",
    date: "",
  });

  const [ledgerActionedBy, setLedgerActionedBy] = useState({
    initials: "",
    date: "",
  });

  const [showPreview, setShowPreview] = useState(false);
  const [formData, setFormData] = useState<{
    items: ExchangeItem[];
    returnedBy: { initials: string; date: string };
    ledgerActionedBy: { initials: string; date: string };
  }>();

  // Check if we need to add a new row when items change
  useEffect(() => {
    if (items.length > 0) {
      const lastItem = items[items.length - 1];
      if (
        lastItem &&
        (lastItem.returnedDescription ||
          lastItem.returnedSize ||
          lastItem.returnedNo ||
          lastItem.issuedDescription ||
          lastItem.issuedSize ||
          lastItem.issuedNo)
      ) {
        // Add a new empty row if the last row has any data
        setItems((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            returnedDescription: "",
            returnedSize: "",
            returnedNo: "",
            issuedDescription: "",
            issuedSize: "",
            issuedNo: "",
          },
        ]);
      }
    }
  }, [items]);

  const handleItemChange = (
    id: number,
    field: keyof ExchangeItem,
    value: string
  ) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out empty rows (where all fields are empty)
    const nonEmptyItems = items.filter(
      (item) =>
        item.returnedDescription ||
        item.returnedSize ||
        item.returnedNo ||
        item.issuedDescription ||
        item.issuedSize ||
        item.issuedNo
    );

    // Update the items state to only include non-empty rows
    setItems(nonEmptyItems);

    // Create the form data with the filtered items
    const formDataToPass = {
      items: nonEmptyItems, // Use the filtered items here
      returnedBy,
      ledgerActionedBy,
      office: office
    };

    setFormData(formDataToPass);
    Server.addForm157(formDataToPass)
      .then(() => {
        toast.success("Form 157 succefully added");
      })
      .catch((error) => {
        toast.error(error);
      });
    console.log("Form data to pass:", formDataToPass);

    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });

  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 157 - EXCHANGE VOUCHER
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Items Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-6 gap-2 font-semibold border-b pb-2 mb-2">
                    <div className="col-span-3">Issues to Bulk</div>
                  </div>
                  <div className="grid grid-cols-6 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Description</div>
                    <div>Size</div>
                    <div>No.</div>
                    <div>Description</div>
                    <div>Size</div>
                    <div>No.</div>
                  </div>

                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-6 gap-2 items-center border-b py-2"
                    >
                      <Input
                        value={item.returnedDescription}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "returnedDescription",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.returnedSize}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "returnedSize",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.returnedNo}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "returnedNo",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.issuedDescription}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "issuedDescription",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.issuedSize}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "issuedSize",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.issuedNo}
                        onChange={(e) =>
                          handleItemChange(item.id, "issuedNo", e.target.value)
                        }
                      />
                    </div>
                  ))}
                </div>

                {/* Signatures Section */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Items Returned By</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={returnedBy.initials}
                          onChange={(e) =>
                            setReturnedBy({
                              ...returnedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={returnedBy.date}
                          onChange={(e) =>
                            setReturnedBy({
                              ...returnedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Ledger Actioned By</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={ledgerActionedBy.initials}
                          onChange={(e) =>
                            setLedgerActionedBy({
                              ...ledgerActionedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={ledgerActionedBy.date}
                          onChange={(e) =>
                            setLedgerActionedBy({
                              ...ledgerActionedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setItems([
                        {
                          id: 1,
                          returnedDescription: "",
                          returnedSize: "",
                          returnedNo: "",
                          issuedDescription: "",
                          issuedSize: "",
                          issuedNo: "",
                        },
                      ]);
                      setReturnedBy({ initials: "", date: "" });
                      setLedgerActionedBy({ initials: "", date: "" });
                      toast.info("Form reset");
                    }}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        const nonEmptyItems = items.filter(
                          (item) =>
                            item.returnedDescription ||
                            item.returnedSize ||
                            item.returnedNo ||
                            item.issuedDescription ||
                            item.issuedSize ||
                            item.issuedNo
                        );
                        setItems(nonEmptyItems);
                        setShowPreview(true);
                      }}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Voucher</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form157Pdf
            formData={formData}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
      
      </div>
    </>
  );
};

export default Form157;
