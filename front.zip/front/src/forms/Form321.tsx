import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form321Pdf from "@/formPdfs/Form321Pdf";
import Server from "@/server/Server";

type EquipmentItem = {
  id: number;
  description: string;
  number: string;
  value: string;
};

type Person = {
  id: number;
  no: string;
  rank: string;
  name: string;
  homeStation: string;
};

const Form321 = () => {
  const [reportNo, setReportNo] = useState("");
  const [province, setProvince] = useState("");
  const [station, setStation] = useState("");
  const [condition, setCondition] = useState<"new" | "part worn" | "old">(
    "new"
  );
  const [dateOfIssue, setDateOfIssue] = useState("");
  const [dateOfLoss, setDateOfLoss] = useState("");
  const [circumstances, setCircumstances] = useState("");
  const [agreeToRefund, setAgreeToRefund] = useState<"agree" | "do not agree">(
    "agree"
  );
  const [officerComment, setOfficerComment] = useState("");
  const [negligence, setNegligence] = useState<"believe" | "do not believe">(
    "believe"
  );
  const [depreciatedValue, setDepreciatedValue] = useState("");
  const [governmentPayPercentage, setGovernmentPayPercentage] = useState("");
  const [memberPayPercentage, setMemberPayPercentage] = useState("");
  const [awaitDate, setAwaitDate] = useState("");
  const [governmentPayAmount, setGovernmentPayAmount] = useState("");
  const [boardOfEnquiryReceived, setBoardOfEnquiryReceived] = useState(false);
  const [homeAffairsAdvised, setHomeAffairsAdvised] = useState(false);
  const [equipmentRecovered, setEquipmentRecovered] = useState(false);
  const [formData, setFormData] = useState<any>(null);

  const [equipmentItems, setEquipmentItems] = useState<EquipmentItem[]>(
    Array(4)
      .fill(null)
      .map((_, i) => ({
        id: i + 1,
        description: "",
        number: "",
        value: "",
      }))
  );

  const [persons, setPersons] = useState<Person[]>(
    Array(4)
      .fill(null)
      .map((_, i) => ({
        id: i + 1,
        no: "",
        rank: "",
        name: "",
        homeStation: "",
      }))
  );

  const [showPreview, setShowPreview] = useState(false);

  const handleEquipmentChange = (
    id: number,
    field: keyof EquipmentItem,
    value: string
  ) => {
    setEquipmentItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handlePersonChange = (
    id: number,
    field: keyof Person,
    value: string
  ) => {
    setPersons((prev) =>
      prev.map((person) =>
        person.id === id ? { ...person, [field]: value } : person
      )
    );
  };

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Filter out empty rows
    const nonEmptyEquipmentItems = equipmentItems.filter(
      item => item.description || item.number || item.value
    );

    const nonEmptyPersons = persons.filter(
      person => person.no || person.rank || person.name || person.homeStation
    );

    // Validate required fields
    if (!reportNo || !province || !station) {
      toast.error("Please fill in all required header fields");
      setIsSubmitting(false);
      return;
    }

    if (!dateOfIssue || !dateOfLoss) {
      toast.error("Please fill in all required date fields");
      setIsSubmitting(false);
      return;
    }

    if (nonEmptyEquipmentItems.length === 0) {
      toast.error("Please add at least one equipment item");
      setIsSubmitting(false);
      return;
    }

    // Prepare form data
    const completeFormData = {
      reportNo,
      province,
      station,
      condition,
      dateOfIssue,
      dateOfLoss,
      circumstances,
      agreeToRefund,
      officerComment,
      negligence,
      depreciatedValue,
      governmentPayPercentage,
      memberPayPercentage,
      awaitDate,
      governmentPayAmount,
      boardOfEnquiryReceived,
      homeAffairsAdvised,
      equipmentRecovered,
      equipmentItems: nonEmptyEquipmentItems,
      persons: nonEmptyPersons,
    };

    // Update state
    setEquipmentItems(nonEmptyEquipmentItems);
    setPersons(nonEmptyPersons);
    setFormData(completeFormData);

    // Submit to server
    Server.addForm321(completeFormData)
      .then(() => {
        toast.success("Form 321 successfully submitted");
        setShowPreview(true);
      })
      .catch(error => {
        console.error("Submission error:", error);
        toast.error(error?.message || "Failed to submit form");
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };


  const handlePrint = () => {
    window.print();
  };

  const resetForm = () => {
    setReportNo("");
    setProvince("");
    setStation("");
    setCondition("new");
    setDateOfIssue("");
    setDateOfLoss("");
    setCircumstances("");
    setAgreeToRefund("agree");
    setOfficerComment("");
    setNegligence("believe");
    setDepreciatedValue("");
    setGovernmentPayPercentage("");
    setMemberPayPercentage("");
    setAwaitDate("");
    setGovernmentPayAmount("");
    setBoardOfEnquiryReceived(false);
    setHomeAffairsAdvised(false);
    setEquipmentRecovered(false);

    setEquipmentItems(
      Array(4)
        .fill(null)
        .map((_, i) => ({
          id: i + 1,
          description: "",
          number: "",
          value: "",
        }))
    );

    setPersons(
      Array(4)
        .fill(null)
        .map((_, i) => ({
          id: i + 1,
          no: "",
          rank: "",
          name: "",
          homeStation: "",
        }))
    );

    toast.success("Form has been reset");
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });

  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold">Z.R.P.</h1>
                <p className="text-sm font-medium">
                  Initial Report of Missing, Damaged or Destroyed Equipment
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <p className="text-xs mb-2">
                    Refer to Section 5 of Part Q1 of Standing Orders Volume II.
                  </p>
                  <p className="text-xs mb-2">
                    Complete in quadruplicate. Original and two copies to O.C.
                    District. One copy to be filed on site.
                  </p>
                  <p className="text-xs">
                    Where alternative answers are given, delete inapplicable.
                  </p>
                </div>

                {/* Header Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 border-b pb-4">
                  <div>
                    <Label>Province</Label>
                    <Input
                      value={province}
                      onChange={(e) => setProvince(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Station</Label>
                    <Input
                      value={station}
                      onChange={(e) => setStation(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Report No.</Label>
                    <Input
                      value={reportNo}
                      onChange={(e) => setReportNo(e.target.value)}
                    />
                  </div>
                </div>

                {/* PART I */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART I. To be completed by person to whom equipment was on
                    issue
                  </h3>

                  <div className="mb-4">
                    <p>
                      The following equipment has been lost/damaged/destroyed.
                    </p>
                    <div className="grid grid-cols-3 gap-2 font-semibold border-b pb-2 mb-2">
                      <div>Description</div>
                      <div>Number</div>
                      <div>Value</div>
                    </div>
                    {equipmentItems.map((item) => (
                      <div
                        key={item.id}
                        className="grid grid-cols-3 gap-2 items-center border-b py-2"
                      >
                        <Input
                          value={item.description}
                          onChange={(e) =>
                            handleEquipmentChange(
                              item.id,
                              "description",
                              e.target.value
                            )
                          }
                          className="border-none"
                        />
                        <Input
                          value={item.number}
                          onChange={(e) =>
                            handleEquipmentChange(
                              item.id,
                              "number",
                              e.target.value
                            )
                          }
                          className="border-none"
                        />
                        <Input
                          value={item.value}
                          onChange={(e) =>
                            handleEquipmentChange(
                              item.id,
                              "value",
                              e.target.value
                            )
                          }
                          className="border-none"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label>Condition was</Label>
                      <div className="flex gap-4">
                        <label className="flex items-center">
                          <input
                            type="radio"
                            checked={condition === "new"}
                            onChange={() => setCondition("new")}
                            className="mr-2"
                          />
                          New
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            checked={condition === "part worn"}
                            onChange={() => setCondition("part worn")}
                            className="mr-2"
                          />
                          Part Worn
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            checked={condition === "old"}
                            onChange={() => setCondition("old")}
                            className="mr-2"
                          />
                          Old
                        </label>
                      </div>
                    </div>
                    <div>
                      <Label>Date of original issue</Label>
                      <Input
                        type="date"
                        value={dateOfIssue}
                        onChange={(e) => setDateOfIssue(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <Label>Date of loss (approx.)</Label>
                    <Input
                      type="date"
                      value={dateOfLoss}
                      onChange={(e) => setDateOfLoss(e.target.value)}
                    />
                  </div>

                  <div className="mb-4">
                    <p>Particulars of person or persons involved:</p>
                    <div className="grid grid-cols-4 gap-2 font-semibold border-b pb-2 mb-2">
                      <div>No.</div>
                      <div>Rank</div>
                      <div>Name</div>
                      <div>Home Station</div>
                    </div>
                    {persons.map((person) => (
                      <div
                        key={person.id}
                        className="grid grid-cols-4 gap-2 items-center border-b py-2"
                      >
                        <Input
                          value={person.no}
                          onChange={(e) =>
                            handlePersonChange(person.id, "no", e.target.value)
                          }
                          className="border-none"
                        />
                        <Input
                          value={person.rank}
                          onChange={(e) =>
                            handlePersonChange(
                              person.id,
                              "rank",
                              e.target.value
                            )
                          }
                          className="border-none"
                        />
                        <Input
                          value={person.name}
                          onChange={(e) =>
                            handlePersonChange(
                              person.id,
                              "name",
                              e.target.value
                            )
                          }
                          className="border-none"
                        />
                        <Input
                          value={person.homeStation}
                          onChange={(e) =>
                            handlePersonChange(
                              person.id,
                              "homeStation",
                              e.target.value
                            )
                          }
                          className="border-none"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="mb-4">
                    <Label>
                      Brief circumstances (concerning loss/damage/destruction;
                      give map reference where applicable)
                    </Label>
                    <textarea
                      value={circumstances}
                      onChange={(e) => setCircumstances(e.target.value)}
                      className="w-full border rounded p-2 min-h-[100px]"
                    />
                  </div>

                  <div className="mb-4">
                    <Label>
                      I agree/do not agree to refund the value of the equipment.
                    </Label>
                    <div className="flex gap-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          checked={agreeToRefund === "agree"}
                          onChange={() => setAgreeToRefund("agree")}
                          className="mr-2"
                        />
                        Agree
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          checked={agreeToRefund === "do not agree"}
                          onChange={() => setAgreeToRefund("do not agree")}
                          className="mr-2"
                        />
                        Do Not Agree
                      </label>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Date</Label>
                      <Input type="date" />
                    </div>
                    <div>
                      <Label>Signed</Label>
                      <Input />
                    </div>
                  </div>
                </div>

                {/* PART II */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART II. To be completed by an officer
                  </h3>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="circumstances-true" />
                      <Label htmlFor="circumstances-true">
                        The circumstances described above are known by me to be
                        true.
                      </Label>
                    </div>

                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="no-doubt" />
                      <Label htmlFor="no-doubt">
                        I have no reason to doubt the truth of the circumstances
                        as described above.
                      </Label>
                    </div>

                    <div>
                      <Label>I wish to make the following comment:</Label>
                      <textarea
                        value={officerComment}
                        onChange={(e) => setOfficerComment(e.target.value)}
                        className="w-full border rounded p-2 min-h-[80px]"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <Label>Date</Label>
                        <Input type="date" />
                      </div>
                      <div>
                        <Label>Signed</Label>
                        <Input />
                      </div>
                      <div>
                        <Label>Post held</Label>
                        <Input />
                      </div>
                      <div>
                        <Label>Rank</Label>
                        <Input />
                      </div>
                    </div>
                  </div>
                </div>

                {/* PART III */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART III. To be completed by the O.C. District
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <Label>
                        (a) I believed to not believe that there has been a
                        degree of negligence in this matter.
                      </Label>
                      <div className="flex gap-4 mt-2">
                        <label className="flex items-center">
                          <input
                            type="radio"
                            checked={negligence === "believe"}
                            onChange={() => setNegligence("believe")}
                            className="mr-2"
                          />
                          Believe
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            checked={negligence === "do not believe"}
                            onChange={() => setNegligence("do not believe")}
                            className="mr-2"
                          />
                          Do Not Believe
                        </label>
                      </div>
                    </div>

                    <div>
                      <Label>
                        (b) I recommend the equipment be written off as a minor
                        loss, if the depreciated value of the equipment is less
                        than $65.
                      </Label>
                    </div>

                    <div>
                      <Label>
                        (c) I recommend a period of 1 month be awaited as from
                        (date) ______ before further action is taken.
                      </Label>
                      <Input
                        type="date"
                        value={awaitDate}
                        onChange={(e) => setAwaitDate(e.target.value)}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label>
                        (d) Notwithstanding the members involved agree to refund
                        the value of the equipment, I recommend the Government
                        should pay ______.
                      </Label>
                      <Input
                        value={governmentPayAmount}
                        onChange={(e) => setGovernmentPayAmount(e.target.value)}
                        className="mt-2"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Signed</Label>
                        <Input />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input type="date" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* PART IV */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART IV. To be completed by the Provincial Quartermaster
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <Label>
                        The depreciated value of the equipment is $ ______
                      </Label>
                      <Input
                        value={depreciatedValue}
                        onChange={(e) => setDepreciatedValue(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label>
                        Arrangements have been made to replace the equipment.
                      </Label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Date</Label>
                        <Input type="date" />
                      </div>
                      <div>
                        <Label>Signed</Label>
                        <Input />
                      </div>
                    </div>
                  </div>
                </div>

                {/* PART V */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART V. To be completed by the O.C. Province
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <Label>(a) It is recommended:—</Label>
                      <div className="ml-4 space-y-2">
                        <div>
                          <Label>
                            (i) The equipment to be written off as a minor loss
                            (where the depreciated value is less than $65).
                          </Label>
                        </div>
                        <div>
                          <Label>
                            (ii) Loss should be borne by Government to ______ %.
                          </Label>
                          <Input
                            value={governmentPayPercentage}
                            onChange={(e) =>
                              setGovernmentPayPercentage(e.target.value)
                            }
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label>
                            (iii) ______ % should be borne by responsible
                            members who agree to refund the value of the
                            equipment.
                          </Label>
                          <Input
                            value={memberPayPercentage}
                            onChange={(e) =>
                              setMemberPayPercentage(e.target.value)
                            }
                            className="mt-2"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label>
                        *(b) I have directed that no action be taken for 1
                        month.
                      </Label>
                    </div>

                    <div>
                      <Label>(c) I have convened a Board of Enquiry.</Label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Date</Label>
                        <Input type="date" />
                      </div>
                      <div>
                        <Label>Signed</Label>
                        <Input />
                      </div>
                    </div>

                    <div className="text-xs italic">
                      <p>
                        * If property not recovered SSO (Q) to be notified by
                        signal of action taken.
                      </p>
                    </div>
                  </div>
                </div>

                {/* PART VI */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART VI. To be completed by SSO (Q). (Tick appropriate
                    instruction)
                  </h3>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="write-off" />
                      <Label htmlFor="write-off">
                        Authority is given to write off as a minor loss.
                      </Label>
                    </div>

                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="return-oc" />
                      <Label htmlFor="return-oc">
                        Return to O.C. Province for convening of Board of
                        Enquiry.
                      </Label>
                    </div>

                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="await-board" />
                      <Label htmlFor="await-board">
                        Await Board of Enquiry. Follow up in 1 month.
                      </Label>
                    </div>

                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="advise-home" />
                      <Label htmlFor="advise-home">
                        Advise Home Affairs of the loss.
                      </Label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                      <div>
                        <Label>Date</Label>
                        <Input type="date" />
                      </div>
                      <div>
                        <Label>Signed</Label>
                        <Input />
                      </div>
                    </div>
                  </div>
                </div>

                {/* PART VII */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 underline">
                    PART VII. To be completed by Quartermaster's Staff
                  </h3>

                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={boardOfEnquiryReceived}
                          onChange={(e) =>
                            setBoardOfEnquiryReceived(e.target.checked)
                          }
                        />
                        <Label>Board of Enquiry received</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={homeAffairsAdvised}
                          onChange={(e) =>
                            setHomeAffairsAdvised(e.target.checked)
                          }
                        />
                        <Label>Home Affairs Advised</Label>
                      </div>
                    </div>

                    <div>
                      <Label>
                        (b) 1 month period has elapsed. O.C. Prov. requests
                      </Label>
                      <div className="ml-4 space-y-2 mt-2">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={equipmentRecovered}
                            onChange={(e) =>
                              setEquipmentRecovered(e.target.checked)
                            }
                          />
                          <Label>(i) Equipment be written off</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={equipmentRecovered}
                            onChange={(e) =>
                              setEquipmentRecovered(e.target.checked)
                            }
                          />
                          <Label>(ii) has convened a Board of Enquiry</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={equipmentRecovered}
                            onChange={(e) =>
                              setEquipmentRecovered(e.target.checked)
                            }
                          />
                          <Label>
                            (iii) has notified properly has been recovered
                          </Label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowPreview(true)}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Report</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form321Pdf
            // formData={
            //   null
            // }
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              Recent Reports
            </h3>

            <div className="relative flex items-center">
              <input
                aria-label="Search"
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                id="search"
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by report no, station..."
                type="text"
                value={searchTerm}
              />
              <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                <Search />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Report No.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Station
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date Issued
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredVouchers.length > 0 ? (
                    filteredVouchers.map((voucher, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {voucher.voucher_no}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.issue_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completed
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        className="px-6 py-4 text-sm text-gray-500 text-center"
                        colSpan="4"
                      >
                        {requisitionVouchers.length === 0
                          ? "No recent reports found"
                          : "No matching reports found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <a
              className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
              href="#"
            >
              <List /> View All Reports
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Form321;
