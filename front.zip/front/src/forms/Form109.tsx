import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form109Pdf from "@/formPdfs/Form109Pdf";
import Server from "@/server/Server";

// Define a type for your clothing item (as transformed)
type TransformedClothingItem = {
  id: string; // Unique ID for each item, e.g., "Badges-Hat-Emb."
  name: string; // The actual article name, e.g., "Hat Emb."
  category: string; // The category, e.g., "Badges"
  sizes: string[]; // Sizes associated with this item (if applicable)
};

type ReceiptItem = {
  id: number;
  description: string;
  size: string;
  number_received: number | string; // Allow string from input, convert to number for API
  number_rejected: number | string; // Allow string from input, convert to number for API
  noTaken: string;
};

type FormData = {
  received_from: string;
  ordinance_voucher_no: string;
  gcs_reqn_no: string;
  supplier_ref_no: string;
  items: ReceiptItem[];
  received_by_date: string;
  received_by_signature: string;
  ledger_actioned_by_date: string;
  ledger_actioned_by_signature: string;
};

const Form109 = ({ stockType }) => {
  const [formData, setFormData] = useState<FormData>({
    received_from: "",
    ordinance_voucher_no: "",
    gcs_reqn_no: "",
    supplier_ref_no: "",
    items: [
      {
        id: 1,
        description: "",
        size: "",
        number_received: "", // Initialize as empty string for input
        number_rejected: "", // Initialize as empty string for input
        noTaken: "",
      },
    ],
    received_by_date: "",
    received_by_signature: "",
    ledger_actioned_by_signature: "",
    ledger_actioned_by_date: "",
  });

  const [showPreview, setShowPreview] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // --- States for Article Search Functionality ---
  const [allClothingItems, setAllClothingItems] = useState<TransformedClothingItem[]>([]);
  // Store suggestions per item row ID
  const [articleSuggestions, setArticleSuggestions] = useState<{ [key: number]: TransformedClothingItem[] }>({});
  const [activeArticleInputId, setActiveArticleInputId] = useState<number | null>(null);

  useEffect(() => {
    // Function to fetch and transform clothing items
    const fetchAndTransformClothingItems = async () => {
      try {
        const response = await Server.getAllClothingItem(); // Assuming this fetches the nested object
        if (response && typeof response === 'object' && !Array.isArray(response)) {
          const transformedData: TransformedClothingItem[] = Object.entries(response).flatMap(
            ([category, itemsArray]) => {
              if (Array.isArray(itemsArray)) {
                return itemsArray.map((itemName: string, index: number) => ({
                  id: `${category}-${itemName.replace(/\s+/g, '-')}-${index}`, // Generate unique ID
                  name: itemName,
                  category: category,
                  sizes: [], // Placeholder; if backend provides sizes, update this logic
                }));
              }
              return [];
            }
          );
          setAllClothingItems(transformedData);
        } else {
          console.warn("API response for clothing items was not an object or was empty:", response);
          setAllClothingItems([]); // Fallback to empty array
        }
      } catch (error) {
        console.error("Error fetching all clothing items:", error);
        setAllClothingItems([]); // Ensure it's an array even on error
      }
    };

    fetchAndTransformClothingItems(); // Call it immediately when component mounts
  }, []); // Empty dependency array means this runs once on mount

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleItemChange = (
    id: number,
    field: keyof ReceiptItem,
    value: string | number
  ) => {
    setFormData((prev) => {
      const updatedItems = prev.items.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      );

      // Add new row if description is filled in the last row
      const lastItem = updatedItems[updatedItems.length - 1];
      if (
        field === "description" &&
        typeof value === "string" &&
        value !== "" &&
        id === lastItem.id && // Check if the change is on the last item
        lastItem.description.trim() !== "" // Only add if the description of the last item is now non-empty
      ) {
        return {
          ...prev,
          items: [
            ...updatedItems,
            {
              id: prev.items.length > 0 ? (prev.items[prev.items.length - 1].id + 1) : 1,
              description: "",
              size: "",
              number_received: "",
              number_rejected: "",
              noTaken: "",
            },
          ],
        };
      }

      return {
        ...prev,
        items: updatedItems,
      };
    });
  };

  // --- New Handlers for Article Search within Items ---
  const handleArticleInputChange = (itemId: number, value: string) => {
    handleItemChange(itemId, "description", value); // Update the item's description

    if (value.trim() === "") {
      setArticleSuggestions((prev) => {
        const newSuggestions = { ...prev };
        delete newSuggestions[itemId]; // Clear suggestions for this item
        return newSuggestions;
      });
      return;
    }

    // Filter allClothingItems based on user input
    const filtered = allClothingItems.filter((clothingItem) =>
      clothingItem.name.toLowerCase().includes(value.toLowerCase())
    );
    setArticleSuggestions((prev) => ({
      ...prev,
      [itemId]: filtered, // Store suggestions specifically for this item ID
    }));
  };

  const handleArticleSelect = (itemId: number, selectedArticle: TransformedClothingItem) => {
    setFormData((prev) => ({
      ...prev,
      items: prev.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              description: selectedArticle.name,
              // Optionally pre-fill size if the selected article has a single size, or clear it
              size: selectedArticle.sizes.length === 1 ? selectedArticle.sizes[0] : item.size,
            }
          : item
      ),
    }));
    setArticleSuggestions((prev) => {
      const newSuggestions = { ...prev };
      delete newSuggestions[itemId]; // Clear suggestions for this item after selection
      return newSuggestions;
    });
    setActiveArticleInputId(null); // Deactivate the input
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Filter out empty items and convert numbers
    const submittedItems = formData.items
      .filter((item) => item.description.trim() !== "")
      .map((item) => ({
        ...item,
        number_received: item.number_received === "" ? null : Number(item.number_received),
        number_rejected: item.number_rejected === "" ? null : Number(item.number_rejected),
      }));

    const completeFormData = {
      ...formData,
      items: submittedItems,
      stockType: stockType, // Ensure stockType is passed if needed by backend
    };

    try {
      await Server.addForm109(completeFormData);
      toast.success('Successfully recorded Form 109');
      setShowPreview(true); // Show preview on successful submission
    } catch (error) {
      toast.error('An error occurred during submission. Please try again.');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setFormData({
      received_from: "",
      ordinance_voucher_no: "",
      gcs_reqn_no: "",
      supplier_ref_no: "",
      items: [
        {
          id: 1,
          description: "",
          size: "",
          number_received: "",
          number_rejected: "",
          noTaken: "",
        },
      ],
      received_by_date: "",
      received_by_signature: "",
      ledger_actioned_by_date: "",
      ledger_actioned_by_signature: "",
    });
    setArticleSuggestions({}); // Clear all suggestions
    setActiveArticleInputId(null);
    setShowPreview(false);
    toast.info("Form has been reset");
  };

  return (
    <>
      <div className="w-full mx-auto">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 109 - ORDNANCE STORE RECEIPT VOUCHER
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Header Info */}
                <div className="mb-6">
                  <div className="mb-4">
                    <Label>Received from:</Label>
                    <Input
                      value={formData.received_from}
                      onChange={(e) =>
                        handleInputChange("received_from", e.target.value)
                      }
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <Label>Ordnance Voucher No.</Label>
                      <Input
                        value={formData.ordinance_voucher_no}
                        onChange={(e) =>
                          handleInputChange(
                            "ordinance_voucher_no",
                            e.target.value
                          )
                        }
                      />
                    </div>
                    <div>
                      <Label>G.C.S./Tradesman Reqn. No.</Label>
                      <Input
                        value={formData.gcs_reqn_no}
                        onChange={(e) =>
                          handleInputChange("gcs_reqn_no", e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <Label>Supplier Ref: No.</Label>
                      <Input
                        value={formData.supplier_ref_no}
                        onChange={(e) =>
                          handleInputChange("supplier_ref_no", e.target.value)
                        }
                      />
                    </div>
                  </div>
                </div>

                {/* Items Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-5 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Description of goods</div>
                    <div>Size</div>
                    <div>Number Received</div>
                    <div>Number Rejected</div>
                    <div>No. taken on stock</div>
                  </div>

                  {formData.items.map((item) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-5 gap-2 items-center border-b py-2"
                    >
                      {/* Description Input with Suggestions */}
                      <div className="relative">
                        <Input
                          value={item.description}
                          onChange={(e) =>
                            handleArticleInputChange(item.id, e.target.value)
                          }
                          onFocus={() => setActiveArticleInputId(item.id)}
                          onBlur={() =>
                            setTimeout(() => setActiveArticleInputId(null), 100)
                          } // Delay to allow click on suggestion
                        />
                        {activeArticleInputId === item.id &&
                          articleSuggestions[item.id] &&
                          articleSuggestions[item.id].length > 0 && (
                            <ul className="absolute z-10 w-full bg-white border border-gray-200 rounded-md shadow-lg max-h-48 overflow-y-auto mt-1">
                              {articleSuggestions[item.id].map((suggestion) => (
                                <li
                                  key={suggestion.id}
                                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                                  onMouseDown={() =>
                                    handleArticleSelect(item.id, suggestion)
                                  } // Use onMouseDown to prevent onBlur from firing first
                                >
                                  {suggestion.name} ({suggestion.category})
                                </li>
                              ))}
                            </ul>
                          )}
                      </div>

                      <Input
                        value={item.size}
                        onChange={(e) =>
                          handleItemChange(item.id, "size", e.target.value)
                        }
                      />
                      <Input
                        value={item.number_received}
                        type="number"
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "number_received",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.number_rejected}
                        type="number"
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "number_rejected",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.noTaken}
                        onChange={(e) =>
                          handleItemChange(item.id, "noTaken", e.target.value)
                        }
                      />
                    </div>
                  ))}
                </div>

                {/* Signatures Section */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">
                      Received and taken on Stock
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Signature</Label>
                        <Input
                          value={formData.received_by_signature}
                          onChange={(e) =>
                            handleInputChange("received_by_signature", e.target.value)
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={formData.received_by_date}
                          onChange={(e) =>
                            handleInputChange("received_by_date", e.target.value)
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Taken on Ledger</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Signature</Label>
                        <Input
                          value={formData.ledger_actioned_by_signature}
                          onChange={(e) =>
                            handleInputChange("ledger_actioned_by_signature", e.target.value)
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={formData.ledger_actioned_by_date}
                          onChange={(e) =>
                            handleInputChange("ledger_actioned_by_date", e.target.value)
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button type="button" variant="outline" onClick={handleReset}>
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowPreview(true)}
                      disabled={isLoading}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? "Submitting..." : "Submit Voucher"}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form109Pdf
            formData={{
              ...formData,
              items: formData.items.filter(
                (item) => item.description.trim() !== ""
              ).map(item => ({
                ...item,
                number_received: item.number_received === "" ? null : Number(item.number_received),
                number_rejected: item.number_rejected === "" ? null : Number(item.number_rejected),
              })),
            }}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
      </div>
    </>
  );
};

export default Form109;