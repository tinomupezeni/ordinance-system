import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search, Trash } from "lucide-react";
import { toast } from "sonner";
import Form227Pdf from "../formPdfs/Form227Pdf";
import Server from "@/server/Server";

type RequisitionItem = {
  id: number;
  forceNo: string;
  rank: string;
  name: string;
  article: string;
  size: string;
  regdNo: string;
  dateDue: string;
  issued: string;
  signature: string;
  life?: string;
  reason?: string;
  isExpanded?: boolean;
};
type ReplacementItem = {
  id: number;
  forceNo: string;
  life?: string;
  dateDue: string;
  issued: string;
  reason?: string;
  isExpanded?: boolean;
};

type CollectedBy = {
  no: string;
  rank: string;
  name: string;
};

type OfficerRecommendation = {
  at: string;
  rank: string;
  expenseType: "GOVERNMENT" | "MEMBER";
};

type CheckedBy = {
  no: string;
  rank: string;
  name?: string;
};

type InitialsAndDate = {
  initials: string;
  date: string;
};

type DispatchMethod = {
  collected: boolean;
  rail: boolean;
  road: boolean;
  air: boolean;
  registeredMail: boolean;
  parcelPost: boolean;
  parcelWarrantNo: string;
};

const RequisitionForm = ({ formType }) => {
  // Form state
  const [ordinanceControlNo, setOrdinanceControlNo] = useState("");
  const [station, setStation] = useState("");
  const [branch, setBranch] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [dispatchMethod, setDispatchMethod] = useState<
    "CALLED FOR" | "DESPATCHED"
  >("CALLED FOR");
  const [date, setDate] = useState<string>(
    new Date().toISOString().split("T")[0]
  );

  // State to hold filtered suggestions for the currently active article input
  const [articleSuggestions, setArticleSuggestions] = useState([]);
  // State to track which item row's article input is currently active/focused
  const [activeArticleInputId, setActiveArticleInputId] = useState(null);

  // Handles changes to any input field for an item
  const handleInputItemChange = (id, field, value) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };

  // Handles input change for the 'Article' field with filtering
  const handleArticleInputChange = (itemId, value) => {
    handleInputItemChange(itemId, "article", value);
    setActiveArticleInputId(itemId); // Set the active input

    if (value.trim() === "") {
      setArticleSuggestions([]); // Clear suggestions if input is empty
      return;
    }

    // Filter allClothingItems based on user input
    const filtered = allClothingItems.filter((clothingItem) =>
      clothingItem.name.toLowerCase().includes(value.toLowerCase())
    );
    setArticleSuggestions(filtered);
  };

  // Handles selection from the article dropdown
  const handleArticleSelect = (itemId, selectedArticle) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === itemId
          ? {
              ...item,
              article: selectedArticle.name,
              // Optionally, pre-fill the size if there's only one, or clear it for selection
              size:
                selectedArticle.sizes.length === 1
                  ? selectedArticle.sizes[0]
                  : "",
            }
          : item
      )
    );
    setArticleSuggestions([]); // Clear suggestions after selection
    setActiveArticleInputId(null); // Deactivate the input
  };

  // Items state
  const [items, setItems] = useState<RequisitionItem[]>([
    createEmptyRequiredItem(1),
  ]);
  const [replacementItems, setReplacementItems] = useState<RequisitionItem[]>([
    createEmptyRequiredItem(1),
  ]);

  const [allClothingItems, setAllClothingItems] = useState([]);

  function formatDateForSubmit(dateString) {
    if (dateString.includes("/")) {
      const [month, day, year] = dateString.split("/");
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }
    return dateString;
  }

  useEffect(() => {
    const getAllClothingItem = () => {
      Server.getAllClothingItem()
        .then((response) => {
          // --- START OF NEW LOGIC ---
          // Assuming 'response' is the object structure you provided
          if (
            response &&
            typeof response === "object" &&
            !Array.isArray(response)
          ) {
            const transformedData = Object.entries(response).flatMap(
              ([category, itemsArray]) => {
                // Ensure itemsArray is an array before mapping
                if (Array.isArray(itemsArray)) {
                  return itemsArray.map((itemName, index) => ({
                    id: `${category}-${itemName.replace(/\s+/g, "-")}-${index}`, // Create a more robust ID
                    name: itemName,
                    category: category,
                    sizes: [], // Initialize with an empty array or default sizes
                  }));
                }
                return []; // Return empty array if itemsArray is not an array
              }
            );
            console.log("Transformed Clothing Items:", transformedData);
            setAllClothingItems(transformedData);
          } else {
            // If the response is already an array (or unexpected), handle it
            console.warn(
              "Unexpected API response format. Expected an object, received:",
              response
            );
            setAllClothingItems(Array.isArray(response) ? response : []); // Set to empty array or direct response if it's already flat
          }
          // --- END OF NEW LOGIC ---
        })
        .catch((error) => {
          console.error("Error fetching clothing items:", error);
        });
    };
    getAllClothingItem();
  }, []); // Empty dependency array means this runs once on mount

  // Collected by state
  const [collectedBy, setCollectedBy] = useState<CollectedBy>({
    no: "",
    rank: "",
    name: "",
  });

  // Officer recommendations state
  const [officerRecommendation, setOfficerRecommendation] =
    useState<OfficerRecommendation>({
      at: "",
      rank: "",
      expenseType: "GOVERNMENT",
    });

  // Checked by states
  const [checkedByOfficer, setCheckedByOfficer] = useState<CheckedBy>({
    no: "",
    rank: "",
  });

  const [checkedByQuartermaster, setCheckedByQuartermaster] =
    useState<CheckedBy>({
      no: "",
      rank: "",
    });

  // Various initials and dates
  const [voucherCheckedBy, setVoucherCheckedBy] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  const [itemsSelectedBy, setItemsSelectedBy] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  const [itemsPackedBy, setItemsPackedBy] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  const [enteredOnClothingCard, setEnteredOnClothingCard] =
    useState<InitialsAndDate>({
      initials: "",
      date: "",
    });

  const [ledgerActioned, setLedgerActioned] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  // Dispatch method checkboxes
  const [dispatchMethodDetails, setDispatchMethodDetails] =
    useState<DispatchMethod>({
      collected: false,
      rail: false,
      road: false,
      air: false,
      registeredMail: false,
      parcelPost: false,
      parcelWarrantNo: "",
    });

  const [showPreview, setShowPreview] = useState(false);

  // Helper function to create empty items
  function createEmptyRequiredItem(id: number): RequisitionItem {
    return {
      id,
      forceNo: "",
      rank: "",
      name: "",
      article: "",
      size: "",
      regdNo: "",
      dateDue: "",
      issued: "",
      signature: "",
      life: "",
      reason: "",
      isExpanded: id === 1,
    };
  }
  function createEmptyReplacementItem(id: number): ReplacementItem {
    return {
      id,
      forceNo: "",
      dateDue: "",
      issued: "",
      life: "",
      reason: "",
      isExpanded: id === 1,
    };
  }

  // Add new row when last row starts being filled
  useEffect(() => {
    const lastItem = items[items.length - 1];
    if (
      lastItem &&
      (lastItem.forceNo ||
        lastItem.rank ||
        lastItem.name ||
        lastItem.article ||
        lastItem.size ||
        lastItem.regdNo ||
        lastItem.dateDue ||
        lastItem.issued ||
        lastItem.signature)
    ) {
      // Add new empty row
      setItems((prev) => [...prev, createEmptyRequiredItem(prev.length + 1)]);
    }

    const replacementLastItem = replacementItems[replacementItems.length - 1];
    if (
      replacementLastItem &&
      (replacementLastItem.forceNo ||
        replacementLastItem.dateDue ||
        replacementLastItem.issued ||
        replacementLastItem.reason)
    ) {
      // Add new empty row
      setReplacementItems((prev) => [
        ...prev,
        createEmptyReplacementItem(prev.length + 1),
      ]);
    }
  }, [items, replacementItems]); // Fixed dependency array
  const handleItemChange = (
    id: number,
    field: keyof RequisitionItem,
    value: string
  ) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };
  const handleReplacementItemChange = (
    id: number,
    field: keyof ReplacementItem,
    value: string
  ) => {
    setReplacementItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleDispatchMethodChange = (
    field: keyof DispatchMethod,
    value: boolean | string
  ) => {
    setDispatchMethodDetails((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Filter out completely empty items
    const submittedItems = items.filter(
      (item) =>
        item.forceNo ||
        item.rank ||
        item.name ||
        item.article ||
        item.size ||
        item.regdNo ||
        item.dateDue ||
        item.issued ||
        item.signature
    );

    const submittedReplacementItems = replacementItems.filter(
      (item) => item.forceNo || item.dateDue || item.issued || item.reason
    );

    setItems(submittedItems);
    setReplacementItems(submittedReplacementItems);
    if (!formType) {
      formType = "individual";
    }

    // Create the complete form data object
    const completeFormData = {
      ordinanceControlNo,
      station,
      branch,
      dispatchMethod,
      date,
      items: submittedItems,
      replacementItems: submittedReplacementItems,
      collectedBy,
      officerRecommendation,
      checkedByOfficer,
      checkedByQuartermaster,
      voucherCheckedBy,
      itemsSelectedBy,
      dispatchMethodDetails,
      itemsPackedBy,
      enteredOnClothingCard,
      ledgerActioned,
      formType,
    };

    Server.addForm227(completeFormData)
      .then(() => {
        toast.success("Form 227 successfully submitted");
        setShowPreview(true);
      })
      .catch((error) => {
        console.error("Submission error:", error);
        toast.error(error?.message || "Failed to submit form");
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  const handlePrint = () => {
    window.print();
  };

  // Form data object to pass to PDF
  const formData = {
    ordinanceControlNo,
    station,
    branch,
    dispatchMethod,
    date,
    items: items.filter(
      (item) =>
        item.forceNo ||
        item.rank ||
        item.name ||
        item.article ||
        item.size ||
        item.regdNo ||
        formatDateForSubmit(item.dateDue) ||
        item.issued ||
        item.signature
    ),
    replacementItems: replacementItems.filter(
      (item) =>
        item.forceNo ||
        formatDateForSubmit(item.dateDue) ||
        item.issued ||
        item.reason
    ),
    collectedBy,
    officerRecommendation,
    checkedByOfficer,
    checkedByQuartermaster,
    voucherCheckedBy,
    itemsSelectedBy,
    dispatchMethodDetails,
    itemsPackedBy,
    enteredOnClothingCard,
    ledgerActioned,
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });

  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">
                  POLICE ORDINANCE STORE REQUISITION
                </h1>
                <p className="text-sm text-gray-600">
                  Issue Voucher [FORM 227]
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Basic Information Section */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <Label className="block mb-1 font-medium">
                      Ordinance Control No.
                    </Label>
                    <Input
                      value={ordinanceControlNo}
                      onChange={(e) => setOrdinanceControlNo(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label className="block mb-1 font-medium">Station</Label>
                    <Input
                      value={station}
                      onChange={(e) => setStation(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label className="block mb-1 font-medium">Branch</Label>
                    <Input
                      value={branch}
                      onChange={(e) => setBranch(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <Label className="block mb-1 font-medium">
                      Dispatch Method
                    </Label>
                    <div className="flex gap-4">
                      <Button
                        type="button"
                        variant={
                          dispatchMethod === "CALLED FOR"
                            ? "default"
                            : "outline"
                        }
                        onClick={() => setDispatchMethod("CALLED FOR")}
                      >
                        Called For
                      </Button>
                      <Button
                        type="button"
                        variant={
                          dispatchMethod === "DESPATCHED"
                            ? "default"
                            : "outline"
                        }
                        onClick={() => setDispatchMethod("DESPATCHED")}
                      >
                        Despatched
                      </Button>
                    </div>
                  </div>
                  <div>
                    <Label className="block mb-1 font-medium">Date</Label>
                    <Input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                    />
                  </div>
                </div>

                {/* Items Section */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Items Required</h3>
                  <div className="space-y-2">
                    <Card className="overflow-hidden">
                      <CardHeader className="py-2 px-4 bg-gray-50 cursor-pointer"></CardHeader>

                      <CardContent className="p-4">
                        <div className="grid grid-cols-9 font-semibold border-b pb-2 mb-2">
                          <div>Force No.</div>
                          <div>Rank</div>
                          <div>Name</div>
                          <div>Article</div>
                          <div>Size</div>
                          <div>Reqd. No</div>
                          <div>Date Due</div>
                          <div>No. Issued</div>
                          <div>Action</div> {/* Added for delete button */}
                        </div>

                        {items.map((item) => (
                          <div
                            key={item.id}
                            className="grid grid-cols-9 gap-2 items-center border-b py-2 relative" // Added relative for positioning dropdown
                          >
                            <Input
                              value={item.forceNo}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "forceNo",
                                  e.target.value
                                )
                              }
                            />
                            <Input
                              value={item.rank}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "rank",
                                  e.target.value
                                )
                              }
                            />
                            <Input
                              value={item.name}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "name",
                                  e.target.value
                                )
                              }
                            />

                            {/* Article Input with Suggestions */}
                            <div className="relative">
                              <Input
                                value={item.article}
                                onChange={(e) =>
                                  handleArticleInputChange(
                                    item.id,
                                    e.target.value
                                  )
                                }
                                onFocus={() => setActiveArticleInputId(item.id)}
                                onBlur={() =>
                                  setTimeout(
                                    () => setActiveArticleInputId(null),
                                    100
                                  )
                                } // Delay to allow click on suggestion
                              />
                              {activeArticleInputId === item.id &&
                                articleSuggestions.length > 0 && (
                                  <ul className="absolute z-10 w-[300px] bg-white border border-gray-200 rounded-md shadow-lg max-h-48 overflow-y-auto">
                                    {articleSuggestions.map((suggestion) => (
                                      <li
                                        key={suggestion.id}
                                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                                        onMouseDown={() =>
                                          handleArticleSelect(
                                            item.id,
                                            suggestion
                                          )
                                        } // Use onMouseDown to prevent onBlur from firing first
                                      >
                                        {suggestion.name}
                                      </li>
                                    ))}
                                  </ul>
                                )}
                            </div>

                            {/* Size Input - Can also be a dropdown/select based on selected article */}
                            <Input
                              value={item.size}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "size",
                                  e.target.value
                                )
                              }
                              // If you want a dropdown for sizes based on selected article:
                              // You'd replace this with a <select> or custom dropdown
                              // For now, it remains an input
                            />
                            <Input
                              value={item.regdNo}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "regdNo",
                                  e.target.value
                                )
                              }
                            />
                            <Input
                              type="date"
                              value={item.dateDue}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "dateDue",
                                  e.target.value
                                )
                              }
                            />
                            <Input
                              type="number"
                              value={item.issued}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "issued",
                                  e.target.value
                                )
                              }
                            />
                            {/* Delete button for an item row */}
                            <button
                              onClick={() => {
                                // Implement logic to remove the item from the 'items' state
                                setItems((prevItems) =>
                                  prevItems.filter((i) => i.id !== item.id)
                                );
                              }}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash />
                            </button>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="mb-6">
                  <p className="font-bold">
                    ALL ITEMS LISTED ABOVE HAVE BEEN COLLECTED FROM THE
                    ORDINANCE STORE
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label>Collected By - No.</Label>
                      <Input
                        value={collectedBy.no}
                        onChange={(e) =>
                          setCollectedBy({ ...collectedBy, no: e.target.value })
                        }
                        required
                      />
                    </div>
                    <div>
                      <Label>Rank</Label>
                      <Input
                        value={collectedBy.rank}
                        onChange={(e) =>
                          setCollectedBy({
                            ...collectedBy,
                            rank: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div>
                      <Label>Name</Label>
                      <Input
                        value={collectedBy.name}
                        onChange={(e) =>
                          setCollectedBy({
                            ...collectedBy,
                            name: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="mb-6 border border-gray-900 rounded-lg p-4">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-4 font-semibold border-b pb-2 mb-2">
                      <div>Force No.</div>
                      <div>Life</div>
                      <div>Date of Issue</div>
                      <div>Brief Reasons for Unserviceability</div>
                    </div>

                    {replacementItems.map((replacementItem) => (
                      <div
                        key={replacementItem.id}
                        className="grid grid-cols-4 gap-2 items-center border-b py-2"
                      >
                        <Input
                          value={replacementItem.forceNo}
                          onChange={(e) =>
                            handleReplacementItemChange(
                              replacementItem.id,
                              "forceNo",
                              e.target.value
                            )
                          }
                        />
                        <Input
                          value={replacementItem.life}
                          onChange={(e) =>
                            handleReplacementItemChange(
                              replacementItem.id,
                              "life",
                              e.target.value
                            )
                          }
                        />
                        <Input
                          type="date"
                          value={replacementItem.dateDue}
                          onChange={(e) =>
                            handleReplacementItemChange(
                              replacementItem.id,
                              "dateDue",
                              e.target.value
                            )
                          }
                        />
                        <Input
                          value={replacementItem.reason}
                          onChange={(e) =>
                            handleReplacementItemChange(
                              replacementItem.id,
                              "reason",
                              e.target.value
                            )
                          }
                        />
                      </div>
                    ))}
                  </CardContent>

                  <div className="mb-6">
                    <p className="font-bold">
                      Recommendations of Officer/Member-in-Charge
                    </p>
                    <p>
                      Items referred to in this part to be replaced at
                      Government expense / at Member's expense
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label>at</Label>
                        <Input
                          value={officerRecommendation.at}
                          onChange={(e) =>
                            setOfficerRecommendation({
                              ...officerRecommendation,
                              at: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Rank</Label>
                        <Input
                          value={officerRecommendation.rank}
                          onChange={(e) =>
                            setOfficerRecommendation({
                              ...officerRecommendation,
                              rank: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="flex items-center gap-4">
                        <Label className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="expenseType"
                            checked={
                              officerRecommendation.expenseType === "GOVERNMENT"
                            }
                            onChange={() =>
                              setOfficerRecommendation({
                                ...officerRecommendation,
                                expenseType: "GOVERNMENT",
                              })
                            }
                          />
                          Government expense
                        </Label>
                        <Label className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="expenseType"
                            checked={
                              officerRecommendation.expenseType === "MEMBER"
                            }
                            onChange={() =>
                              setOfficerRecommendation({
                                ...officerRecommendation,
                                expenseType: "MEMBER",
                              })
                            }
                          />
                          Member's expense
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex grid-cols-2 gap-4">
                  <div className="mb-6 border border-black p-4 rounded-lg flex-1">
                    <p className="font-bold">
                      Checked by Officer/Member-in-Charge(All Requisitions)
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label>No.</Label>
                        <Input
                          value={checkedByOfficer.no}
                          onChange={(e) =>
                            setCheckedByOfficer({
                              ...checkedByOfficer,
                              no: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Rank</Label>
                        <Input
                          value={checkedByOfficer.rank}
                          onChange={(e) =>
                            setCheckedByOfficer({
                              ...checkedByOfficer,
                              rank: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mb-6 border border-black p-4 rounded-lg flex-1">
                    <p className="font-bold">
                      Checked by Quartermaster's Representative(Items on Station
                      Charge only)
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label>No.</Label>
                        <Input
                          value={checkedByQuartermaster.no}
                          onChange={(e) =>
                            setCheckedByQuartermaster({
                              ...checkedByQuartermaster,
                              no: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Rank</Label>
                        <Input
                          value={checkedByQuartermaster.rank}
                          onChange={(e) =>
                            setCheckedByQuartermaster({
                              ...checkedByQuartermaster,
                              rank: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="mb-6 border border-black p-4">
                    <p className="font-bold">Voucher Checked By</p>
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={voucherCheckedBy.initials}
                          onChange={(e) =>
                            setVoucherCheckedBy({
                              ...voucherCheckedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={voucherCheckedBy.date}
                          onChange={(e) =>
                            setVoucherCheckedBy({
                              ...voucherCheckedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mb-6 border border-black p-4">
                    <p className="font-bold">Items Selected By</p>
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={itemsSelectedBy.initials}
                          onChange={(e) =>
                            setItemsSelectedBy({
                              ...itemsSelectedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={itemsSelectedBy.date}
                          onChange={(e) =>
                            setItemsSelectedBy({
                              ...itemsSelectedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mb-6 border border-black p-4">
                    <p className="font-bold">Method of Issue/Despatch</p>
                    <div className="grid grid-cols-2 gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={dispatchMethodDetails.collected}
                          onChange={(e) =>
                            handleDispatchMethodChange(
                              "collected",
                              e.target.checked
                            )
                          }
                        />
                        <Label>Collected</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={dispatchMethodDetails.rail}
                          onChange={(e) =>
                            handleDispatchMethodChange("rail", e.target.checked)
                          }
                        />
                        <Label>Rail</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={dispatchMethodDetails.road}
                          onChange={(e) =>
                            handleDispatchMethodChange("road", e.target.checked)
                          }
                        />
                        <Label>Road</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={dispatchMethodDetails.air}
                          onChange={(e) =>
                            handleDispatchMethodChange("air", e.target.checked)
                          }
                        />
                        <Label>Air</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={dispatchMethodDetails.registeredMail}
                          onChange={(e) =>
                            handleDispatchMethodChange(
                              "registeredMail",
                              e.target.checked
                            )
                          }
                        />
                        <Label>Registered Mail</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={dispatchMethodDetails.parcelPost}
                          onChange={(e) =>
                            handleDispatchMethodChange(
                              "parcelPost",
                              e.target.checked
                            )
                          }
                        />
                        <Label>Parcel Post</Label>
                      </div>
                    </div>
                    <div>
                      <Label>Parcel/Warrant No.</Label>
                      <Input
                        type="text"
                        value={dispatchMethodDetails.parcelWarrantNo}
                        onChange={(e) =>
                          handleDispatchMethodChange(
                            "parcelWarrantNo",
                            e.target.value
                          )
                        }
                      />
                    </div>
                  </div>

                  <div className="mb-6 border border-black p-4">
                    <p className="font-bold">Items Packed By</p>
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={itemsPackedBy.initials}
                          onChange={(e) =>
                            setItemsPackedBy({
                              ...itemsPackedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={itemsPackedBy.date}
                          onChange={(e) =>
                            setItemsPackedBy({
                              ...itemsPackedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mb-6 border border-black p-4">
                    <p className="font-bold">Entered on Clothing Card</p>
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={enteredOnClothingCard.initials}
                          onChange={(e) =>
                            setEnteredOnClothingCard({
                              ...enteredOnClothingCard,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={enteredOnClothingCard.date}
                          onChange={(e) =>
                            setEnteredOnClothingCard({
                              ...enteredOnClothingCard,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mb-6 border border-black p-4">
                    <p className="font-bold">Ledger Actioned</p>
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={ledgerActioned.initials}
                          onChange={(e) =>
                            setLedgerActioned({
                              ...ledgerActioned,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={ledgerActioned.date}
                          onChange={(e) =>
                            setLedgerActioned({
                              ...ledgerActioned,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      // Reset all form fields
                      setOrdinanceControlNo("");
                      setStation("");
                      setBranch("");
                      setDispatchMethod("CALLED FOR");
                      setDate(new Date().toISOString().split("T")[0]);
                      setItems([createEmptyRequiredItem(1)]);
                      setReplacementItems([createEmptyReplacementItem(1)]);
                      setCollectedBy({ no: "", rank: "", name: "" });
                      setOfficerRecommendation({
                        at: "",
                        rank: "",
                        expenseType: "GOVERNMENT",
                      });
                      setCheckedByOfficer({ no: "", rank: "" });
                      setCheckedByQuartermaster({ no: "", rank: "" });
                      setVoucherCheckedBy({ initials: "", date: "" });
                      setItemsSelectedBy({ initials: "", date: "" });
                      setDispatchMethodDetails({
                        collected: false,
                        rail: false,
                        road: false,
                        air: false,
                        registeredMail: false,
                        parcelPost: false,
                        parcelWarrantNo: "",
                      });
                      setItemsPackedBy({ initials: "", date: "" });
                      setEnteredOnClothingCard({ initials: "", date: "" });
                      setLedgerActioned({ initials: "", date: "" });

                      toast.info("Form has been reset");
                    }}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowPreview(true)}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Requisition</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form227Pdf
            formData={formData}
            // formData={staticFormData}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
        {/* <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              Recent Reports
            </h3>

            <div className="relative flex items-center">
              <input
                aria-label="Search"
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                id="search"
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by report no, station..."
                type="text"
                value={searchTerm}
              />
              <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                <Search />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Report No.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Station
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date Issued
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredVouchers.length > 0 ? (
                    filteredVouchers.map((voucher, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {voucher.voucher_no}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.issue_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completed
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        className="px-6 py-4 text-sm text-gray-500 text-center"
                        colSpan="4"
                      >
                        {requisitionVouchers.length === 0
                          ? "No recent reports found"
                          : "No matching reports found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <a
              className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
              href="#"
            >
              <List /> View All Reports
            </a>
          </div>
        </div> */}
      </div>
    </>
  );
};

export default RequisitionForm;
