import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import RejectionCertificatePdf from "@/formPdfs/RejectionCertificatePdf";

type RejectedItem = {
  id: number;
  item: string;
  qty: string;
  dNote: string;
  orderNo: string;
  rejected: string;
  accepted: string;
  value: string;
};

const RejectionCertificate = () => {
  // Form state with sample data
  const [formData, setFormData] = useState({
    entryNo: "",
    certificateNo: "",
    inspectorInfo: {
      number: "",
      rank: "",
      name: ""
    },
    supplier: "",
    items: [
      {
    
        item: "",
        qty: "",
        dNote: "",
        orderNo: "",
        rejected: "",
        accepted: "",
        value: ""
      }
    ] as RejectedItem[],
    allAccepted: false,
    allRejected: false,
    rejectionReason: "",
    qualification: "",
    yearsServed: "",
    signature: "",
    date: "",
    witnessInfo: {
      fNumber: "",
      rank: "",
      name: "",
      officeHeld: ""
    }
  });

  const [showPreview, setShowPreview] = useState(false);

  // Add new row when last row starts being filled
  useEffect(() => {
    const lastItem = formData.items[formData.items.length - 1];
    if (lastItem && (lastItem.item || lastItem.qty || lastItem.dNote || 
        lastItem.orderNo || lastItem.rejected || lastItem.accepted || lastItem.value)) {
      setFormData(prev => ({
        ...prev,
        items: [
          ...prev.items,
          {
            id: prev.items.length + 1,
            item: "",
            qty: "",
            dNote: "",
            orderNo: "",
            rejected: "",
            accepted: "",
            value: ""
          }
        ]
      }));
    }
  }, [formData.items]);

  const handleItemChange = (id: number, field: keyof RejectedItem, value: string) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      )
    }));
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNestedChange = (parent: string, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [field]: value
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter out empty items
    const submittedItems = items.filter(
      (item) =>
        item.item ||
        item.qty ||
        item.dNote ||
        item.orderNo ||
        item.rejected ||
        item.accepted ||
        item.value
    );

    // Create form data object
    const formData = {
      entryNo,
      certificateNo,
      inspectorInfo,
      supplier,
      rejectionReason,
      qualification,
      yearsServed,
      signature,
      date,
      witnessInfo,
      items: submittedItems,
      allAccepted,
      allRejected
    };

    // Submit to server
    Server.addRejectionCertificate(formData)
      .then(() => {
        toast.success("Rejection certificate successfully submitted");
        setShowPreview(true);
      })
      .catch((error) => {
        toast.error(error.message || "Failed to submit rejection certificate");
      });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setFormData({
      entryNo: "",
      certificateNo: "",
      inspectorInfo: {
        number: "",
        rank: "",
        name: ""
      },
      supplier: "",
      items: [{
        id: 1,
        item: "",
        qty: "",
        dNote: "",
        orderNo: "",
        rejected: "",
        accepted: "",
        value: ""
      }],
      allAccepted: false,
      allRejected: false,
      rejectionReason: "",
      qualification: "",
      yearsServed: "",
      signature: "",
      date: "",
      witnessInfo: {
        fNumber: "",
        rank: "",
        name: "",
        officeHeld: ""
      }
    });
    toast.info("Form has been reset");
  };

  // Recent reports data
  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers] = useState([
    {
      voucher_no: "RC-2024-001",
      supplier: "Uniforms Ltd",
      issue_date: "2024-05-10",
      status: "Completed"
    },
    {
      voucher_no: "RC-2024-002",
      supplier: "Leather Goods Co",
      issue_date: "2024-05-12",
      status: "Pending"
    }
  ]);

  const filteredVouchers = requisitionVouchers.filter(voucher => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.supplier).toLowerCase().includes(searchLower)
    );
  });
  const staticPdfData = {
    entryNo: "RC-001",
    certificateNo: "CERT-001",
    inspectorInfo: {
      number: "I-123",
      rank: "Inspector",
      name: "John Moyo"
    },
    supplier: "Uniforms Ltd",
    items: [
      {
        id: 1,
        item: "Combat Boots",
        qty: "10",
        dNote: "DN-2024-001",
        orderNo: "ORD-2024-001",
        rejected: "2",
        accepted: "8",
        value: "$200"
      },
      {
        id: 2,
        item: "Leather Belts",
        qty: "15",
        dNote: "DN-2024-001",
        orderNo: "ORD-2024-001",
        rejected: "5",
        accepted: "10",
        value: "$150"
      }
    ],
    allRejected: true,
    rejectionReason: "Poor stitching quality and substandard leather",
    qualification: "Master Tailor",
    yearsServed: "5",
    signature: "J. Moyo",
    date: "2024-05-15",
    witnessInfo: {
      fNumber: "F-456",
      rank: "Sergeant",
      name: "Alice Banda",
      officeHeld: "Store Manager"
    }
  };
  
  return (
    <div className="flex">
      {!showPreview ? (
        <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
          <CardHeader className="pb-0">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-blue-900">
                GOODS RECEIVED REGISTER
              </h1>
              <p className="text-sm text-gray-600">
                Entry No:{" "}
                <Input
                  className="inline w-32"
                  value={formData.entryNo}
                  onChange={(e) => handleInputChange("entryNo", e.target.value)}
                />
                /2024
              </p>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-4 text-center">
                  ORDNANCE STORES REJECTION CERTIFICATE
                </h2>
                <div className="mb-4">
                  <Label className="font-bold">
                    CERTIFICATE NUMBER{" "}
                    <Input
                      className="inline w-32"
                      value={formData.certificateNo}
                      onChange={(e) => handleInputChange("certificateNo", e.target.value)}
                    />
                    /2024
                  </Label>
                </div>

                {/* Inspector Info */}
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <Label>Number</Label>
                    <Input
                      value={formData.inspectorInfo.number}
                      onChange={(e) => handleNestedChange("inspectorInfo", "number", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Rank</Label>
                    <Input
                      value={formData.inspectorInfo.rank}
                      onChange={(e) => handleNestedChange("inspectorInfo", "rank", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Name</Label>
                    <Input
                      value={formData.inspectorInfo.name}
                      onChange={(e) => handleNestedChange("inspectorInfo", "name", e.target.value)}
                    />
                  </div>
                </div>

                <p className="mb-4">
                  of <strong>PGHQ TAILORS / SADDLERS</strong> have on this
                  date examined the following items from
                </p>

                <div className="mb-4">
                  <Label>Supplier</Label>
                  <Input
                    value={formData.supplier}
                    onChange={(e) => handleInputChange("supplier", e.target.value)}
                    placeholder="Supplier name"
                  />
                </div>

                {/* Items Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-7 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Item</div>
                    <div>Qty</div>
                    <div>D/Note</div>
                    <div>Order No.</div>
                    <div>Rejected</div>
                    <div>Accepted</div>
                    <div>Value</div>
                  </div>

                  {formData.items.map((item) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-7 gap-2 items-center border-b py-2"
                    >
                      <Input
                        value={item.item}
                        onChange={(e) => handleItemChange(item.id, "item", e.target.value)}
                      />
                      <Input
                        value={item.qty}
                        onChange={(e) => handleItemChange(item.id, "qty", e.target.value)}
                      />
                      <Input
                        value={item.dNote}
                        onChange={(e) => handleItemChange(item.id, "dNote", e.target.value)}
                      />
                      <Input
                        value={item.orderNo}
                        onChange={(e) => handleItemChange(item.id, "orderNo", e.target.value)}
                      />
                      <Input
                        value={item.rejected}
                        onChange={(e) => handleItemChange(item.id, "rejected", e.target.value)}
                      />
                      <Input
                        value={item.accepted}
                        onChange={(e) => handleItemChange(item.id, "accepted", e.target.value)}
                      />
                      <Input
                        value={item.value}
                        onChange={(e) => handleItemChange(item.id, "value", e.target.value)}
                      />
                    </div>
                  ))}
                </div>

                {/* Certification Section */}
                <div className="mb-4">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="all-accepted"
                        checked={formData.allAccepted}
                        onCheckedChange={(checked) => {
                          handleInputChange("allAccepted", !!checked);
                          if (checked) handleInputChange("allRejected", false);
                        }}
                      />
                      <Label htmlFor="all-accepted">
                        All items are of good quality and must be taken into stock
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="all-rejected"
                        checked={formData.allRejected}
                        onCheckedChange={(checked) => {
                          handleInputChange("allRejected", !!checked);
                          if (checked) handleInputChange("allAccepted", false);
                        }}
                      />
                      <Label htmlFor="all-rejected">
                        I have rejected items for the following reasons:
                      </Label>
                    </div>
                    <div className="ml-6">
                      <Input
                        value={formData.rejectionReason}
                        onChange={(e) => handleInputChange("rejectionReason", e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                {/* Qualifications */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label>My Qualification</Label>
                    <Input
                      value={formData.qualification}
                      onChange={(e) => handleInputChange("qualification", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Years of Service</Label>
                    <Input
                      value={formData.yearsServed}
                      onChange={(e) => handleInputChange("yearsServed", e.target.value)}
                    />
                  </div>
                </div>

                {/* Signature and Date */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label>Signature</Label>
                    <Input
                      value={formData.signature}
                      onChange={(e) => handleInputChange("signature", e.target.value)}
                    />
                    <p className="text-xs italic">[QUALITY CONTROLLER]</p>
                  </div>
                  <div>
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={formData.date}
                      onChange={(e) => handleInputChange("date", e.target.value)}
                    />
                  </div>
                </div>

                {/* Witness Information */}
                <div className="grid grid-cols-4 gap-4">
                  <div>
                    <Label>F/Number</Label>
                    <Input
                      value={formData.witnessInfo.fNumber}
                      onChange={(e) => handleNestedChange("witnessInfo", "fNumber", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Rank</Label>
                    <Input
                      value={formData.witnessInfo.rank}
                      onChange={(e) => handleNestedChange("witnessInfo", "rank", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Name</Label>
                    <Input
                      value={formData.witnessInfo.name}
                      onChange={(e) => handleNestedChange("witnessInfo", "name", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Office Held</Label>
                    <Input
                      value={formData.witnessInfo.officeHeld}
                      onChange={(e) => handleNestedChange("witnessInfo", "officeHeld", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-between mt-6">
                <Button type="button" variant="outline" onClick={handleReset}>
                  Reset Form
                </Button>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowPreview(true)}
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Print Preview
                  </Button>
                  <Button type="submit">Submit Certificate</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <RejectionCertificatePdf
          // formData={formData}
          formData={staticPdfData}
          onBack={() => setShowPreview(false)}
          onPrint={handlePrint}
        />
      )}

      {/* Recent Reports Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="space-y-4">
          <h3 className="text-xl font-semibold flex items-center gap-2">
            Recent Certificates
          </h3>
          <div className="relative flex items-center">
            <input
              aria-label="Search"
              className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by certificate no, supplier..."
            />
            <button className="absolute right-3 text-gray-500 hover:text-blue-600">
              <Search />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cert. No.
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Supplier
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredVouchers.map((voucher, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {voucher.voucher_no}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {voucher.supplier}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {voucher.issue_date}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        voucher.status === "Completed" 
                          ? "bg-green-100 text-green-800" 
                          : "bg-yellow-100 text-yellow-800"
                      }`}>
                        {voucher.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <a className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2">
            <List /> View All Certificates
          </a>
        </div>
      </div>
    </div>
  );
};

export default RejectionCertificate;