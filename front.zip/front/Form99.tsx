import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Printer, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import Form99Pdf from "@/formPdfs/Form99Pdf";

type KitItem = {
  id: number;
  name: string;
  handedIn: string;
  deficient: string;
  cost: string;
  ordinanceUse: string;
  isGroup?: boolean;
  groupItems?: KitItem[];
  expanded?: boolean;
};

const Form99 = () => {
  const [forceNo, setForceNo] = useState("");
  const [rank, setRank] = useState("");
  const [name, setName] = useState("");
  const [station, setStation] = useState("");
  const [branch, setBranch] = useState("");

  // Group similar items together
  const groupedKitItems = [
    {
      name: "Badges",
      items: [
        "Badge Flag Police",
        "Badge Flag Zim",
        "Badge Police G/B",
        "Badges of Rank",
        "Badges, Arm S/cst",
        "Badges, Cap, Emb W/P",
        "Badges, Cap, Shako",
      ]
    },
    {
      name: "Belts",
      items: [
        "Belt Stable",
        "Belt Stable Chaplain",
        "Belt, Leather",
        "Belt, Web",
      ]
    },
    {
      name: "Boots",
      items: [
        "Boots, Black",
        "Boots, Brown",
        "Boots, Canvas",
        "Boots Greep Sole",
        "Boots riding",
        "Boots Veldskoen",
        "Boots,Combat",
      ]
    },
    {
      name: "Caps",
      items: [
        "Cap Nurse",
        "Cap, Combat",
        "Cap, Drab",
        "Cap Drab Chaplain",
        "Cap, Dispatch",
        "Cap, F.D. Blue",
        "Cap, Poncho",
        "Cap, STU",
      ]
    },
    {
      name: "Coats",
      items: [
        "Coat rain",
        "Coat Trench",
        "Coat Trench W/P",
        "Coat, Dust White",
      ]
    },
    {
      name: "Dresses",
      items: [
        "Dress, W/P, Winter",
        "Dress, W/P., Summer",
      ]
    },
    {
      name: "Epaulettes",
      items: [
        "Epaulettes",
        "Epaulettes, W/P.",
      ]
    },
    {
      name: "Gloves",
      items: [
        "Gloves, Blue, W/P",
        "Gloves, Driving, W/P",
        "Gloves, Leather, Khaki",
        "Gloves, Leather, Unlined",
        "Gloves, White",
        "Gloves Doe Skin",
        "Gloves Nylon",
        "Gloves PVC",
      ]
    },
    {
      name: "Hats",
      items: [
        "Hat Blue Chaplain",
        "Hat Blue W/PA",
        "Hat, Soft Blue",
      ]
    },
    {
      name: "Jackets",
      items: [
        "Jacket and Slack",
        "Jacket Combat",
        "Jacket FD",
        "Jacket Patrol STU",
        "Jacket Riding",
        "Jacket Riot",
        "Jacket riot FPU",
      ]
    },
    {
      name: "Overalls",
      items: [
        "Overalls Black",
        "Overalls Blue",
        "Overalls Grey",
        "Overalls Special STU",
        "Overalls White",
      ]
    },
    {
      name: "Shirts",
      items: [
        "Shirt Blue Band",
        "Shirt Combat",
        "Shirt Combat S/S",
        "Shirt, Drab",
        "Shirt, Drab S/S",
        "Shirt, Grey",
        "Shirt, Khaki",
        "Shirt, Tech",
        "Shirt, Tee",
      ]
    },
    {
      name: "Shoes",
      items: [
        "Shoes, black",
        "Shoes, Brown",
        "Shoes, Canvas",
        "Shoes, Court",
      ]
    },
    {
      name: "Suits",
      items: [
        "Suit 3 piece",
        "Suit Bag",
        "Suit Eton",
        "Suit FD",
        "Suit rain jungle green",
        "Suit riot",
        "Suit Terylene",
        "Suit Track",
        "Suit work",
      ]
    },
    {
      name: "Trousers",
      items: [
        "Trousers, Combat",
        "Trousers riding",
        "Trousers riot",
        "Trousers riot FPU",
        "Trousers Tetrex",
      ]
    },
    {
      name: "Uniforms",
      items: [
        "Uniform Grey Nurse",
        "Uniform, F.D., Band",
      ]
    },
    // Other individual items
    ...["Aigulette, Gold, Band", "Bag, Kit", "Bag, Sleeping", "Baton", "Blanket", 
        "Blouse, Terylene", "Bottle Oil", "Breeches Riding", "Brooches Force No.", 
        "Brush, Cleaning", "Buckle", "Buttons, Large", "Buttons, Medium", 
        "Buttons, Small", "Cane, Leather", "Cardigan Blue", "Case Pistol Web", 
        "Chest Web", "Cover, Pocket Book", "Curtain, Mosquito", "Drawers", 
        "Fork, Table", "Frog, Bayonet", "Frog, Sword", "Gauntlets, M/C.", 
        "Grip canvas", "Halyard", "Hand cuffs", "Helmet, Crash", "Housewife", 
        "Identity Card", "Jersey Grey", "Kit Cleaning FN", "Knife Table", 
        "Lamp Police", "Lanyard Pistol", "Lanyard Purple", "Lanyard Whistle", 
        "Leggings Leather", "Manual First Aid", "Mug Steel", "Pack Back Small", 
        "Pantaloons Blue Drill", "Pantihose", "Peak S/R", "Pillow Leather", 
        "Plate Steel", "Police Investigation Manual", "Pouches Magazine", 
        "Pull Through Rifle", "Puttees Pair", "Rifle", "Sash S/M", 
        "Satchel Blue W/P", "Shako Band", "Sheet Bed", "Shelter Light Weight", 
        "Shorts PT", "Shorts, Terylene", "Skirt blue CIV", "Skirt Summer", 
        "Sleeves Traffic", "Slips Pillow", "Socks Black Pair", "Socks Khaki Pair", 
        "Spoon Table", "Spurs Jack Pair", "Stars Gilded", "Stars Gilt Embro", 
        "Stars Gilt Min", "Stairs Min Embro", "Stockings BT", "Stockings Khaki", 
        "Stockings W/P", "Tabard reflective", "Tie Black", "Tie Blue", "Tin Mess", 
        "Titles “A”", "Titles Airwing", "Titles Z.R.P.", "Towel, Hand", "Veil Face", 
        "Vest", "Visor", "Web. Equip. Set 69 patt", "Whistle"]
      .map(item => ({ name: item, items: [] }))
  ];

  // Initialize state with grouped items
  const [items, setItems] = useState<KitItem[]>(() => {
    let id = 1;
    const result: KitItem[] = [];
    
    groupedKitItems.forEach(group => {
      if (group.items.length > 0) {
        // This is a group
        const groupItems = group.items.map(item => ({
          id: id++,
          name: item,
          handedIn: "",
          deficient: "",
          cost: "",
          ordinanceUse: ""
        }));
        
        result.push({
          id: id++,
          name: group.name,
          handedIn: "",
          deficient: "",
          cost: "",
          ordinanceUse: "",
          isGroup: true,
          groupItems,
          expanded: false
        });
      } else {
        // Individual item
        result.push({
          id: id++,
          name: group.name,
          handedIn: "",
          deficient: "",
          cost: "",
          ordinanceUse: ""
        });
      }
    });
    
    return result;
  });

  const [receivedBy, setReceivedBy] = useState({
    initials1: "",
    date1: "",
    initials2: "",
    date2: "",
    initials3: "",
    date3: "",
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleItemChange = (
    id: number,
    field: keyof KitItem,
    value: string
  ) => {
    setItems(prev =>
      prev.map(item => {
        if (item.id === id) {
          return { ...item, [field]: value };
        }
        
        // Also check group items
        if (item.isGroup && item.groupItems) {
          const updatedGroupItems = item.groupItems.map(groupItem => {
            if (groupItem.id === id) {
              return { ...groupItem, [field]: value };
            }
            return groupItem;
          });
          
          return { ...item, groupItems: updatedGroupItems };
        }
        
        return item;
      })
    );
  };

  const toggleGroup = (id: number) => {
    setItems(prev =>
      prev.map(item => 
        item.id === id 
          ? { ...item, expanded: !item.expanded } 
          : item
      )
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <>
      {!showPreview ? (
        <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm">
          <CardHeader className="pb-0">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
              <p className="text-sm text-gray-600">
                FORM 99 - KIT HANDED IN ON DISCHARGE
              </p>
              <p className="text-xs text-gray-500 mt-1">
                SEE Section 34 OF Chapter 4 And Appendix 21 of Standing Orders
                and section 52 and Appendix "A" of Special Constabulary Orders.
              </p>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Member Information */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div>
                  <Label>Force No.</Label>
                  <Input
                    value={forceNo}
                    onChange={(e) => setForceNo(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Rank</Label>
                  <Input
                    value={rank}
                    onChange={(e) => setRank(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Name</Label>
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Station</Label>
                  <Input
                    value={station}
                    onChange={(e) => setStation(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Branch</Label>
                  <Input
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                  />
                </div>
              </div>

              {/* Legend */}
              <div className="grid grid-cols-4 gap-2 mb-2 text-sm font-semibold">
                <div>Column "A" - Number of Items Handed In</div>
                <div>Column "B" - Number of Items Deficient</div>
                <div>Column "C" - Costs of Deficient Items</div>
                <div>Column "D" - Ordinance Use Only</div>
              </div>

              {/* Kit Items Table */}
              <div className="mb-6 border rounded-lg overflow-hidden">
                <div className="grid grid-cols-5 gap-2 font-semibold bg-gray-50 p-2">
                  <div>Item Description</div>
                  <div>A</div>
                  <div>B</div>
                  <div>C ($ c)</div>
                  <div>D</div>
                </div>

                <div className="max-h-[500px] overflow-y-auto">
                  {items.map((item) => (
                    <div key={item.id}>
                      <div className="grid grid-cols-5 gap-2 items-center border-b p-2">
                        <div className="text-sm flex items-center">
                          {item.isGroup ? (
                            <button
                              type="button"
                              onClick={() => toggleGroup(item.id)}
                              className="mr-2"
                            >
                              {item.expanded ? (
                                <ChevronUp className="h-4 w-4" />
                              ) : (
                                <ChevronDown className="h-4 w-4" />
                              )}
                            </button>
                          ) : null}
                          {item.name}
                        </div>
                        {item.isGroup ? (
                          <div className="col-span-4 text-sm text-gray-500">
                            {item.groupItems?.length} variations
                          </div>
                        ) : (
                          <>
                            <Input
                              type="number"
                              value={item.handedIn}
                              onChange={(e) =>
                                handleItemChange(item.id, "handedIn", e.target.value)
                              }
                              className="h-8"
                            />
                            <Input
                              type="number"
                              value={item.deficient}
                              onChange={(e) =>
                                handleItemChange(item.id, "deficient", e.target.value)
                              }
                              className="h-8"
                            />
                            <Input
                              value={item.cost}
                              onChange={(e) =>
                                handleItemChange(item.id, "cost", e.target.value)
                              }
                              className="h-8"
                            />
                            <Input
                              value={item.ordinanceUse}
                              onChange={(e) =>
                                handleItemChange(
                                  item.id,
                                  "ordinanceUse",
                                  e.target.value
                                )
                              }
                              className="h-8"
                            />
                          </>
                        )}
                      </div>

                      {/* Render group items if expanded */}
                      {item.isGroup && item.expanded && item.groupItems?.map((groupItem) => (
                        <div
                          key={groupItem.id}
                          className="grid grid-cols-5 gap-2 items-center border-b p-2 pl-8 bg-gray-50"
                        >
                          <div className="text-sm">{groupItem.name}</div>
                          <Input
                            type="number"
                            value={groupItem.handedIn}
                            onChange={(e) =>
                              handleItemChange(groupItem.id, "handedIn", e.target.value)
                            }
                            className="h-8"
                          />
                          <Input
                            type="number"
                            value={groupItem.deficient}
                            onChange={(e) =>
                              handleItemChange(groupItem.id, "deficient", e.target.value)
                            }
                            className="h-8"
                          />
                          <Input
                            value={groupItem.cost}
                            onChange={(e) =>
                              handleItemChange(groupItem.id, "cost", e.target.value)
                            }
                            className="h-8"
                          />
                          <Input
                            value={groupItem.ordinanceUse}
                            onChange={(e) =>
                              handleItemChange(
                                groupItem.id,
                                "ordinanceUse",
                                e.target.value
                              )
                            }
                            className="h-8"
                          />
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <div className="font-bold">First Column Total: $</div>
                <div>
                  <Input />
                </div>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div>
                  <Label>Initials</Label>
                  <Input
                    value={receivedBy.initials1}
                    onChange={(e) =>
                      setReceivedBy({
                        ...receivedBy,
                        initials1: e.target.value,
                      })
                    }
                  />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={receivedBy.date1}
                    onChange={(e) =>
                      setReceivedBy({ ...receivedBy, date1: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label>Initials</Label>
                  <Input
                    value={receivedBy.initials2}
                    onChange={(e) =>
                      setReceivedBy({
                        ...receivedBy,
                        initials2: e.target.value,
                      })
                    }
                  />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={receivedBy.date2}
                    onChange={(e) =>
                      setReceivedBy({ ...receivedBy, date2: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label>Initials</Label>
                  <Input
                    value={receivedBy.initials3}
                    onChange={(e) =>
                      setReceivedBy({
                        ...receivedBy,
                        initials3: e.target.value,
                      })
                    }
                  />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={receivedBy.date3}
                    onChange={(e) =>
                      setReceivedBy({ ...receivedBy, date3: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="mb-4">
                <p className="font-semibold">
                  Received and Actioned by Officer/Member-in-Charge
                </p>
              </div>

              {/* Form Actions */}
              <div className="flex justify-between mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => toast.info("Form reset")}
                >
                  Reset Form
                </Button>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowPreview(true)}
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Print Preview
                  </Button>
                  <Button type="submit">Submit Form</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Form99Pdf
        // formData={
        //   null
        // }
        onBack={() => setShowPreview(false)}
        onPrint={handlePrint}
        />
      )}
    </>
  );
};

export default Form99;