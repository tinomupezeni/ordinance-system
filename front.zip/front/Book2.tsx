import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import Book2Pdf from "@/formPdfs/Book2Pdf";

type IssueItem = {
  id: number;
  description: string;
  quantity: string;
  remarks: string;
};

type FormData = {
  issuedBy: string;
  issuedTo: string;
  dispatchMethod: string;
  receivedBy: string;
  receivedDate: string;
  recipientNo: string;
  recipientRank: string;
  recipientName: string;
  recipientStation: string;
  certifiedBy: string;
  certifiedDate: string;
  ivNo: string;
  ivDate: string;
  reqnNo: string;
  reqnDate: string;
  items: IssueItem[];
};

const Book2 = () => {
  const [formData, setFormData] = useState<FormData>({
    issuedBy: "",
    issuedTo: "",
    dispatchMethod: "",
    receivedBy: "",
    receivedDate: "",
    recipientNo: "",
    recipientRank: "",
    recipientName: "",
    recipientStation: "",
    certifiedBy: "",
    certifiedDate: "",
    ivNo: "",
    ivDate: "",
    reqnNo: "",
    reqnDate: "",
    items: [
      {
        id: 1,
        description: "",
        quantity: "",
        remarks: "",
      }
    ]
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleItemChange = (
    id: number,
    field: keyof IssueItem,
    value: string
  ) => {
    setFormData(prev => {
      const updatedItems = prev.items.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      );

      // Add new row if description is filled in the last row
      if (field === 'description' && 
          value !== "" && 
          id === prev.items[prev.items.length - 1].id) {
        return {
          ...prev,
          items: [
            ...updatedItems,
            {
              id: prev.items.length + 1,
              description: "",
              quantity: "",
              remarks: "",
            }
          ]
        };
      }

      return {
        ...prev,
        items: updatedItems
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter out empty items (where description is empty)
    const submittedItems = formData.items.filter(item => item.description.trim() !== "");
    
    const completeFormData = {
      ...formData,
      items: submittedItems
    };
    
    console.log("Form data to be sent to PDF:", completeFormData);
    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setFormData({
      issuedBy: "",
      issuedTo: "",
      dispatchMethod: "",
      receivedBy: "",
      receivedDate: "",
      recipientNo: "",
      recipientRank: "",
      recipientName: "",
      recipientStation: "",
      certifiedBy: "",
      certifiedDate: "",
      ivNo: "",
      ivDate: "",
      reqnNo: "",
      reqnDate: "",
      items: [
        {
          id: 1,
          description: "",
          quantity: "",
          remarks: "",
        }
      ]
    });
    toast.info("Form has been reset");
  };

  return (
    <>
      {!showPreview ? (
        <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm">
          <CardHeader className="pb-0">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
              <p className="text-sm text-gray-600">
                Z.R.P. BOOK 2 - ISSUE VOUCHER
              </p>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Header Information */}
              <div className="mb-6 space-y-4">
                <div>
                  <Label>Issued by</Label>
                  <Input
                    value={formData.issuedBy}
                    onChange={(e) => handleInputChange("issuedBy", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Issued to</Label>
                  <Input
                    value={formData.issuedTo}
                    onChange={(e) => handleInputChange("issuedTo", e.target.value)}
                  />
                </div>
                <div>
                  <Label>How despatched</Label>
                  <Input
                    value={formData.dispatchMethod}
                    onChange={(e) => handleInputChange("dispatchMethod", e.target.value)}
                  />
                </div>
              </div>

              {/* Recipient Information */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div>
                  <Label>Received by (Signature)</Label>
                  <Input
                    value={formData.receivedBy}
                    onChange={(e) => handleInputChange("receivedBy", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={formData.receivedDate}
                    onChange={(e) => handleInputChange("receivedDate", e.target.value)}
                  />
                </div>
                <div>
                  <Label>No.</Label>
                  <Input
                    value={formData.recipientNo}
                    onChange={(e) => handleInputChange("recipientNo", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Rank</Label>
                  <Input
                    value={formData.recipientRank}
                    onChange={(e) => handleInputChange("recipientRank", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Name</Label>
                  <Input
                    value={formData.recipientName}
                    onChange={(e) => handleInputChange("recipientName", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Station</Label>
                  <Input
                    value={formData.recipientStation}
                    onChange={(e) => handleInputChange("recipientStation", e.target.value)}
                  />
                </div>
              </div>

              {/* Certification */}
              <div className="mb-6">
                <p className="font-semibold mb-2">
                  CERTIFIED that items marked * have been recorded on Inventory.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Officer/Member-in-Charge (Signature)</Label>
                    <Input
                      value={formData.certifiedBy}
                      onChange={(e) => handleInputChange("certifiedBy", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={formData.certifiedDate}
                      onChange={(e) => handleInputChange("certifiedDate", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div className="mb-6 p-4 bg-gray-50 rounded text-xs">
                <p>
                  NOTES.—Issue Voucher will be completed in QUADRUPLICATE, the
                  ORIGINAL and SECOND copy being forwarded to the receiving
                  Station under separate cover. The THIRD copy will be marked
                  PACKING NOTE and enclosed with the consignment. The FOURTH
                  copy will be retained in the Issue Voucher Book of the issuing
                  Station. The ORIGINAL will, on receipt of the consignment, be
                  receipted and returned to the issuing Station where it will be
                  pasted to the FOURTH copy in the Issue Voucher Book, except
                  when it is required to support other documents, e.g., Arms and
                  Ammunition Returns, when suitable endorsement will be made on
                  the FOURTH copy.
                </p>
              </div>

              {/* Voucher Numbers */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div>
                  <Label>I.V. No.</Label>
                  <Input
                    value={formData.ivNo}
                    onChange={(e) => handleInputChange("ivNo", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={formData.ivDate}
                    onChange={(e) => handleInputChange("ivDate", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Reqn. No.</Label>
                  <Input
                    value={formData.reqnNo}
                    onChange={(e) => handleInputChange("reqnNo", e.target.value)}
                  />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={formData.reqnDate}
                    onChange={(e) => handleInputChange("reqnDate", e.target.value)}
                  />
                </div>
              </div>

              {/* Items Table */}
              <div className="mb-6">
                <div className="grid grid-cols-3 gap-2 font-semibold border-b pb-2 mb-2">
                  <div>Description</div>
                  <div>Quantity</div>
                  <div>Remarks</div>
                </div>

                {formData.items.map((item) => (
                  <div
                    key={item.id}
                    className="grid grid-cols-3 gap-2 items-center border-b py-2"
                  >
                    <Input
                      value={item.description}
                      onChange={(e) =>
                        handleItemChange(item.id, "description", e.target.value)
                      }
                    />
                    <Input
                      type="number"
                      value={item.quantity}
                      onChange={(e) =>
                        handleItemChange(item.id, "quantity", e.target.value)
                      }
                    />
                    <Input
                      value={item.remarks}
                      onChange={(e) =>
                        handleItemChange(item.id, "remarks", e.target.value)
                      }
                    />
                  </div>
                ))}
              </div>

              {/* Form Actions */}
              <div className="flex justify-between mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                >
                  Reset Form
                </Button>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      const submittedItems = formData.items.filter(item => 
                        item.description.trim() !== ""
                      );
                      setShowPreview(true);
                    }}
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Print Preview
                  </Button>
                  <Button type="submit">Submit Voucher</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Book2Pdf
          formData={{
            ...formData,
            items: formData.items.filter(item => item.description.trim() !== "")
          }}
          onBack={() => setShowPreview(false)}
          onPrint={handlePrint}
        />
      )}
    </>
  );
};

export default Book2;