# your_app_name/serializers.py

from rest_framework import serializers
from ..models import ClothingItem, Stock, ClothingCategory

class ClothingItemSerializer(serializers.ModelSerializer):
    # This field will get its value from the `total_stock_quantity` property on the model
    total_stock = serializers.IntegerField(source='total_stock_quantity', read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = ClothingItem
        fields = ['id', 'name', 'full_name', 'category_name', 'total_stock', 'lifespan_months', 'is_special_issue']
        # You can add more fields if needed for your frontend display