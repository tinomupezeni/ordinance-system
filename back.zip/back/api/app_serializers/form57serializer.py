# api/app_serializers/form57serializer.py (or serializers.py)

from rest_framework import serializers
from ..models import Form57, Form57LedgerEntry, OfficeType # Adjust imports based on your actual file structure

class Form57LedgerEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Form57LedgerEntry
        fields = ['id', 'date', 'voucher', 'receipts', 'issues', 'balance', 'outstanding_orders']
        # IMPORTANT: 'id' should NOT be read_only here, as it's needed for updating existing nested items.
        # It will be ignored for new creations, but used for updates.
        read_only_fields = []


class Form57Serializer(serializers.ModelSerializer):
    ledger_entries = Form57LedgerEntrySerializer(many=True, required=False)

    class Meta:
        model = Form57
        fields = [
            'id', 'description', 'price', 'reorder_level', 'reorder_amount',
            'office',
            'ledger_entries', 'created_by', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_by', 'created_at', 'updated_at']

    def create(self, validated_data):
        # Pop the nested ledger_entries data as we'll handle it separately
        ledger_entries_data = validated_data.pop('ledger_entries', [])

        # Create the main Form57 instance
        form57 = Form57.objects.create(**validated_data)

        # Create the related Form57LedgerEntry instances
        for entry_data in ledger_entries_data:
            # If an 'id' comes for a new entry (unlikely but good to be safe), remove it.
            # DRF's create won't use it, and it's for updates.
            entry_data.pop('id', None)
            Form57LedgerEntry.objects.create(form57=form57, **entry_data)
        return form57

    def update(self, instance, validated_data):
        # Pop the nested ledger_entries data
        ledger_entries_data = validated_data.pop('ledger_entries', [])

        # Update the main Form57 instance fields
        instance.description = validated_data.get('description', instance.description)
        instance.price = validated_data.get('price', instance.price)
        instance.reorder_level = validated_data.get('reorder_level', instance.reorder_level)
        instance.reorder_amount = validated_data.get('reorder_amount', instance.reorder_amount)
        instance.office = validated_data.get('office', instance.office)
        instance.save()

        # Handle updates/creations/deletions of nested ledger entries
        # Get existing ledger entry IDs for the current Form57 instance
        existing_ledger_entry_ids = set(instance.ledger_entries.values_list('id', flat=True))
        
        # Get IDs from the incoming ledger_entries data
        incoming_ledger_entry_ids = set()
        
        for entry_data in ledger_entries_data:
            entry_id = entry_data.get('id', None)
            if entry_id:
                incoming_ledger_entry_ids.add(entry_id)
                # Update existing entry
                try:
                    ledger_entry = Form57LedgerEntry.objects.get(id=entry_id, form57=instance)
                    # Use a nested serializer for updating if there's complex validation/logic
                    # Otherwise, direct update is fine for simple fields
                    for attr, value in entry_data.items():
                        setattr(ledger_entry, attr, value)
                    ledger_entry.save()
                except Form57LedgerEntry.DoesNotExist:
                    # This case should ideally not happen if IDs are managed correctly
                    # but if it does, it means an ID was sent that doesn't belong
                    # to this form, or it's a new entry that was incorrectly given an ID.
                    # You might want to log this or raise an error.
                    pass # Or handle error for invalid ID

            else:
                # Create new entry (no ID provided in payload)
                Form57LedgerEntry.objects.create(form57=instance, **entry_data)

        # Entries to delete: those in the DB for this form but not in the incoming data
        for entry_id_to_delete in existing_ledger_entry_ids - incoming_ledger_entry_ids:
            Form57LedgerEntry.objects.filter(id=entry_id_to_delete, form57=instance).delete()

        return instance