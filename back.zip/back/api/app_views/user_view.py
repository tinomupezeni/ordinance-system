from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from ..models import Userprofile
from ..app_serializers.user_serializer import UserprofileSerializer
from django.contrib.auth.models import User
from django.utils import timezone

class UserListCreateAPIView(APIView):
    def get(self, request):
        users = Userprofile.objects.all()
        serializer = UserprofileSerializer(users, many=True)
        return Response(serializer.data)

    def post(self, request):
        # Create a new Django User first
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password') # You should handle password securely (e.g., hash it)
        rank = request.data.get('rank')
        office = request.data.get('office')
        province = request.data.get('province')
        station = request.data.get('station')

        if not all([username, email, password, rank, office, province, station]):
            return Response({"error": "Missing required fields"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = User.objects.create_user(username=username, email=email, password=password)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        # Then create the Userprofile linked to the new User
        data = {
            'user': user.id, # Pass the ID of the created User
            'rank': rank,
            'office': office,
            'province': province,
            'station': station,
            'last_active': timezone.now() # Set current time for last_active
        }
        serializer = UserprofileSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    


# your_app_name/views.py (Add this new view)

from rest_framework.generics import RetrieveUpdateAPIView
from rest_framework.permissions import IsAdminUser # Or a custom permission
from django.contrib.auth.models import User
from ..models import Userprofile
from ..app_serializers.user_serializer import UserprofileSerializer
from django.db import transaction # <--- ADD THIS IMPORT STATEMENT


class UserStatusUpdateAPIView(RetrieveUpdateAPIView):
    queryset = Userprofile.objects.all()
    serializer_class = UserprofileSerializer
    lookup_field = 'id' # Assuming you'll pass the Userprofile ID
    # permission_classes = [IsAdminUser] # Only allow admin users to update status

    def update(self, request, *args, **kwargs):
        user_profile = self.get_object()
        new_status = request.data.get('status')

        if new_status not in dict(Userprofile.STATUS_CHOICES).keys():
            return Response({"error": "Invalid status value."}, status=status.HTTP_400_BAD_REQUEST)

        # Update the Userprofile status
        user_profile.status = new_status

        # Also manage the Django User's 'is_active' based on status
        user = user_profile.user
        if new_status == 'active':
            user.is_active = True
        elif new_status == 'rejected' or new_status == 'suspended':
            user.is_active = False # Deactivate user if rejected or suspended
        # For 'pending', is_active should remain False (from initial request)

        try:
            with transaction.atomic():
                user_profile.save()
                user.save()
                serializer = self.get_serializer(user_profile)
                return Response(serializer.data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



