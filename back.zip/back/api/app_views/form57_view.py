from rest_framework import viewsets, permissions
from ..models import Form57, Form57LedgerEntry, OfficeType # Adjust import path as needed
from ..app_serializers.form57serializer import Form57Serializer, Form57LedgerEntrySerializer # Adjust import path as needed



class Form57ViewSet(viewsets.ModelViewSet):
    serializer_class = Form57Serializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        # Start with all objects
        queryset = Form57.objects.all()

        # Filter by 'office' if a query parameter is provided
        office_param = self.request.query_params.get('office')
        if office_param:
            # Validate that the provided office_param is a valid choice
            # This is important to prevent invalid lookups
            valid_offices = [choice[0] for choice in OfficeType.choices]
            if office_param in valid_offices:
                queryset = queryset.filter(office=office_param)
            else:
                # Optionally, raise an error or return an empty queryset if the office param is invalid
                from rest_framework.exceptions import ValidationError
                raise ValidationError({"office": "Invalid office type provided."})

        # Further filter by the user who created it (if desired, as per your old Form163 example)
        # For example, if a user can only see forms created by them in their specific office:
        # queryset = queryset.filter(created_by=self.request.user)

        return queryset

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class Form57LedgerEntryViewSet(viewsets.ModelViewSet):
    queryset = Form57LedgerEntry.objects.all()
    serializer_class = Form57LedgerEntrySerializer
    permission_classes = [permissions.IsAuthenticated]

    # You might want to restrict access to ledger entries to only those
    # related to forms the user has access to.
    # def get_queryset(self):
    #     # Example: Only show entries for forms the user created
    #     return Form57LedgerEntry.objects.filter(form57__created_by=self.request.user)