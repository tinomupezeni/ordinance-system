# views.py
from django.db.models import Count, Q
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from ..models import (
    Form57,
    Issuance,
    Officer,
    RequisitionForm, 
    Book2IssueVoucher, 
    Form163, 
    Form321,
    Form109,
    ExchangeVoucher,
    RejectionCertificate,
    DischargeCertificate
)

from .issues_serializers import (
    IssuanceSerializer,
    RequisitionFormSerializer,
    Book2IssueVoucherSerializer,
    Form163Serializer,
    Form321Serializer,
    Form109Serializer,
    ExchangeVoucherSerializer,
    RejectionCertificateSerializer,
    DischargeCertificateSerializer
)


class FormCountsView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        user = request.user
        
        counts = {
            'form227': {
                'total': RequisitionForm.objects.count(),
                'awaiting': RequisitionForm.objects.filter(
                    created_by=user,
                    office_in_charge_status='awaiting'
                ).count(),
                'approved': RequisitionForm.objects.filter(
                    created_by=user,
                    office_in_charge_status='approved'
                ).count(),
                'rejected': RequisitionForm.objects.filter(
                    created_by=user,
                    office_in_charge_status='rejected'
                ).count(),
            },
            'book2': {
                'total': Book2IssueVoucher.objects.count(),
                # Add status counts if Book2 has status fields
            },
            'form163': {
                'total': Form163.objects.count(),
                # Add status counts if Form163 has status fields
            },
            'form321': {
                'total': Form321.objects.count(),
                # Add status counts if Form321 has status fields
            },
            'form109': {
                'total': Form109.objects.count(),
                # Add status counts if Form109 has status fields
            },
            # 'form51': {
            #     'total': Form51.objects.filter(created_by=user).count(),
            #     # Add status counts if Form109 has status fields
            # },
            'form157': {
                'total': ExchangeVoucher.objects.count(),
                # Add status counts if Form109 has status fields
            },
             'clothing_cards':{
                'total': Officer.objects.count() 
             },
             'form57':{
                'total': Form57.objects.count() 
             },
             'form163':{
                'total': Form163.objects.count() 
             },
            # Add other forms as needed
        }

        print(counts)
        
        return Response(counts)


class FormListView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    
    # Map URL form types to their corresponding models and serializers
    FORM_MAPPING = {
        'form227': {
            'model': RequisitionForm,
            'serializer': RequisitionFormSerializer
        },
        'book2': {
            'model': Book2IssueVoucher,
            'serializer': Book2IssueVoucherSerializer
        },
         'clothing-cards': {
            'model': Issuance,
            'serializer': IssuanceSerializer
        },
        'form163': {
            'model': Form163,
            'serializer': Form163Serializer
        },
        'form321': {
            'model': Form321,
            'serializer': Form321Serializer
        },
        'form109': {
            'model': Form109,
            'serializer': Form109Serializer
        },
        'form157': {
            'model': ExchangeVoucher,
            'serializer': ExchangeVoucherSerializer
        },
        'rejection-certificate': {
            'model': RejectionCertificate,
            'serializer': RejectionCertificateSerializer
        },
        'discharge-certificate': {
            'model': DischargeCertificate,
            'serializer': DischargeCertificateSerializer
        },
       
    }
    
    def get(self, request, form_type):
        user = request.user
        
        # Check if the requested form type is valid
        if form_type not in self.FORM_MAPPING:
            return Response(
                {'error': 'Invalid form type'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        form_config = self.FORM_MAPPING[form_type]
        model = form_config['model']
        serializer_class = form_config['serializer']
        
        # Get all forms for the current user, ordered by creation date (newest first)
        forms = model.objects.order_by('-created_at')
        
        # Serialize the data
        serializer = serializer_class(forms, many=True)
        
        return Response({
            'count': forms.count(),
            'results': serializer.data
        })