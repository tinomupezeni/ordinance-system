from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from .app_views.form163_view import Form163ApproveRejectView, Form163WaitingListView

# Import all necessary views from your app_views and main views.py
# Make sure these paths are correct relative to your urls.py file.
from .views import *
from .app_views.admin_view import (
 ApproveForm163APIView,
 ApproveRequisitionView,
    CardingApproveRequisitionView,
 RejectForm163View,
)
from .app_views.issues_view import *
from .app_views.form109_view import *
from .app_views.clothing_view import *
from .app_views.form57_view import *
from .app_views.user_view import *

# Create router for ViewSets
router = DefaultRouter()
router.register(r'officers', OfficerViewSet)
router.register(r'issuances', IssuanceViewSet)
router.register(r'clothing_items', ClothingItemViewSet)
router.register(r'form57', Form57ViewSet, basename='form57') # ADD basename here
router.register(r'form57ledgerentry', Form57LedgerEntryViewSet, basename='form57ledgerentry') 
router.register(r'clothing-items-stock', ClothingItemStockViewSet, basename='clothing-item-stock')

# ... other router registrations


urlpatterns = [
    # Include router URLs first to avoid conflicts with static paths if patterns overlap
    path('', include(router.urls)), # This includes paths for /officers/, /issuances/, /clothing_items/ etc.

    # -----------------------------
    # Authentication
    path('login/', login_user, name='login_user'),
    path('signup/', register_user, name='register_user'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # Login
    path('refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # Refresh token
    path('users/', UserListCreateAPIView.as_view(), name='user-list-create'),
    path('users/<int:id>/status/', UserStatusUpdateAPIView.as_view(), name='user-status-update'), # New URL

    # -----------------------------
    # Requisition Voucher

    path('form227/', RequisitionFormCreateView.as_view(), name='create-requisition'),
    path('requisition-voucher/list/', RequisitionFormListView.as_view(), name='list-requisitions'),
    path('requisition-voucher/list/admin-authorization/', RequisitionFormListViewOfficerInChargeAuth.as_view(), name='get-requisitions'),
    path('form163/list/admin-authorization/', Form163WaitingListView.as_view(), name='get-requisitions'),
    path('form227/admin-authorization/<int:pk>/', ApproveRequisitionView.as_view(), name='admin-authorization'),
    path('form163/admin-authorization/<int:pk>/', ApproveForm163APIView.as_view(), name='admin-authorization'),
    path('form227/carding-authorization/<int:pk>/', CardingApproveRequisitionView.as_view(), name='carding-authorization'),
    path('requisition-voucher/<int:pk>/', RequisitionFormDetailView.as_view(), name='requisition-detail'),
    # -----------------------------
    # Form 321

    path('form321/', Form321CreateView.as_view(), name='create-form-321'),
    path('form321/list/', Form321ListView.as_view(), name='list-form-321'),
    path('form321/<int:pk>/', Form321DetailView.as_view(), name='form-321-detail'),
    # -----------------------------
    # Form 163

    path('form163/', Form163CreateView.as_view(), name='create-form-163'),
    path('form163/list/', Form163ListView.as_view(), name='list-form-163'),
    path('form163/<int:pk>/', Form163DetailView.as_view(), name='form-163-detail'),
      path('form163/<int:pk>/reject/', RejectForm163View.as_view(), name='form163-reject'), # Add this line
    # ...
    # -----------------------------
    # Rejection Certificate

    path('rejection-certificate/', RejectionCertificateCreateView.as_view(), name='create-rejection-certificate'),
    path('rejection-certificate/list/', RejectionCertificateListView.as_view(), name='list-rejection-certificates'),
    path('rejection-certificate/<int:pk>/', RejectionCertificateDetailView.as_view(), name='rejection-certificate-detail'),

    # -----------------------------
    # Issue Voucher Book 2

    path('book2-issue-voucher/', Book2IssueVoucherCreateView.as_view(), name='create-book2-issue-voucher'),
    path('book2-issue-voucher/<str:office>/', Book2IssueVoucherListView.as_view(), name='list-book2-issue-vouchers'),
    path('book2-issue-voucher/<int:pk>/', Book2IssueVoucherDetailView.as_view(), name='book2-issue-voucher-detail'),

    # -----------------------------
    # form 157 *
    # Note: You have 'ExchangeVoucher' for form157 which is fine, but ensure consistency
    path('form157/', ExchangeVoucherCreateView.as_view(), name='form157-create'),
    path('form157/list/<str:office>/', ExchangeVoucherListView.as_view(), name='form157-list'),
    path('form157/<int:pk>/', ExchangeVoucherDetailView.as_view(), name='form157-detail'),

    # -----------------------------
    #  Discharge Certificate

    path('discharge-certificate/', DischargeCertificateCreateView.as_view(), name='create-discharge-certificate'),
    path('discharge-certificate/list/', DischargeCertificateListView.as_view(), name='list-discharge-certificates'),
    path('discharge-certificate/<int:pk>/', DischargeCertificateDetailView.as_view(), name='discharge-certificate-detail'),

    # -----------------------------
    #  Exchange Voucher
    # This block appears to be a duplicate of the 'form 157 *' section above.
    # If form 157 IS the exchange voucher, keep one set. If they are different,
    # ensure your views are distinct. Assuming for now it's a duplicate.
    # path('exchange-voucher/', ExchangeVoucherCreateView.as_view(), name='create-exchange-voucher'),
    # path('exchange-voucher/list/', ExchangeVoucherListView.as_view(), name='list-exchange-vouchers'),
    # path('exchange-voucher/<int:pk>/', ExchangeVoucherDetailView.as_view(), name='exchange-voucher-detail'),

    # -----------------------------
    # Form 109
    path('form109/', Form109ListCreateView.as_view(), name='form109-list-create'),
    path('form109/<int:id>/', Form109RetrieveView.as_view(), name='form109-retrieve'),

    #---------------------------------
    # issues office
    # --------------------------------
    path('forms/counts/', FormCountsView.as_view(), name='form-counts'),
    path('forms/<str:form_type>/', FormListView.as_view(), name='form-list'),

    # ----------------------------
    # Clothing views (Custom Endpoints)
    # ----------------------------
    # Note: Your router already registers '/clothing_items/' for ClothingItemViewSet.
    # These custom paths might conflict or be redundant if the ViewSet covers them.
    # If these custom views (functions) offer different functionality, keep them,
    # but be aware of the potential for overlapping URLs.
    path('all-clothing-items/', clothing_by_category, name='all-clothing-items'),
    path('add-clothing-item/', add_clothing_item, name='add-clothing-item'),
    path('clothing-items/<str:category_name>/', delete_clothing_category, name='delete-clothing-category'),
    path('clothing-items/<str:category_name>/items/<str:item_name>/', delete_clothing_item, name='delete-clothing-item'),

    path('officer-data/', OfficerDataCreateView.as_view(), name='officer_data_create'),

    # form 163
      path('form163/<int:pk>/approve-reject/', Form163ApproveRejectView.as_view(), name='form163-approve-reject'),
]