import pandas as pd
from django.core.management.base import BaseCommand
from ...models import ClothingCategory, ClothingItem, Officer, IssuedClothing
from datetime import datetime

class Command(BaseCommand):
    help = 'Import ZRP Form 51 data from Excel file'

    def handle(self, *args, **options):
        # Load the Excel file
        file_path = '/home/tino/Downloads/ZRP Asset Management/zrp_clothes/api/management/commands/MASVINGO ZRP FORM 51 AS AT 20 MAY 2025.xlsx'
        df = pd.read_excel(file_path, sheet_name='Table 1', header=7)  # Data starts at row 7

        print(df.columns.tolist())

        
        # # Clean up the dataframe
        # df = df.dropna(how='all')  # Drop empty rows
        # df = df.reset_index(drop=True)
        
        # # Get all clothing item columns (from column L onwards)
        # clothing_columns = df.columns[11:]  # Columns after 'Serial' (column K)
        
        # # First pass: Extract all unique clothing items and determine their categories
        # all_items = set()
        # for col in clothing_columns:
        #     all_items.add(str(col).strip())
        
        # # Create categories based on the first part of each item name (before comma)
        # category_items = {}
        # for item in all_items:
        #     if pd.isna(item):
        #         continue
                
        #     # Split on first comma to get category
        #     if ',' in item:
        #         category = item.split(',')[0].strip()
        #     else:
        #         category = item  # Use full name as category if no comma
                
        #     # Special handling for certain categories
        #     if 'Special Issues' in item:
        #         category = 'Special Issues'
        #     elif 'Recruits' in item or 'Induction Course' in item:
        #         category = 'Recruits'
        #     elif 'Promotion' in item:
        #         category = 'Promotion'
                
        #     if category not in category_items:
        #         category_items[category] = []
        #     category_items[category].append(item)
        
        # # Create all categories in database
        # for category_name in category_items.keys():
        #     ClothingCategory.objects.get_or_create(name=category_name)
        #     self.stdout.write(self.style.SUCCESS(f'Created category: {category_name}'))
        
        # # Create all clothing items in database
        # for category_name, items in category_items.items():
        #     category = ClothingCategory.objects.get(name=category_name)
            
        #     for item_name in items:
        #         # Determine if special/recruit/promotion item
        #         is_special = 'Special Issues' in category_name
        #         is_recruit = 'Recruits' in category_name
        #         is_promotion = 'Promotion' in category_name
                
        #         # Get base name (before first comma)
        #         base_name = item_name.split(',')[0].strip() if ',' in item_name else item_name
                
        #         ClothingItem.objects.get_or_create(
        #             full_name=item_name,
        #             defaults={
        #                 'name': base_name,
        #                 'category': category,
        #                 'is_special_issue': is_special,
        #                 'is_recruit_issue': is_recruit,
        #                 'is_promotion_issue': is_promotion
        #             }
        #         )
        #         self.stdout.write(self.style.SUCCESS(f'Created item: {item_name} under {category_name}'))
        
        # # Process each officer and their issuances
        # current_officer = None
        # for _, row in df.iterrows():
        #     # Check if this is a new officer (has date_attested)
        #     if pd.notna(row['Date attested:']):
        #         # Create new officer
        #         force_no = str(row['Force No.:']) if pd.notna(row['Force No.:']) else None
        #         current_officer, created = Officer.objects.get_or_create(
        #             force_no=force_no,
        #             defaults={
        #                 'date_attested': row['Date attested:'],
        #                 'branch': row['Branch:'],
        #                 'name': row['Name:'],
        #                 'initials': row['Initials:'],
        #                 's_c_c_no': row['S.C.C No.'],
        #                 'cl_no': row['C.L. No:']
        #             }
        #         )
        #         if created:
        #             self.stdout.write(self.style.SUCCESS(f'Created officer: {current_officer.name}'))
        #     elif current_officer is None:
        #         continue  # Skip rows before first officer
                
        #     # Process each clothing item issuance
        #     for col in clothing_columns:
        #         if pd.notna(row[col]):
        #             # Get quantity (assuming 1 if not specified)
        #             try:
        #                 quantity = int(float(row[col]))  # Handle possible float values
        #             except (ValueError, TypeError):
        #                 quantity = 1
                    
        #             # Find the clothing item by full name
        #             item_name = str(col).strip()
        #             try:
        #                 item = ClothingItem.objects.get(full_name=item_name)
        #             except ClothingItem.DoesNotExist:
        #                 self.stdout.write(self.style.WARNING(f'Clothing item not found: {item_name}'))
        #                 continue
                    
        #             # Create issuance record
        #             date_issued = row['Date'] if pd.notna(row['Date']) else datetime.now().date()
                    
        #             IssuedClothing.objects.create(
        #                 officer=current_officer,
        #                 clothing_item=item,
        #                 date_issued=date_issued,
        #                 issued_by=row['Issued By'],
        #                 cl_no=row['C.L No.'],
        #                 serial_no=row['Serial'],
        #                 quantity=quantity
        #             )
        
        # self.stdout.write(self.style.SUCCESS('Successfully imported all data'))