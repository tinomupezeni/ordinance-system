# app/management/commands/populate_clothing.py
from django.core.management.base import BaseCommand
from ...models import ClothingCategory, ClothingItem

class Command(BaseCommand):
    help = 'Populates the database with clothing categories and items'

    def handle(self, *args, **kwargs):
        # Female/unisex items
        female_data = {
            "Badges": [
                "Hat Emb.",
                "Collar",
                "Slip On",
                "Sergeant Major",
                "Flag Zimbabwe",
                "Flag Police",
                "Police Grey",
            ],
            "Belts": ["Stable Chaplain", "Web"],
            "Boots": ["Combat", "CrepeSole", "Superpro"],
            "Buttons": ["Medium", "Small"],
            "Gloves": ["Driving", "Navy Blue", "White"],
            "Hats": ["Navy Blue W/P", "Blue Chaplain", "Blue Band"],
            "Jackets": ["Riot", "Waterproof", "Webbing"],
            "Peaks": ["Double Row", "Single Row", "Triple Row"],
            "Socks": ["Khaki", "White"],
            "Suits": [
                "Winter",
                "Summer S/S",
                "Summer L/S",
                "Waterproof",
                "Eton",
                "Track",
            ],
            "Shoes": ["Court", "Safety", "Black Off", "Black Leather", "Canvas"],
            "Shirts": ["Blue", "Grey", "Khaki Tech", "Tee"],
            "Skirts": ["Winter", "Summer", "Blue Civilian"],
            "Slacks": ["Trousers", "and Jacket"],
            "Sashes": ["Sergeant Major"],
            "Stars": ["Gilded", "embroided"],
            "Titles": ["Shoulder"],
            "Trousers": ["Riot", "Combat", "Tetrex", "Riot Women Police", "Riot Cycles"],
        }

        # Male items
        male_data = {
           "Promotion

Chevrons, 3 Bar, Anodised

Chevrons, 3 Bar, Gold on Blue

Belt, Sam Browne

Cane, Leather Covered

Gloves, Leather, Unlined

Stars, Guilded

Stars Gilt

Case, Pistol Web

Lanyard, Revolver

Lanyard, Whistle Chaplain

Lanyard, Whistle Double Chaplain

Lanyard, Whistle Double Blue

Lanyard, Whistle, Double Gold Cotton

Gloves, Doeskin

Case, Dispatch

Gloves, White, Nylon

Patches Gorgettes

Peak Single Row

Peak Double Row

Peak Triple Row

Stars Embroidered

Sword, Ceremonial, Complete, Gold /Nickel

Sword, Ceremonial, Complete, Brown/Black

Tip Starve Full Size

Tip Starve Ano Miniature

Tip Starve Embroidery

Zimbird In Wreath F/S

Zimbird In Wreath Ano Miniature

Cord Shoulder

Eppaulettes

Recruits

Brush, Blacking

Brush, Clothes

Fork, Table

Grip, Canvas

Housewife

Pillow

Plate, Steel

Sheet, Bed

Shirt, Grey

Shoes, Canvas

Shoes, P. T

Slips pillow

Sock, Khaki Wool

Spoon, Table

Shorts P.T. White

Suit, Track

Trousers Riot Cycles

Towel

Trousers, Riot

Vest

Aiguillette, Gold

Aiguillette, Cotton Guilt Wire

Badge, Shakol, F.M.B

Badge, Cap, Junior Officer

Badge, Cap, ‘S’ Officer

Badge, Cap, ‘J’ Officer

Badge, Cap, Anodised

Badge, Cap, Chaplain

Badges, Collar, Anodised

Badge Flag Police

Badge Flag Zimbabwe

Badge Police Grey

Badge Sergeant Major

Badge Slip on

Bag, Kit

Bag, Sleeping

Battery

Baton Rubber

Bed Hounsfield

Belt Stable

Belt Stable Ceremonial

Belt Stable Chaplain

Belt, Ceremonial, Band

Belt, Waist, Leather, Black

Belt, Waist, Leather, Brown

Beret, Navy, Blue

Blanket

Book, Instruction

Boots, Black, Leather Sole

Boots, Brown, Leather Sole

Boots, Veldskoen

Boot, Rubber Knee

Boots, Super-Pro

Bore, Tie

Buckle, Anodised

Buttons, Anodised, Large

Buttons, Anodised, Medium

Buttons, Anodised, Small

Cap , blue band

Cap, Baseball

Cap, Bandmaster

Cap, Blue, S.T.U

Cap, Blue Officer

Cap, Drab

Cap, Drab Chaplain

Cap, Poncho P.P.S

Coat, Rain

Coat, Trench

Socks, Nylon

Socks, Black

Stockings, Khaki Tech

Suits, Full Dress, Whipcord

Suit Patrol

Suit, Fawn, ADC

Suit, Dance, Band

Suit, Bandmaster

Tie, Blue

Tin, Mess (Set)

Titles, Shoulder, Anodised

Trousers, Fawn

Trousers, Tetrex

Trousers, Riot

Tie, Black

Suit, Blue, Band

Vest

Whistle

Manual, First, Aid

Veil, Face

Trousers Riot Cycle

Trousers Riot FPU

Special Issues

Belt, Stable Chaplain

Boots, Combat

Boot, Combat, Crepe, Sole

Overalls, Blue, Combination

Dustcoat

Gloves, Leather, Unlined

Jacket, Webbing

Lanyard Whistle Chaplain

Lantern, Hunter

Overalls, White, Caterers

Overalls, White, Combination

Overall, Blue, Swat

Pantaloons N/B, Drill

Suit, Blue, Band

Trousers, Blue, Civilian

Breeches Riding

Cover, Leather, Pocket book

Curtain, Mosquito

Drawers

Gauntlets, M/Cycle

Gloves, White

Gloves, Khaki

Handcuffs

Helmet, Crash

Identity Card

Jacket, Swat

Jacket, Riot

Jacket, Waterproof

Jersey, Grey

Knife, Table

Lamp, Police

Lanyard, Whistle

Mug, Plastic

Name Tags

Name Tags Magnetic

Plate, Steel

Puttees

Respirator

Reaction Suit

Rifle

Sheet, Ground

Shirt, Drab

Shirt, Drab, Short Sleeve

Shirt white patrol

Shirt, Grey

Shirt Blue, Civilian

Shirt, Khaki, Technician

Shirt, Riot Long Sleeve

Shirt, Riot Short Sleeve

Sleeves Reflective

Shoes, Black

Shoes, Brown

Shoes, Canvas

Shoes, Protective, Tech

Shirt, Combat

Shirt, Tie Type

Shelter L/W

Sash, Sergeant Major

Suit Waterproof

Tabards Reflective

Zimbridl In Wreath

Work Suit

Suit Rain Jungle Green

Spurs Jack

Women

Badges, Hat Emb.

Badges,Collar

Badges, Slip On

Badge Sergeant Major

Badge Flag Zimbabwe

Badge Flag Police

Badge Police Grey

Bag Shoulder W/P

Bars, Gilt

Bed Hounsfield

Belt Stable Chaplain

Belt,Web

Blankets, G.S.

Book, Instruction

Boots, Combat

Boots, CrepeSole

Boots, Superpro

Button, Medium

Button, Small

Coat, Trench. Navy Blue

Cap, S.T.U.

Cover, Leather, P/Book

Curtain, Mosquito

Case, Despatch

Gloves,Driving

Gloves, Navy Blue

Gloves White

Handcuffs

Holster pi

Hat, Navy Blue W/P

Hat Blue Chaplain

Hat Blue Band

Identity Card

Jacket, Riot

Jacket Waterproof

Jacket Webbing

Jersey, Blue W/P

Lamp, Police

Lanyard, Whistle

Manual, First Aid

Name Tags/ magnetic

Overall, Acid Proof

Pantihose

Plates, Backing

Socks, Khaki

Suit, Winter

shoes court, high heeled

Shoes, Court

Shoes, Safety

Shoes, Black Off

Suit Summer S/S

Suit Summer L/S

Shirt, Blue

Stars Gilded

Slacks, Trousers

Shirt, Grey

Shirt, Khaki Tech

Skirt Winter

Slack and Jacket

Slack

Sash Sergeant Major

Stars embroided

Suit Waterproof

Skirt Summer

Skirt Blue Civilian

Suit Eton

Detachable shoulder

Titles, Shoulder

Trousers, Riot

Tie, Blue

Trousers, Combat

Trousers, Tetrex

Trousers Riot Women Police

Trousers Riot Cycles

Tabards Reflective

Worksuit

Whistle

Recruits/Induction Course

Brush, Blacking

Brush, Clothes

Buckle, Anodised

Grip Canvas/ Hold All

Housewife

Pillow, Feather

Sheets, Bed

Shirt, Tee

Shoes, Black Leather

Shoes, Canvas

Slips, Pillow

Socks, White

Suit, Track

Towels, Hand"
        }

        # Combine all categories (female + male)
        all_categories = set(female_data.keys()).union(set(male_data.keys()))
        
        # Create categories and items
        for category_name in all_categories:
            category, created = ClothingCategory.objects.get_or_create(name=category_name)
            
            # Add female items if they exist
            if category_name in female_data:
                for item_name in female_data[category_name]:
                    ClothingItem.objects.get_or_create(
                        name=item_name,
                        defaults={
                            'category': category,
                            'lifespan_months': 6
                        }
                    )

            
            # Add male items if they exist
            if category_name in male_data:
                for item_name in male_data[category_name]:
                   ClothingItem.objects.get_or_create(
                        name=item_name,
                        defaults={
                            'category': category,
                            'lifespan_months': 6
                        }
                    )


        self.stdout.write(self.style.SUCCESS('Successfully populated clothing data'))


        