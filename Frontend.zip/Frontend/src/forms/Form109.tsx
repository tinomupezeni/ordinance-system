import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form109Pdf from "@/formPdfs/Form109Pdf";
import Server from "@/server/Server";

type ReceiptItem = {
  id: number;
  description: string;
  size: string;
  number_received: number;
  number_rejected: number;
  noTaken: string;
};

type FormData = {
  received_from: string;
  ordinance_voucher_no: string;
  gcs_reqn_no: string;
  supplier_ref_no: string;
  items: ReceiptItem[];
  received_by_date: string
  received_by_signature: string;
  ledger_actioned_by_date: string
  ledger_actioned_by_signature: string;
};

const Form109 = ({stockType}) => {
  const [formData, setFormData] = useState<FormData>({
    received_from: "",
    ordinance_voucher_no: "",
    gcs_reqn_no: "",
    supplier_ref_no: "",
    items: [
      {
        id: 1,
        description: "",
        size: "",
        number_received: 0,
        number_rejected: 0,
        noTaken: "",
      },
    ],
    received_by_date: "",
    received_by_signature: "",
    ledger_actioned_by_signature: "",
    ledger_actioned_by_date: "",
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };


  const handleItemChange = (
    id: number,
    field: keyof ReceiptItem,
    value: string | boolean
  ) => {
    setFormData((prev) => {
      const updatedItems = prev.items.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      );

      // Add new row if description is filled in the last row
      if (
        field === "description" &&
        typeof value === "string" &&
        value !== "" &&
        id === prev.items[prev.items.length - 1].id
      ) {
        return {
          ...prev,
          items: [
            ...updatedItems,
            {
              id: prev.items.length + 1,
              description: "",
              size: "",
              number_received: 0,
              number_rejected: 0,
              noTaken: "",
            },
          ],
        };
      }

      return {
        ...prev,
        items: updatedItems,
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out empty items (where description is empty)
    const submittedItems = formData.items.filter(
      (item) => item.description.trim() !== ""
    );

    const completeFormData = {
      ...formData,
      items: submittedItems,
      stockType: stockType
    };

    Server.addForm109(completeFormData).then(() => {
      toast('Succefully recorded form 109')
    }).catch((error) => {
      toast('An error occured', error)
      console.log(error);
      
    })

    console.log("Form data to be sent to PDF:", completeFormData);
    // setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setFormData({
      received_from: "",
      ordinance_voucher_no: "",
      gcs_reqn_no: "",
      supplier_ref_no: "",
      items: [
        {
          id: 1,
          description: "",
          size: "",
          number_received: 0,
          number_rejected: 0,
          noTaken: "",
        },
      ],
      received_by_date: "",
      received_by_signature: "",
      ledger_actioned_by_date: "",
        ledger_actioned_by_signature: "",
      
    });
    toast.info("Form has been reset");
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });



  return (
    <>
      <div className="w-full mx-auto">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 109 - ORDNANCE STORE RECEIPT VOUCHER
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Header Info */}
                <div className="mb-6">
                  <div className="mb-4">
                    <Label>Received from:</Label>
                    <Input
                      value={formData.received_from}
                      onChange={(e) =>
                        handleInputChange("received_from", e.target.value)
                      }
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <Label>Ordnance Voucher No.</Label>
                      <Input
                        value={formData.ordinance_voucher_no}
                        onChange={(e) =>
                          handleInputChange(
                            "ordinance_voucher_no",
                            e.target.value
                          )
                        }
                      />
                    </div>
                    <div>
                      <Label>G.C.S./Tradesman Reqn. No.</Label>
                      <Input
                        value={formData.gcs_reqn_no}
                        onChange={(e) =>
                          handleInputChange("gcs_reqn_no", e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <Label>Supplier Ref: No.</Label>
                      <Input
                        value={formData.supplier_ref_no}
                        onChange={(e) =>
                          handleInputChange("supplier_ref_no", e.target.value)
                        }
                      />
                    </div>
                  </div>
                </div>

                {/* Items Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-5 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Description of goods</div>
                    <div>Size</div>
                    <div>Number Received</div>
                    <div>Number Rejected</div>
                    <div>No. taken on stock</div>
                  </div>

                  {formData.items.map((item) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-5 gap-2 items-center border-b py-2"
                    >
                      <Input
                        value={item.description}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "description",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.size}
                        onChange={(e) =>
                          handleItemChange(item.id, "size", e.target.value)
                        }
                      />
                      <Input
                        value={item.number_received}
                        type="number"
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "number_received",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.number_rejected}
                        type="number"
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "number_rejected",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.noTaken}
                        onChange={(e) =>
                          handleItemChange(item.id, "noTaken", e.target.value)
                        }
                      />
                    </div>
                  ))}
                </div>

                {/* Signatures Section */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">
                      Received and taken on Stock
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Signature</Label>
                        <Input
                          value={formData.received_by_signature}
                          onChange={(e) =>
    handleInputChange("received_by_signature", e.target.value)
  }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={formData.received_by_date}
                           onChange={(e) =>
    handleInputChange("received_by_date", e.target.value)
  }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Taken on Ledger</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Signature</Label>
                        <Input
                          value={formData.ledger_actioned_by_signature}
                           onChange={(e) =>
    handleInputChange("ledger_actioned_by_signature", e.target.value)
  }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={formData.ledger_actioned_by_date}
                           onChange={(e) =>
    handleInputChange("ledger_actioned_by_date", e.target.value)
  }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button type="button" variant="outline" onClick={handleReset}>
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        const submittedItems = formData.items.filter(
                          (item) => item.description.trim() !== ""
                        );
                        setShowPreview(true);
                      }}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Voucher</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form109Pdf
            // formData={staticFormData}
            formData={{
              ...formData,
              items: formData.items.filter(
                (item) => item.description.trim() !== ""
              ),
            }}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
        {/* <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              Recent Reports
            </h3>

            <div className="relative flex items-center">
              <input
                aria-label="Search"
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                id="search"
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by report no, station..."
                type="text"
                value={searchTerm}
              />
              <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                <Search />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Voucher No.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Supplier
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date Received
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredVouchers.length > 0 ? (
                    filteredVouchers.map((voucher, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {voucher.voucher_no}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.issue_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completed
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        className="px-6 py-4 text-sm text-gray-500 text-center"
                        colSpan="4"
                      >
                        {requisitionVouchers.length === 0
                          ? "No recent reports found"
                          : "No matching reports found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <a
              className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
              href="#"
            >
              <List /> View All Reports
            </a>
          </div>
        </div> */}
      </div>
    </>
  );
};

export default Form109;
