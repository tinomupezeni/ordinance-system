import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form163Pdf from "@/formPdfs/Form163Pdf";
import Server from "@/server/Server";

type RequisitionItem = {
  id: number;
  description: string;
  size: string;
  noRegd: string;
  noIssued: string;
};

const Form163 = () => {
  const [items, setItems] = useState<RequisitionItem[]>([
    {
      id: 1,
      description: "",
      size: "",
      noRegd: "",
      noIssued: "",
    },
  ]);

  const [requestedBy, setRequestedBy] = useState({
    initials: "",
    date: "",
  });

  const [issuedBy, setIssuedBy] = useState({
    initials: "",
    date: "",
  });

  const [receivedBy, setReceivedBy] = useState({
    initials: "",
    date: "",
  });

  const [ledgerActionedBy, setLedgerActionedBy] = useState({
    initials: "",
    date: "",
  });

  const [showPreview, setShowPreview] = useState(false);
  const [formData, setFormData] = useState({});

  // Check if we need to add a new row when items change
  useEffect(() => {
    const lastItem = items[items.length - 1];
    if (
      lastItem?.description ||
      lastItem?.size ||
      lastItem?.noRegd ||
      lastItem?.noIssued
    ) {
      // Add a new empty row if the last row has any data
      setItems((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          description: "",
          size: "",
          noRegd: "",
          noIssued: "",
        },
      ]);
    }
  }, [items]);

  const handleItemChange = (
    id: number,
    field: keyof RequisitionItem,
    value: string
  ) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
  
    // Filter out empty rows and prepare the data
    const nonEmptyItems = items.filter(
      (item) => item.description || item.size || item.noRegd || item.noIssued
    );
  
    // Validate required fields (including dates)
    if (!requestedBy.date || !issuedBy.date || !receivedBy.date || !ledgerActionedBy.date) {
      toast.error("Please fill in all date fields");
      return;
    }
  
    // Prepare the complete form data
    const completeFormData = {
      items: nonEmptyItems,
      requestedBy,
      issuedBy,
      receivedBy,
      ledgerActionedBy,
    };
  
    // Update state and submit
    setFormData(completeFormData);
    setItems(nonEmptyItems);
  
    Server.addForm163(completeFormData)
      .then(() => {
        toast.success("Form 163 successfully added");
        setShowPreview(true);
      })
      .catch((error) => {
        toast.error(error.message);
      });
  };


  const handlePrint = () => {
    window.print();
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });

  const staticFormData = {
    items: [
      {
        id: 1,
        description: "Boots, Black Leather",
        size: "42",
        noRegd: "2",
        noIssued: "2",
      },
      {
        id: 2,
        description: "Shirts, Khaki",
        size: "M",
        noRegd: "5",
        noIssued: "5",
      },
      {
        id: 3,
        description: "Trousers, Navy Blue",
        size: "34",
        noRegd: "3",
        noIssued: "3",
      },
      {
        id: 4,
        description: "Caps, Police Issue",
        size: "L",
        noRegd: "2",
        noIssued: "2",
      },
      {
        id: 5,
        description: "", // Empty row for demonstration
        size: "",
        noRegd: "",
        noIssued: "",
      },
    ],
    requestedBy: {
      initials: "J.M.",
      date: "2025-04-15",
    },
    issuedBy: {
      initials: "R.T.",
      date: "2025-04-16",
    },
    receivedBy: {
      initials: "P.K.",
      date: "2025-04-16",
    },
    ledgerActionedBy: {
      initials: "L.B.",
      date: "2025-04-17",
    },
  };

  // Sample data for recent reports table
  const recentReports = [
    {
      voucher_no: "163-2025-001",
      station: "ZRP Avondale",
      issue_date: "2025-04-10",
      status: "Completed",
    },
    {
      voucher_no: "163-2025-002",
      station: "ZRP Harare Central",
      issue_date: "2025-04-12",
      status: "Completed",
    },
    {
      voucher_no: "163-2025-003",
      station: "ZRP Bulawayo",
      issue_date: "2025-04-14",
      status: "Completed",
    },
  ];
  useEffect(() => {

    setRequisitonVouchers(recentReports);
  }, [])
  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 163 - REQUISITION ON BULK STORE
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Items Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-4 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Description</div>
                    <div>Size</div>
                    <div>No. Regd.</div>
                    <div>No. Issued</div>
                  </div>

                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-4 gap-2 items-center border-b py-2"
                    >
                      <Input
                        value={item.description}
                        onChange={(e) =>
                          handleItemChange(
                            item.id,
                            "description",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={item.size}
                        onChange={(e) =>
                          handleItemChange(item.id, "size", e.target.value)
                        }
                      />
                      <Input
                        value={item.noRegd}
                        onChange={(e) =>
                          handleItemChange(item.id, "noRegd", e.target.value)
                        }
                      />
                      <Input
                        value={item.noIssued}
                        onChange={(e) =>
                          handleItemChange(item.id, "noIssued", e.target.value)
                        }
                      />
                    </div>
                  ))}
                </div>

                {/* Signatures Section */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Requested By</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={requestedBy.initials}
                          onChange={(e) =>
                            setRequestedBy({
                              ...requestedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={requestedBy.date}
                          onChange={(e) =>
                            setRequestedBy({
                              ...requestedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Issued By</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={issuedBy.initials}
                          onChange={(e) =>
                            setIssuedBy({
                              ...issuedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={issuedBy.date}
                          onChange={(e) =>
                            setIssuedBy({ ...issuedBy, date: e.target.value })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Received By</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={receivedBy.initials}
                          onChange={(e) =>
                            setReceivedBy({
                              ...receivedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={receivedBy.date}
                          onChange={(e) =>
                            setReceivedBy({
                              ...receivedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border p-4 rounded">
                    <h3 className="font-semibold mb-2">Ledger Actioned By</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Initials</Label>
                        <Input
                          value={ledgerActionedBy.initials}
                          onChange={(e) =>
                            setLedgerActionedBy({
                              ...ledgerActionedBy,
                              initials: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={ledgerActionedBy.date}
                          onChange={(e) =>
                            setLedgerActionedBy({
                              ...ledgerActionedBy,
                              date: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setItems([
                        {
                          id: 1,
                          description: "",
                          size: "",
                          noRegd: "",
                          noIssued: "",
                        },
                      ]);
                      setRequestedBy({ initials: "", date: "" });
                      setIssuedBy({ initials: "", date: "" });
                      setReceivedBy({ initials: "", date: "" });
                      setLedgerActionedBy({ initials: "", date: "" });
                      toast.info("Form reset");
                    }}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        const nonEmptyItems = items.filter(
                          (item) =>
                            item.description ||
                            item.size ||
                            item.noRegd ||
                            item.noIssued
                        );
                        setItems(nonEmptyItems);
                        setShowPreview(true);
                      }}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Requisition</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form163Pdf
            // formData={formData}
            formData={staticFormData}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
        {/* <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              Recent Reports
            </h3>

            <div className="relative flex items-center">
              <input
                aria-label="Search"
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                id="search"
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by report no, station..."
                type="text"
                value={searchTerm}
              />
              <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                <Search />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Report No.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Station
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date Issued
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredVouchers.length > 0 ? (
                    filteredVouchers.map((voucher, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {voucher.voucher_no}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.issue_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completed
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        className="px-6 py-4 text-sm text-gray-500 text-center"
                        colSpan="4"
                      >
                        {requisitionVouchers.length === 0
                          ? "No recent reports found"
                          : "No matching reports found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <a
              className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
              href="#"
            >
              <List /> View All Reports
            </a>
          </div>
        </div> */}
      </div>
    </>
  );
};

export default Form163;
