import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form57Pdf from "@/formPdfs/Form57Pdf";

type LedgerEntry = {
  id: number;
  date: string;
  voucher: string;
  receipts: string;
  issues: string;
  balance: string;
};

type FormData = {
  description: string;
  price: string;
  reorderLevel: string;
  reorderAmount: string;
  ledgerEntries: LedgerEntry[];
};

const Form57 = () => {
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [reorderLevel, setReorderLevel] = useState("");
  const [reorderAmount, setReorderAmount] = useState("");

  const [entries, setEntries] = useState<LedgerEntry[]>([
    {
      id: 1,
      date: "",
      voucher: "",
      receipts: "",
      issues: "",
      balance: "",
    },
  ]);

  const [formData, setFormData] = useState<FormData>({
    description: "",
    price: "",
    reorderLevel: "",
    reorderAmount: "",
    ledgerEntries: [
      {
        id: 1,
        date: "",
        voucher: "",
        receipts: "",
        issues: "",
        balance: "",
      },
    ],
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleEntryChange = (
    id: number,
    field: keyof LedgerEntry,
    value: string
  ) => {
    setEntries((prev) => {
      const updatedEntries = prev.map((entry) =>
        entry.id === id ? { ...entry, [field]: value } : entry
      );

      // Check if we need to add a new row
      if (
        field === "balance" ||
        field === "date" ||
        (field === "voucher" && value !== "" && id === prev[prev.length - 1].id)
      ) {
        return [
          ...updatedEntries,
          {
            id: prev.length + 1,
            date: "",
            voucher: "",
            receipts: "",
            issues: "",
            balance: "",
          },
        ];
      }

      return updatedEntries;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out empty rows (where all fields are empty)
    const submittedEntries = entries.filter(
      (entry) =>
        entry.date ||
        entry.voucher ||
        entry.receipts ||
        entry.issues ||
        entry.balance
    );

    // Log all the form data
    console.log({
      itemDetails: {
        description,
        price,
        reorderLevel,
        reorderAmount,
      },
      ledgerEntries: submittedEntries,
    });

    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });

  const staticFormData = {
    description: "Boots, Black Leather",
    price: "$45.00",
    reorderLevel: "10 pairs",
    reorderAmount: "20 pairs",
    ledgerEntries: [
      {
        id: 1,
        date: "2025-01-15",
        voucher: "V-2025-001",
        receipts: "50",
        issues: "5",
        balance: "45",
        outstandingOrders: "PO-2025-001",
      },
      {
        id: 2,
        date: "2025-02-10",
        voucher: "V-2025-002",
        receipts: "0",
        issues: "12",
        balance: "33",
        outstandingOrders: "",
      },
      {
        id: 3,
        date: "2025-03-05",
        voucher: "V-2025-003",
        receipts: "30",
        issues: "8",
        balance: "55",
        outstandingOrders: "PO-2025-002",
      },
      {
        id: 4,
        date: "2025-04-01",
        voucher: "V-2025-004",
        receipts: "0",
        issues: "15",
        balance: "40",
        outstandingOrders: "",
      },
      {
        id: 5,
        date: "", // Empty row for demonstration
        voucher: "",
        receipts: "",
        issues: "",
        balance: "",
        outstandingOrders: "",
      },
    ],
  };

  // Sample data for recent reports table
  const recentReports = [
    {
      voucher_no: "57-2025-001",
      supplier: "Uniforms Ltd",
      issue_date: "2025-04-10",
      status: "Completed",
    },
    {
      voucher_no: "57-2025-002",
      supplier: "Leather Goods Co",
      issue_date: "2025-04-12",
      status: "Completed",
    },
    {
      voucher_no: "57-2025-003",
      supplier: "Police Supplies Inc",
      issue_date: "2025-04-14",
      status: "Completed",
    },
  ];

  useEffect(() => {
    setRequisitonVouchers(recentReports);
  }, []);

  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 57 - ORDNANCE LEDGER CARD
                </p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Item Information */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <Label>Description</Label>
                    <Input
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Price</Label>
                    <Input
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Re-order Level</Label>
                    <Input
                      value={reorderLevel}
                      onChange={(e) => setReorderLevel(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Re-order Amount</Label>
                    <Input
                      value={reorderAmount}
                      onChange={(e) => setReorderAmount(e.target.value)}
                    />
                  </div>
                </div>

                {/* Ledger Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-6 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Date</div>
                    <div>Voucher</div>
                    <div>Receipts</div>
                    <div>Issues</div>
                    <div>Balance</div>
                    <div>Outstanding Orders</div>
                  </div>

                  {entries.map((entry) => (
                    <div
                      key={entry.id}
                      className="grid grid-cols-6 gap-2 items-center border-b py-2"
                    >
                      <Input
                        type="date"
                        value={entry.date}
                        onChange={(e) =>
                          handleEntryChange(entry.id, "date", e.target.value)
                        }
                      />
                      <Input
                        value={entry.voucher}
                        onChange={(e) =>
                          handleEntryChange(entry.id, "voucher", e.target.value)
                        }
                      />
                      <Input
                        value={entry.receipts}
                        onChange={(e) =>
                          handleEntryChange(
                            entry.id,
                            "receipts",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        value={entry.issues}
                        onChange={(e) =>
                          handleEntryChange(entry.id, "issues", e.target.value)
                        }
                      />
                      <Input
                        value={entry.balance}
                        onChange={(e) =>
                          handleEntryChange(entry.id, "balance", e.target.value)
                        }
                      />
                      <Input />
                    </div>
                  ))}
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      // Reset form
                      setDescription("");
                      setPrice("");
                      setReorderLevel("");
                      setReorderAmount("");
                      setEntries([
                        {
                          id: 1,
                          date: "",
                          voucher: "",
                          receipts: "",
                          issues: "",
                          balance: "",
                        },
                      ]);
                      toast.info("Form has been reset");
                    }}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowPreview(true)}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Ledger</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Form57Pdf
            formData={staticFormData}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              Recent Reports
            </h3>

            <div className="relative flex items-center">
              <input
                aria-label="Search"
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                id="search"
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by report no, station..."
                type="text"
                value={searchTerm}
              />
              <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                <Search />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Certificate No.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Supplier
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredVouchers.length > 0 ? (
                    filteredVouchers.map((voucher, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {voucher.voucher_no}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.issue_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completed
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        className="px-6 py-4 text-sm text-gray-500 text-center"
                        colSpan="4"
                      >
                        {requisitionVouchers.length === 0
                          ? "No recent reports found"
                          : "No matching reports found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <a
              className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
              href="#"
            >
              <List /> View All Reports
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Form57;
