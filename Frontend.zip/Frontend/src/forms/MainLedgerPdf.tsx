import React from 'react';

const MainLedgerPdf = ({ formData }) => {
  return (
    <div className="preview-form" style={{ 
      fontFamily: 'Arial, sans-serif',
      maxWidth: '800px',
      margin: '0 auto',
      padding: '20px',
      border: '1px solid #000',
      position: 'relative'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h3 style={{ textDecoration: 'underline', marginBottom: '5px' }}>
          POLICE ORDNANCE STORE REQUISITION — ISSUE VOUCHER
        </h3>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Ordinance Control No.: {formData.ordinanceControlNo}</span>
          <span>Date: {formData.date}</span>
        </div>
      </div>

      <div style={{ marginBottom: '15px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Station: {formData.station}</span>
          <span>Branch: {formData.branch}</span>
          <span>To be {formData.dispatchMethod}</span>
        </div>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '15px' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid #000' }}>
            <th style={{ width: '5%', textAlign: 'left', padding: '5px' }}>No.</th>
            <th style={{ width: '10%', textAlign: 'left', padding: '5px' }}>Force No.</th>
            <th style={{ width: '10%', textAlign: 'left', padding: '5px' }}>Rank</th>
            <th style={{ width: '20%', textAlign: 'left', padding: '5px' }}>Name</th>
            <th style={{ width: '20%', textAlign: 'left', padding: '5px' }}>Articles Required</th>
            <th style={{ width: '10%', textAlign: 'left', padding: '5px' }}>Size</th>
            <th style={{ width: '10%', textAlign: 'left', padding: '5px' }}>Regd. No</th>
            <th style={{ width: '10%', textAlign: 'left', padding: '5px' }}>Date due</th>
            <th style={{ width: '5%', textAlign: 'left', padding: '5px' }}>No Issued</th>
            <th style={{ width: '10%', textAlign: 'left', padding: '5px' }}>Signature</th>
          </tr>
        </thead>
        <tbody>
          {formData.items.map((item, index) => (
            <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '5px' }}>{index + 1}</td>
              <td style={{ padding: '5px' }}>{item.forceNo}</td>
              <td style={{ padding: '5px' }}>{item.rank}</td>
              <td style={{ padding: '5px' }}>{item.name}</td>
              <td style={{ padding: '5px' }}>{item.article}</td>
              <td style={{ padding: '5px' }}>{item.size}</td>
              <td style={{ padding: '5px' }}>{item.regdNo}</td>
              <td style={{ padding: '5px' }}>{item.dateDue}</td>
              <td style={{ padding: '5px' }}>{item.issued}</td>
              <td style={{ padding: '5px' }}>{item.signature}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginBottom: '15px' }}>
        <p>ALL ITEMS LISTED ABOVE HAVE BEEN COLLECTED FROM THE ORDINANCE STORE</p>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Total Issued: BY No. {formData.collectedBy.no} Rank {formData.collectedBy.rank} Name {formData.collectedBy.name}</span>
          <span>Voucher Checked By Initials: {formData.checkedByInitials} Date: {formData.date}</span>
        </div>
      </div>

      <div style={{ marginBottom: '15px', borderTop: '1px solid #000', paddingTop: '10px' }}>
        <h4 style={{ textDecoration: 'underline' }}>REPLACEMENT BEFORE EXPIRY OF PERIOD OF SERVICEABILITY</h4>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
          <span>Item No. {formData.replacementInfo.itemNo}</span>
          <span>Life {formData.replacementInfo.life}</span>
          <span>Date of Issue {formData.replacementInfo.dateOfIssue}</span>
        </div>
        <p>Brief Reasons for Unserviceability: {formData.replacementInfo.reasons}</p>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Items Selected By Initials: {formData.replacementInfo.selectedByInitials}</span>
          <span>Date: {formData.replacementInfo.selectedDate}</span>
        </div>
      </div>

      <div style={{ marginBottom: '15px', borderTop: '1px solid #000', paddingTop: '10px' }}>
        <h4 style={{ textDecoration: 'underline' }}>Recommendations of Officer/Member-in-Charge</h4>
        <p>
          Items referred to in this part to be replaced at {formData.recommendations.expenseType} expense
          {formData.recommendations.expenseType === 'Member\'s' && ` at ${formData.recommendations.percentage}% of cost`}
        </p>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>No. {formData.recommendations.no} Rank {formData.recommendations.rank}</span>
          <span>Signature: {formData.recommendations.signature}</span>
        </div>
      </div>

      <div style={{ marginBottom: '15px', borderTop: '1px solid #000', paddingTop: '10px' }}>
        <h4 style={{ textDecoration: 'underline' }}>Method of Issue/Despatch</h4>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
          <span>Collected</span>
          <span>Rail</span>
          <span>Road</span>
          <span>Air</span>
          <span>Registered Mail</span>
          <span>Parcel Post</span>
          <span>Parcel/Warrant No. {formData.issueMethod}</span>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px' }}>
        <div>
          <p>Checked by Officer/Member-in-Charge (All Requisitions)</p>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Signed: {formData.checkedByOfficer.signature}</span>
            <span>No. {formData.checkedByOfficer.no} Rank {formData.checkedByOfficer.rank}</span>
          </div>
        </div>
        <div>
          <p>Checked by Quartermaster's Representative (Items on Station Charge Only)</p>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Signed: {formData.checkedByQuartermaster.signature}</span>
            <span>No. {formData.checkedByQuartermaster.no} Rank {formData.checkedByQuartermaster.rank}</span>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <p>Items Packed by Initials: {formData.packedByInitials} Date: {formData.packedDate}</p>
          <p>Entered on Clothing Card No. {formData.clothingCardNo}</p>
        </div>
        <div>
          <p>Ledger Actioned Initials: {formData.ledgerInitials} Date: {formData.ledgerDate}</p>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px' }}>
        <div style={{ textAlign: 'center' }}>
          <p>DATE STAMP (Top Copy Only)</p>
        </div>
        <div style={{ textAlign: 'center' }}>
          <p>DATE STAMP (Top Copy Only)</p>
        </div>
      </div>
    </div>
  );
};

export default MainLedgerPdf;