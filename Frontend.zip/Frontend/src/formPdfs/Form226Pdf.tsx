import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { Menu, Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const Form227Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  return (
    <div className="w-[210mm] min-h-[297mm] mx-auto bg-white p-6 print:p-0 text-black form226pdf">
      {/* Form Header */}
      <div className=" mb-4">
        <div className="w-[100%] flex mb-6 justify-between">
          <p></p>
          <p className="">FORM 226</p>
        </div>
        <div className="flex">
          <h1 className="text-xl font-bold flex justify-between w-[100%] ml-6">
            Z.R. POLICE REPAYMENT <br />
            REQUISITION — ISSUE VOUCHER
          </h1>
          <div className="flex justify-between mt-2 text-sm right-0 border border-2 border-black w-[400px]">
            <span className="border-r border-black w-[50px]"></span>
            <span className="px-4 py-1">
              Ordinance Control No.
              <br /> {formData.ordinanceControlNo}
            </span>
          </div>
        </div>
      </div>

      {/* Rank and Name */}
      <div className="flex justify-between mb-4 text-sm-custom w-full">
        <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[30%] mr-4">
          <span className="px-4 py-1 mx-auto">
            Rank:
            <br /> {formData.rank}
          </span>
        </div>
        <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[40%] mr-4">
          <span className="px-4 py-1 mx-auto">
            Name:
            <br /> {formData.name}
          </span>
        </div>
        <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[30%]">
          <span className="px-4 py-1 mx-auto">
            Force No.:
            <br /> {formData.forceNo}
          </span>
        </div>
      </div>

      {/* Station and Branch */}
      <div className="flex justify-between mb-4 text-sm-custom w-full">
        <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[40%] mr-4">
          <span className="px-4 py-1 mx-auto">
            Station:
            <br /> {formData.station}
          </span>
        </div>
        <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[30%] mr-4">
          <span className="px-4 py-1 mx-auto">
            Branch:
            <br /> {formData.branch}
          </span>
        </div>
        <div className="flex justify-between  mt-2 text-sm border-2 border-black h-[60px] w-[40%] mr-4">
          <span className="px-4 py-1 mx-auto text-center">
            To be
            <br /> <span className="font-bold">CALLED FOR/DESPATCHED</span>{" "}
            <br />
            <span className="text-xs">{formData.dispatchMethod}</span>
          </span>
        </div>
      </div>
      <div className="parent-div">
        <div></div>
        <div className="top-bar">
          <label>Ordnance Use Only</label>
        </div>
      </div>

      {/* Items Table */}
      <table className="w-full text-xs form227">
        <thead>
          <tr>
            <th className="w-[40%]">Articles Required</th>
            <th className="w-[8%]">Size</th>
            <th className="w-[8%]">
              No <br /> Reqd.
            </th>

            <th className="w-[10%] supplied-header">
              No. <br /> Supplied
            </th>
            <th className="w-[8%]">
              Priced <br /> at
            </th>
            <th className="w-[8%]">$</th>
            <th className="w-[4%] ">c</th>
            <th className="w-[15%]">Remarks</th>
          </tr>
        </thead>

        <tbody>
          {formData.items &&
          formData.items.some((item: any) => item.article !== "")
            ? formData.items.map((item: any) => (
                <tr key={item.id} className="form-rows">
                  <td className="">{item.article}</td>
                  <td className="">{item.size}</td>
                  <td className="">{item.reqdNo}</td>
                  <td className="supplied-header">{item.suppliedNo}</td>
                  <td className="">{item.price}</td>
                  <td className="">{item.$}</td>
                  <td className="">{item.c}</td>
                  <td className="">{item.remarks}</td>
                </tr>
              ))
            : Array.from({ length: 12 }).map((_, index) => (
                <tr key={`empty-row-${index}`} className="form-rows">
                  <td className="h-5"></td>
                  <td className=""></td>
                  <td className=""></td>
                  <td className="supplied-header"></td>{" "}
                  {/* Numbered articles */}
                  <td className=""></td>
                  <td className=""></td>
                  <td className=""></td>
                  <td className=""></td>
                </tr>
              ))}
        </tbody>
      </table>
      <div className="flex text-xs border-l border-black ">
        {/* Left section */}
        <div className="flex items-center  w-[100%] ">
          <div className="flex flex-col items-center gap-2">
            <span className="h-0.5 bg-black w-full"></span>
            <span className="h-0.5 bg-black w-full"></span>
            <span className="h-0.5 bg-black w-80"></span>
          </div>
          <div className="text-start ml-5">
            <p className="font-bold">TOTAL</p>
            <p>No.:</p>
          </div>
          <p className="w-24 "></p>
        </div>

        {/* Right section */}
        <div className="flex items-center justify-between w-[40%] ">
          <div className="text-center">
            <p className="font-bold">TOTAL</p>
            <p>COST:</p>
          </div>
          <p className="w-24 "></p>
          <div className="flex flex-col items-center gap-1">
            <span className="h-0.5 bg-black w-20"></span>
            <span className="h-0.5 bg-black w-20"></span>
            <span className="h-0.5 bg-black w-20"></span>
          </div>
        </div>
      </div>

      {/* Collection Confirmation */}
      <div className="flex  w-full items-start border border-black">
        <div className="flex-1 max-w-[55%]">
          <div className="">
            <div className="text-sm border-b border-black p-2">
              <p className="mb-2  text-center text-sm">
                I certify that the articles requisitioned for above are for my{" "}
                <br /> own personal use.
              </p>
              <div className="flex-col ">
                <div className="py-2">
                  <span>
                    Date{" "}
                    {formData.collectedBy.no ? (
                      formData.collectedBy.no
                    ) : (
                      <span>...........................</span>
                    )}{" "}
                    Signature{" "}
                    {formData.collectedBy.rank ? (
                      formData.collectedBy.rank
                    ) : (
                      <span>
                        ........................................................
                      </span>
                    )}
                  </span>
                </div>
                <span>
                  No.{" "}
                  {formData.collectedBy.no ? (
                    formData.collectedBy.no
                  ) : (
                    <span>.............................</span>
                  )}{" "}
                  Rank{" "}
                  {formData.collectedBy.rank ? (
                    formData.collectedBy.rank
                  ) : (
                    <span>...........................</span>
                  )}{" "}
                  Name{" "}
                  {formData.collectedBy.name ? (
                    formData.collectedBy.name
                  ) : (
                    <span>..........................</span>
                  )}
                </span>
              </div>
            </div>
            <div className="text-sm  border-b border-black p-2">
              <p className="mb-2 text-start text-sm">
                I certify that the above-named member--
              </p>
              <div className="ml-4">
                <p>*Is not due for discharge.</p>
                <p>
                  *Is due for discharge on.{" "}
                  <span>
                    .................................................................
                  </span>
                </p>
                <p>but the items are necessary for police duties.</p>
                <p className="text-center">(*Delete inapplicable)</p>
              </div>
              <div className="flex-col ">
                <div className="py-3">
                  <span>
                    Date{" "}
                    {formData.collectedBy.no ? (
                      formData.collectedBy.no
                    ) : (
                      <span>...........................</span>
                    )}{" "}
                    Signature{" "}
                    {formData.collectedBy.rank ? (
                      formData.collectedBy.rank
                    ) : (
                      <span>
                        ..........................................................
                      </span>
                    )}
                  </span>
                </div>
                <div className="">
                  <span>
                    No.{" "}
                    {formData.collectedBy.no ? (
                      formData.collectedBy.no
                    ) : (
                      <span>.............................</span>
                    )}{" "}
                    Rank{" "}
                    {formData.collectedBy.rank ? (
                      formData.collectedBy.rank
                    ) : (
                      <span>...........................</span>
                    )}{" "}
                    Name{" "}
                    {formData.collectedBy.name ? (
                      formData.collectedBy.name
                    ) : (
                      <span>..........................</span>
                    )}
                  </span>
                </div>
                <span>
                  Officer/Member-in-Charge{" "}
                  {formData.collectedBy.no ? (
                    formData.collectedBy.no
                  ) : (
                    <span>
                      ...................................................................
                    </span>
                  )}{" "}
                </span>
              </div>
            </div>
            <div className="text-sm  border-b border-black p-2">
              <p className="text-center text-sm">
                I certify that the above articles have been received by me in{" "}
                <br /> good order and condition
              </p>

              <div className="flex-col ">
                <div className="py-3">
                  <span>
                    Date{" "}
                    {formData.collectedBy.no ? (
                      formData.collectedBy.no
                    ) : (
                      <span>...........................</span>
                    )}{" "}
                    Signature{" "}
                    {formData.collectedBy.rank ? (
                      formData.collectedBy.rank
                    ) : (
                      <span>
                        ........................................................
                      </span>
                    )}
                  </span>
                </div>
                <div className="py-1.5">
                  <span>
                    No.{" "}
                    {formData.collectedBy.no ? (
                      formData.collectedBy.no
                    ) : (
                      <span>.............................</span>
                    )}{" "}
                    Rank{" "}
                    {formData.collectedBy.rank ? (
                      formData.collectedBy.rank
                    ) : (
                      <span>...........................</span>
                    )}{" "}
                    Name{" "}
                    {formData.collectedBy.name ? (
                      formData.collectedBy.name
                    ) : (
                      <span>...........................</span>
                    )}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* {right box inputs} */}
        <div className="right-fields flex-1 max-w-[45%]">
          <div className="right-box">
            <p>
              Voucher <br /> Checked By
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials:
                  <br />
                  {formData.voucherCheckedBy.initials}
                </span>
              </div>
              <div>
                <span>
                  Date
                  <br />
                  {formData.voucherCheckedBy.date}
                </span>
              </div>
            </div>
          </div>

          <div className="right-box">
            <p>
              Items <br /> Selected By
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials:
                  <br />
                  {formData.itemsSelectedBy.initials}
                </span>
              </div>
              <div>
                <span>
                  Date
                  <br />
                  {formData.itemsSelectedBy.date}
                </span>
              </div>
            </div>
          </div>

          <div className="right-box">
            <p>
              Method of <br /> Issue/Despatch
            </p>
            <div className="grid grid-cols-2 gap-2 w-full">
              {formData.methodOfIssue ? (
                <label>
                  {formData.methodOfIssue}
                  <input type="checkbox" className="ml-1" checked readOnly />
                </label>
              ) : null}
            </div>
          </div>

          <div className="right-box">
            <p>
              Warrant/ <br />
              Parcel No.
            </p>
            <div className="field-group">
              <span>{formData.collectedByNo}</span>
            </div>
          </div>

          <div className="right-box">
            <p>
              Items <br /> Checked By
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials:
                  <br />
                  {formData.collectedByNo}
                </span>
              </div>
              <div>
                <span>
                  Date
                  <br />
                  {formData.collectedByNo}
                </span>
              </div>
            </div>
          </div>
          <div className="right-box">
            <p>
              Items <br /> Packed By
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials:
                  <br />
                  {formData.itemsPackedBy.initials}
                </span>
              </div>
              <div>
                <span>
                  Date
                  <br />
                  {formData.itemsPackedBy.date}
                </span>
              </div>
            </div>
          </div>
          <div className="right-box">
            <p>
              Items <br /> Costed By
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials:
                  <br />
                  {formData.itemsCostedBy.initials}
                </span>
              </div>
              <div>
                <span>
                  Date
                  <br />
                  {formData.itemsCostedBy.date}
                </span>
              </div>
            </div>
          </div>

          <div className="right-box">
            <p>
              Ledger Action <br /> Taken by
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials:
                  <br />
                  {formData.ledgerActioned.initials}
                </span>
              </div> setRequisitonVouchers(recentReports);
              <div>
                <span>
                  Date
                  <br />
                  {formData.ledgerActioned.date}
                </span>
              </div>
            </div>
          </div>

          <div className="right-box">
            <p>
              S.F.S Action <br /> Taken by
            </p>
            <div className="field-group">
              <div>
                <span>
                  Initials
                  <br />
                  {formData.sfsActionTakenBy.initials}
                </span>
              </div>
              <div>
                <span>
                  Date
                  <br />
                  {formData.sfsActionTakenBy.date}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form227Pdf;
