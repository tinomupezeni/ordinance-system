import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";
import { Stamp } from "./Stamp";

// Preview Component (matches PDF layout exactly)
const Form109Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  const getCurrentDateStamp = () => {
    const today = new Date();
    const day = String(today.getDate()).padStart(2, "0");
    const month = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const year = today.getFullYear();
    return `${day}-${month}-${year}`;
  };

  return (
    <div className="w-[210mm] min-h-[297mm] border border-black mx-auto bg-white p-6 print:p-0 text-black form109pdf">
      {/* Form Header */}
      <div className="text-center mb-4">
        <div className="flex justify-between align-center w-full ">
          <p className="flex right-0">Z.R.P</p>
          <p className="flex right-0">FORM 109</p>
        </div>
        <h1 className="text-xxl font-bold flex justify-center ">
          ORDNANCE STORE RECEIPT VOUCHER
        </h1>
      </div>

      <div className="form109topps">
        <p>
          Received from: <br /> <span>{formData?.received_from}</span>
        </p>
        <div className="flex">
          <p>
            Ordnance Voucher No. <br />{" "}
            <span>{formData?.ordinance_voucher_no}</span>
          </p>
          <p>
            G.C.S./Tradesman Reqn. No. <br />{" "}
            <span>{formData?.gcs_reqn_no}</span>
          </p>
          <p>
            Supplier Ref: No. <br /> <span>{formData?.supplier_ref_no}</span>
          </p>
        </div>
      </div>

      <div className="relative w-full">
        {/* Table */}
        <table className="w-full text-sm form227">
          <thead>
            <tr>
              <th>Description</th>
              <th>Size</th>
              <th>
                Number <br /> Received
              </th>
              <th>
                Number <br /> Rejected
              </th>
              <th>
                No. taken <br /> on stock
              </th>
            </tr>
          </thead>
          <tbody>
            {formData?.items &&
            formData?.items.some((item: any) => item.article !== "")
              ? formData?.items.map((item: any) => (
                  <tr key={item.id} className="form-rows">
                    <td className="h-5 w-[50%]">{item.description}</td>
                    <td>{item.size}</td>
                    <td>{item.number_received}</td>
                    <td>{item.number_rejected}</td>
                    <td>{item.noTaken}</td>
                  </tr>
                ))
              : Array.from({ length: 15 }).map((_, index) => (
                  <tr key={`empty-row-${index}`} className="form-rows">
                    <td className="h-5 w-[50%]"></td>
                    <td className="w-10"></td>
                    <td className="w-5"></td>
                    <td className="w-5"></td>
                    <td className="w-20"></td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>

      {/* Collection Confirmation */}
      <div className="w-full flex justify-between ">
        <div className="w-[50%] text-center">
          <p>Receipt Bay Date Stamp</p>
          <Stamp office="Receiving Bay" />
        </div>
        <div className="w-[50%]">
          <div className="border border-black">
            <p className="font-bold flex justify-center border-b border-black">
              Received and taken on Stock
            </p>
            <div className="flex h-20">
              <div className="w-[60%] border-r border-black">
                <span className="px-4 py-1 block">
                  Signature
                  <br /> {formData?.received_by_signature}
                </span>
              </div>
              <div className="w-[40%]">
                <span className="px-4 py-1 block">
                  Date
                  <br /> {formData?.received_by_date}
                </span>
              </div>
            </div>
          </div>

          <div className="border border-black ">
            <p className="font-bold flex justify-center border-b border-black">
              Taken on Ledger
            </p>
            <div className="flex h-20">
              <div className="w-[60%] border-r border-black">
                <span className="px-4 py-1 block">
                  Initials:
                  <br /> {formData?.ledger_actioned_by_signature}
                </span>
              </div>
              <div className="w-[40%]">
                <span className="px-4 py-1 block">
                  Date
                  <br /> {formData?.ledger_actioned_by_date}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form109Pdf;
