// contexts/AuthContext.js
import { createContext, useContext, useEffect, useState } from 'react';
import { Link, useNavigate } from "react-router-dom";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if tokens exist in localStorage
        const accessToken = localStorage.getItem('access');
        if (!accessToken) {
          throw new Error('No access token');
        }

        // Here you might want to verify the token with your backend
        // For now, we'll just check its existence
        const userData = {
          username: localStorage.getItem('username'),
          role: localStorage.getItem('role'),
          userId: localStorage.getItem('user_id')
        };

        if (userData.username) {
          setUser(userData);
        } else {
          throw new Error('User data not found');
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        localStorage.removeItem('access');
        localStorage.removeItem('refresh');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        localStorage.removeItem('user_id');
        navigate("/login");

      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [router]);

  const login = (data) => {
    localStorage.setItem('access', data.access);
    localStorage.setItem('refresh', data.refresh);
    localStorage.setItem('username', data.user);
    localStorage.setItem('role', data.role);
    localStorage.setItem('user_id', data.user_id);
    setUser({
      username: data.user,
      role: data.role,
      userId: data.user_id
    });
  };

  const logout = () => {
    localStorage.removeItem('access');
    localStorage.removeItem('refresh');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    localStorage.removeItem('user_id');
    setUser(null);
    navigate("/login");

  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);