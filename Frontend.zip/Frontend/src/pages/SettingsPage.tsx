import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import SettingsPage from "./Settings";

const Settings = () => {
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex top-20">
        <Sidebar />
        <main className="flex-1 flex-1 p-6 ml-72 mt-20">
          <SettingsPage />
        </main>
      </div>
    </div>
  );
};

export default Settings;
