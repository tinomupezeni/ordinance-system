import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import logo from "@/assets/zrp-logo.png";
import { off } from "node:process";
import { BASE_URL } from "@/constants";

// const BASE_URL = 'http://127.0.0.1:5005';
// const BASE_URL = "http://192.168.80.92:5005"

const Login = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await axios.post(
        `${BASE_URL}/api/login/`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 200) {
        const { access, refresh, role, user_id, user ,office } = response.data;

        var user_office = null;

        switch (office) {
          case 'Admin':
            user_office = 'Officer in Charge';
            break;
          case 'Issues':
            user_office = 'Issues Officer';
            break;
          
          case 'Carding':
            user_office = 'Carding Officer';
            break;

          case 'Receiving Bay':
            user_office = 'Receiving Bay';
            break;

          case 'Dispatch':
            user_office = 'Dispatch Officer';
            break;
          case 'Kardex':
            user_office = 'Kardex Officer';
            break;
          case 'Stores':
            user_office = 'Stores Officer';
            break;
          case 'Loans':
            user_office = 'Loans Officer';
            break;
          case 'Bulk':
            user_office = 'Bulk Officer';
            break;
          default:
            user_office = 'Unknown Office'; // optional default case
        }

        
        // Store tokens and user details in localStorage
        localStorage.setItem("accessToken", access);
        localStorage.setItem("refreshToken", refresh);
        // localStorage.setItem("userRole", role);
        localStorage.setItem("userId", user_id);
        localStorage.setItem("username", user);
        localStorage.setItem("office", user_office);
      
       console.log(access, refresh, role, user_id, user , office);

        toast.success("Login successful");
        
        // Redirect based on user role
        
            navigate("/dashboard");
            
        
      }
    } catch (error: any) {
      console.error("Login error:", error);
      
      let errorMessage = "An error occurred during login";
      if (error.response) {
        if (error.response.data?.errors) {
          errorMessage = Object.values(error.response.data.errors)
            .flat()
            .join("\n");
        } else if (error.response.data?.message) {
          errorMessage = error.response.data.message;
        }
      } else if (error.request) {
        errorMessage = "No response received from server";
      }

      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="flex justify-center mb-6">
          <Link to="/" className="flex items-center">
            <div className="w-12 h-12 mr-2">
              <img
                src={logo}
                alt="ZRP ABIS"
                className="w-full h-full object-contain"
              />
            </div>
            <h1 className="font-bold text-2xl">
              <span className="text-blue-950">ZRP</span>
              <span className="text-yellow-500">ORDNANCE</span>
            </h1>
          </Link>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">
              Login
            </CardTitle>
            <CardDescription className="text-center">
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Force Number</Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="ZRP-23"
                  required
                  value={formData.username}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link
                    to="/forgot-password"
                    className="text-sm font-medium text-blue-600 hover:underline"
                  >
                    Forgot password?
                  </Link>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    required
                    value={formData.password}
                    onChange={handleChange}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  "Sign in"
                )}
              </Button>
            </form>
          </CardContent>

          <CardFooter className="flex justify-center flex-col space-y-4">
            <div className="text-center text-sm text-gray-600">
              Don't have an account?{" "}
              <Link
                to="/signup"
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                Sign up
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Login;