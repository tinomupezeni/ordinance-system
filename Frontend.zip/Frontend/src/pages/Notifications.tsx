import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import NotificationsView from "@/components/NotificationsView";
import { formatDate } from "@/lib/utils";
import { Clock } from "lucide-react";

const Notifications = ({ office }) => {
  // Current date
  const today = new Date();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 flex-1 p-6 ml-72 mt-20">
          <div className="flex-col justify-between items-center mb-6">
            <h1 className="flex text-xl font-semibold mb-4">
              {formatDate(today, "MMM d, yyyy")}
            </h1>
            <h1 className="text-xl font-bold bg-yellow-200 text-gray-800 px-4 py-2 rounded shadow inline-block">
              {office} Notifications
            </h1>
          </div>

          <NotificationsView office={office} />
        </main>
      </div>
    </div>
  );
};

export default Notifications;
