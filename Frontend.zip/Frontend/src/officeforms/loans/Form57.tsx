const form57Transactions = [
  { 
      id: 1, 
      officer: "Sergeant L. Dube", 
      item: "Binoculars", 
      transactionDate: "2025-04-15", 
      transactionType: "Issued",
      quantity: 1,
      reference: "ORD/2025/015"
  },
  { 
      id: 2, 
      officer: "Inspector Chari", 
      item: "Walkie Talkie", 
      transactionDate: "2025-04-18", 
      transactionType: "Returned",
      quantity: 2,
      reference: "ORD/2025/018"
  },
  { 
      id: 3, 
      officer: "Constable Moyo", 
      item: "First Aid Kit", 
      transactionDate: "2025-04-20", 
      transactionType: "Issued",
      quantity: 1,
      reference: "ORD/2025/022"
  },
];

const Form57Ledger = () => (
  <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Form 57 - Ordnance Ledger Cards</h2>
      <table className="min-w-full text-sm">
          <thead>
              <tr className="border-b">
                  <th className="py-2 px-4">Reference</th>
                  <th className="py-2 px-4">Officer</th>
                  <th className="py-2 px-4">Item</th>
                  <th className="py-2 px-4">Quantity</th>
                  <th className="py-2 px-4">Date</th>
                  <th className="py-2 px-4">Transaction Type</th>
              </tr>
          </thead>
          <tbody>
              {form57Transactions.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50 border-b cursor-pointer">
                      <td className="py-2 px-4">{entry.reference}</td>
                      <td className="py-2 px-4">{entry.officer}</td>
                      <td className="py-2 px-4">{entry.item}</td>
                      <td className="py-2 px-4">{entry.quantity}</td>
                      <td className="py-2 px-4">{entry.transactionDate}</td>
                      <td className={`py-2 px-4 ${
                          entry.transactionType === "Issued" ? "text-blue-600" : "text-green-600"
                      }`}>
                          {entry.transactionType}
                      </td>
                  </tr>
              ))}
          </tbody>
      </table>
  </div>
);

export default Form57Ledger;