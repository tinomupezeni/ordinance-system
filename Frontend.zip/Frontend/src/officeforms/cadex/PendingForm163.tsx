import { Button } from "@/components/ui/button";
import Form163Pdf from "@/formPdfs/Form163Pdf";
import { X, Check, Ban } from "lucide-react";
import { useState } from "react";

const PendingForm163s = ({ requests }) => {
  // Static data for Form 163 requests
  const [displayRequests, setDisplayRequests] = useState(
    requests || [
      {
        id: 1,
        formNumber: "163-2023-001",
        date: "2023-05-15",
        station: "Harare Central",
        itemsRequested: "Trousers (20), Jackets (15)",
        status: "Pending",
      },
      {
        formNumber: "163-2023-001",
        date: "2023-05-15",
        station: "Harare Central",
        itemsRequested: "Trousers (20), Jackets (15)",
        status: "Pending",
      },
      {
        formNumber: "163-2023-002",
        date: "2023-05-16",
        station: "Bulawayo Main",
        itemsRequested: "Shirts (30), Caps (25)",
        status: "Pending",
      },
      {
        formNumber: "163-2023-003",
        date: "2023-05-17",
        station: "Mutare Depot",
        itemsRequested: "Boots (50), Belts (40)",
        status: "Pending",
      },
      {
        formNumber: "163-2023-004",
        date: "2023-05-18",
        station: "Gweru HQ",
        itemsRequested: "Jerseys (35), Raincoats (20)",
        status: "Pending",
      },
      {
        formNumber: "163-2023-005",
        date: "2023-05-19",
        station: "Masvingo Station",
        itemsRequested: "Trousers (25), Shirts (25)",
        status: "Processed",
      },
      {
        formNumber: "163-2023-005",
        date: "2023-05-19",
        station: "Masvingo Station",
        itemsRequested: "Trousers (25), Shirts (25)",
        status: "Processed",
      },
      {
        formNumber: "163-2023-005",
        date: "2023-05-19",
        station: "Masvingo Station",
        itemsRequested: "Trousers (25), Shirts (25)",
        status: "Processed",
      },
      // ... other static requests
    ]
  );

  const [openForm, setOpenForm] = useState(false);
  const [currentForm, setCurrentForm] = useState(null);

  const viewForm = (form) => {
    setCurrentForm(form);
    setOpenForm(true);
  };

  const handleProcess = (formId) => {
    setDisplayRequests(prev =>
      prev.map(req =>
        req.id === formId ? { ...req, status: "Processed" } : req
      )
    );
    setOpenForm(false);
  };

  const handleReject = (formId) => {
    setDisplayRequests(prev =>
      prev.map(req =>
        req.id === formId ? { ...req, status: "Rejected" } : req
      )
    );
    setOpenForm(false);
  };

  return (
    <div className="bg-white p-4 shadow rounded mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">
          Form 163 - Internal Requisitions
        </h2>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setOpenForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  <X className="w-4 h-4" />
                  Back to list
                </Button>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="destructive"
                  onClick={() => handleReject(currentForm.id)}
                  className="flex items-center gap-2"
                >
                  <Ban className="w-4 h-4" />
                  Reject Requisition
                </Button>
                <Button
                  variant="default"
                  onClick={() => handleProcess(currentForm.id)}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <Check className="w-4 h-4" />
                  Process Requisition
                </Button>
              </div>
            </div>

            <div className="mt-4">
              <Form163Pdf
                formData={currentForm}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b">
                <th className="py-3 px-4 text-left">Form #</th>
                <th className="py-3 px-4 text-left">Date</th>
                <th className="py-3 px-4 text-left">Station</th>
                <th className="py-3 px-4 text-left">Items Requested</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayRequests.map((req) => (
                <tr key={req.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{req.formNumber}</td>
                  <td className="py-3 px-4">{req.date}</td>
                  <td className="py-3 px-4">{req.station}</td>
                  <td className="py-3 px-4">{req.itemsRequested}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        req.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : req.status === "Rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {req.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewForm(req)}
                    >
                      View
                    </Button>
                    {req.status === "Pending" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => handleReject(req.id)}
                        >
                          Reject
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => handleProcess(req.id)}
                        >
                          Process
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default PendingForm163s;