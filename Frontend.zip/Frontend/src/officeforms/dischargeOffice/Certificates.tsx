const zrpCertificates = [
    { id: 1, officer: "Constable John M.", issuedOn: "2025-05-06", status: "Issued" },
    { id: 2, officer: "Sergeant Clara Z.", issuedOn: "2025-05-02", status: "Pending" },
  ];
  
  const ZRPCertificates = () => (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">ZRP Discharge Certificates</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Officer</th>
            <th className="py-2 px-4">Issued On</th>
            <th className="py-2 px-4">Status</th>
          </tr>
        </thead>
        <tbody>
          {zrpCertificates.map((cert) => (
            <tr key={cert.id} className="hover:bg-gray-50">
              <td className="py-2 px-4">{cert.officer}</td>
              <td className="py-2 px-4">{cert.issuedOn}</td>
              <td className="py-2 px-4">{cert.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  export default ZRPCertificates;
  