const dischargeBook2Entries = [
    { id: 1, item: "Uniform Kit", quantity: 1, officer: "Constable John M.", date: "2025-05-05" },
    { id: 2, item: "Ration Pack", quantity: 2, officer: "Sergeant Clara Z.", date: "2025-05-01" },
  ];
  
  const Book2DischargeLog = () => (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Book 2 - Discharge Transactions</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Item</th>
            <th className="py-2 px-4">Quantity</th>
            <th className="py-2 px-4">Officer</th>
            <th className="py-2 px-4">Date</th>
          </tr>
        </thead>
        <tbody>
          {dischargeBook2Entries.map((entry) => (
            <tr key={entry.id} className="hover:bg-gray-50">
              <td className="py-2 px-4">{entry.item}</td>
              <td className="py-2 px-4">{entry.quantity}</td>
              <td className="py-2 px-4">{entry.officer}</td>
              <td className="py-2 px-4">{entry.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  export default Book2DischargeLog;
  