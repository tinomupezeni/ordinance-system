// components/ProcessedFormsHistory.tsx
const ProcessedFormsHistory = () => {
    const forms = [
      { id: "109-000", supplier: "Mutare Depot", date: "2025-05-04", items: 5 },
    ];
  
    return (
      <div className="bg-white p-4 rounded-xl shadow">
        <h2 className="text-lg font-semibold mb-4">🗂️ Recently Processed Form 109s</h2>
        <ul className="space-y-2 text-sm text-gray-700">
          {forms.map((form) => (
            <li key={form.id} className="border-b pb-2">
              <strong>{form.id}</strong> – {form.items} items from {form.supplier} ({form.date})
            </li>
          ))}
        </ul>
      </div>
    );
  };
  
  export default ProcessedFormsHistory;
  