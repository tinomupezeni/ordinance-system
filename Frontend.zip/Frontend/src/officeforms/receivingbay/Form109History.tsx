import Form109Pdf from "@/formPdfs/Form109Pdf";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import Server from "@/server/Server";

interface Form109Entry {
  formNumber: string;
  dateReceived: string;
  itemsReceived: number;
  sender: string;
  status: "Processed" | "Pending" | "Rejected";
}

// const forms109: Form109Entry[] = [
//   {
//     formNumber: "109/2025/032",
//     dateReceived: "2025-05-05",
//     itemsReceived: 120,
//     sender: "Supply HQ",
//     status: "Processed",
//   },
//   {
//     formNumber: "109/2025/031",
//     dateReceived: "2025-05-04",
//     itemsReceived: 80,
//     sender: "Harare Central",
//     status: "Processed",
//   },
//   {
//     formNumber: "109/2025/030",
//     dateReceived: "2025-05-03",
//     itemsReceived: 200,
//     sender: "Support Unit",
//     status: "Rejected",
//   },
//   {
//     formNumber: "109/2025/132",
//     dateReceived: "2025-05-15",
//     itemsReceived: 95,
//     sender: "Supply HQ",
//     status: "Pending",
//   },
//   {
//     formNumber: "109/2025/131",
//     dateReceived: "2025-05-15",
//     itemsReceived: 150,
//     sender: "Eastern Depot",
//     status: "Processed",
//   },
//   {
//     formNumber: "109/2025/033",
//     dateReceived: "2025-05-05",
//     itemsReceived: 65,
//     sender: "Northern Warehouse",
//     status: "Rejected",
//   },
// // ];

const Form109History = () => {
  const [openFormDetails, setOpenFormDetails] = useState(false);
  const [dateFilter, setDateFilter] = useState("");
  const [senderFilter, setSenderFilter] = useState("");
  const [forms109, setForms109] = useState([]);
  const [selectedForm, setSelectedForm] = useState<Form109Entry | null>(null);

  const filteredHistory = forms109.filter((entry) => {
    const matchesDate = dateFilter
      ? entry.dateReceived.includes(dateFilter)
      : true;
    const matchesSender = senderFilter
      ? entry.sender.toLowerCase().includes(senderFilter.toLowerCase())
      : true;
    return matchesDate && matchesSender;
  });

  const viewFormDetails = (formId: string) => {
    const form = forms109.find(entry => entry.id === formId);
    if (form) {
      setSelectedForm(form);
      setOpenFormDetails(true);
    }
  };

  const getForm109 = () => {
    Server.getForms("form109")
      .then((response) => {
        console.log("forms 109 == ",response);
        setForms109(response.results);
      })
      .catch((error) => {
        console.log(error);
      });
  };


  useEffect(() => {
    getForm109();
  }, []);

  return (
    <div className="bg-white shadow rounded-lg p-4 mt-5">
      <h1 className="text-lg font-semibold mb-4">Receiving Bay Office</h1>
      {!openFormDetails ? (
        <div className="">
          <h2 className="text-lg font-semibold mb-4">All Recorded Form 109</h2>

          {/* Simple always-visible filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Filter by supplier..."
                value={senderFilter}
                onChange={(e) => setSenderFilter(e.target.value)}
                className="pl-10 w-full rounded-md border border-gray-300 py-2 px-3 text-sm"
              />
            </div>
            <div className="flex-1">
              <input
                type="date"
                placeholder="Filter by date..."
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-full rounded-md border border-gray-300 py-2 px-3 text-sm"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-sm text-left">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-2 px-4">Form #</th>
                  <th className="py-2 px-4">Date Received</th>
                  <th className="py-2 px-4">Received From</th>
                  <th className="py-2 px-4">Number of Items Received</th>
                  <th className="py-2 px-4">Stock Type</th>
                </tr>
              </thead>
              <tbody>
                {filteredHistory.map((entry, index) => (
                  <tr
                    key={index}
                    className="border-b border-gray-100 hover:bg-gray-50 cursor-pointer"
                    onClick={() => viewFormDetails(entry.id)}
                  >
                    <td className="py-3 px-4">{entry.id}</td>
                    <td className="py-3 px-4">{entry.received_by_date}</td>
                    <td className="py-3 px-4">{entry.received_from}</td>
                    <td className="py-3 px-4">{entry.items.length}</td>
                    <td className="py-3 px-4 capitalize">{entry.stock_type}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <Form109Pdf
          formData={selectedForm}
          onBack={() => setOpenFormDetails(false)}
          onPrint={function (): void {
            throw new Error("Function not implemented.");
          }}
        />
      )}
    </div>
  );
};

export default Form109History;
