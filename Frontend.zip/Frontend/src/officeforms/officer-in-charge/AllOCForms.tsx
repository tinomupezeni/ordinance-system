import React, { useEffect, useState } from "react";
import {
  FileText,
  CheckCircle,
  Clock,
  XCircle,
  X,
  ArrowLeftCircle,
} from "lucide-react";
import Form163Pdf from "@/formPdfs/Form163Pdf";
import Form227Pdf from "@/formPdfs/Form227Pdf";
import Form99Pdf from "@/formPdfs/Form99Pdf";
import ClothingCardForm from "@/forms/Form51B";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
// import { printWithStyles } from "@/utils/print";
import Server from "@/server/Server";
import { toast } from "sonner";

// Define a type for our form data
type FormData = {
  formNumber: string;
  formType: string;
  office_in_charge_status: "awaiting" | "approved" | "rejected";
  date: string;
  requestedBy: string;
};

const AllOfficerInCharge = () => {
  // State for forms data
  const [forms, setForms] = useState<FormData[]>([
   
  ]);
  const [formData, setFormData] = useState(null);

  const [selectedFormType, setSelectedFormType] = useState<string | null>(null);
  const [selectedFormIndex, setSelectedFormIndex] = useState<number | null>(
    null
  );
  const [showApproveConfirm, setShowApproveConfirm] = useState(false);

  const handleFetchAllForms = () => {
    Server.getForms227AdminAuth().then((response) => {
      setForms(response)
    })
  }

  useEffect(() => {
    handleFetchAllForms()
  }, [])

  const handleFormSelection = (
    formType: string,
    index: number,
    formNumber: number
  ) => {
    setSelectedFormType(formType);
    setSelectedFormIndex(index);

    // send the form id to backend and return the form data
    console.log(formNumber);

    setFormData(forms.find(form => form.id === formNumber));
    setSelectedFormType('Form 227')

  };

  const handleApprove = (formId) => {
    if (selectedFormIndex !== null) {
      
      Server.authorizeForm227(formId).then(() => {
const updatedForms = [...forms];
      updatedForms[selectedFormIndex].office_in_charge_status = "approved";
      setForms(updatedForms);
      setSelectedFormType(null);
      setSelectedFormIndex(null);
      setShowApproveConfirm(false);
      }).catch((error) => {
        toast.error('An error occurred: ' + (error?.message || 'Unknown error'));
console.error(error);

        console.log(error);
        
      })
    }
  };

  const handleReject = () => {
    if (selectedFormIndex !== null) {
      const updatedForms = [...forms];
      updatedForms[selectedFormIndex].office_in_charge_status = "rejected";
      setForms(updatedForms);
      setSelectedFormType(null);
      setSelectedFormIndex(null);
    }
  };
  const handleBackHome = () => {
    if (selectedFormIndex !== null) {
      setSelectedFormType(null);
      setSelectedFormIndex(null);
    }
  };

  const renderFormContent = () => {
    switch (selectedFormType) {
      case "Form 163":
        return (
          <Form163Pdf
            formData={formData}
            onBack={() => {
              setSelectedFormType(null);
              setSelectedFormIndex(null);
            }}
            onPrint={function (): void {
              throw new Error("Function not implemented.");
            }}
          />
        );
      case "Form 227":
        return (
          <Form227Pdf
            formData={formData}
            onBack={() => {
              setSelectedFormType(null);
              setSelectedFormIndex(null);
            }}
            onPrint={() => printWithStyles(".formpdf")}
          />
        );
      case "Form 99":
        return (
          <Form99Pdf
            formData={formData}
            onBack={() => {
              setSelectedFormType(null);
              setSelectedFormIndex(null);
            }}
            onPrint={function (): void {
              throw new Error("Function not implemented.");
            }}
          />
        );
      case "Form 51A":
        return <ClothingCardForm />;
      default:
        return <p>Please select a form to view its details.</p>;
    }
  };

  const getStatusBadge = (status: FormData["status"]) => {
    switch (status) {
      case "approved":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-green-100 text-green-800">
            <CheckCircle className="w-4 h-4" />
            {status}
          </span>
        );
      case "rejected":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-red-100 text-red-800">
            <XCircle className="w-4 h-4" />
            {status}
          </span>
        );
      case "awaiting":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-yellow-100 text-yellow-800">
            <Clock className="w-4 h-4" />
            {status}
          </span>
        );
      default:
        return <span>{status}</span>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="p-6">
        <h2 className="text-2xl font-semibold mb-6">
          Officer in Charge - Forms Awaiting Approval
        </h2>
        {!selectedFormType ? (
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <table className="min-w-full table-auto text-sm">
              <thead>
                <tr className="border-b">
                  <th className="py-3 px-4 text-left">Form #</th>
                  <th className="py-3 px-4 text-left">Form Type</th>
                  <th className="py-3 px-4 text-left">Requested By</th>
                  <th className="py-3 px-4 text-left">Date</th>
                  <th className="py-3 px-4 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {forms.map((form, index) => (
                  <tr
                    key={index}
                    className="border-b hover:bg-gray-50 cursor-pointer"
                    onClick={() =>
                      handleFormSelection(form.formType, index, form.id)
                    }
                  >
                    <td className="py-3 px-4">{form.id}</td>
                    <td className="py-3 px-4 text-blue-600 hover:text-blue-800">
                      {/* {form.formType} */}
                      Form 227
                    </td>
                    <td className="py-3 px-4">{form.collectedBy.name}</td>
                    <td className="py-3 px-4">{form.date}</td>
                    <td className="py-3 px-4">{getStatusBadge(form.office_in_charge_status)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="mt-6 bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex justify-between items-center mb-4 w-[50%] mx-auto">
              <h3 className="text-xl font-semibold">Form Details</h3>
              <Button
                variant="outline"
                className=" text-gray-500 hover:bg-gray-50 hover:text-gray-600"
                onClick={handleBackHome}
              >
                <ArrowLeftCircle className="w-4 h-4 mr-2" />
                Back
              </Button>
              {forms[selectedFormIndex!].office_in_charge_status === "awaiting" ? (
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="border-red-500 text-red-500 hover:bg-red-50 hover:text-red-600"
                    onClick={handleReject}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => setShowApproveConfirm(true)}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                </div>
              ) : (
                <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-green-100 text-green-800">
                  <CheckCircle className="w-4 h-4" />
                  Approved
                </span>
              )}
            </div>
            {renderFormContent()}
          </div>
        )}
      </div>

      {/* Approval Confirmation Dialog */}
      <AlertDialog
        open={showApproveConfirm}
        onOpenChange={setShowApproveConfirm}

      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Approval</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to approve this form? This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-green-600 hover:bg-green-700"
              onClick={() => handleApprove(forms[selectedFormIndex!]?.id)}

            >
              Approve
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AllOfficerInCharge;
