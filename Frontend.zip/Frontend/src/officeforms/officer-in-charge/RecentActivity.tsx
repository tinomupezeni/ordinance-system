// components/RecentActivity.tsx
const RecentActivity = () => {
    const activities = [
      {
        user: "Sgt. Dube",
        action: "Approved Exchange Voucher",
        date: "2025-05-05",
      },
      {
        user: "Cst. Sibanda",
        action: "Submitted Request for Supplies",
        date: "2025-05-04",
      },
      {
        user: "Sgt. Dube",
        action: "Removed 10 Jackets from inventory",
        date: "2025-05-03",
      },
    ];
  
    return (
      <div className="bg-white p-4 rounded-xl shadow ">
        <h2 className="text-lg font-semibold mb-4">📋 Recent Activity</h2>
        <ul className="space-y-2 text-sm text-gray-700">
          {activities.map((act, idx) => (
            <li key={idx} className="border-b pb-4">
              <strong>{act.user}</strong> – {act.action} ({act.date})
            </li>
          ))}
        </ul>
      </div>
    );
  };
  
  export default RecentActivity;
  