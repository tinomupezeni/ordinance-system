const form163Dispatches = [
    { id: 1, item: "Radio Set", destination: "CID HQ", dispatchedBy: "Constable T. Mapfumo", date: "2025-04-10" },
    { id: 2, item: "Barricades", destination: "ZRP Mabvuku", dispatchedBy: "Sergeant M. Chirwa", date: "2025-04-12" },
  ];
  
  const Form163Dispatches = () => (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Form 163 - Dispatch Log</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Item</th>
            <th className="py-2 px-4">Destination</th>
            <th className="py-2 px-4">Dispatched By</th>
            <th className="py-2 px-4">Date</th>
          </tr>
        </thead>
        <tbody>
          {form163Dispatches.map((entry) => (
            <tr key={entry.id} className="hover:bg-gray-50">
              <td className="py-2 px-4">{entry.item}</td>
              <td className="py-2 px-4">{entry.destination}</td>
              <td className="py-2 px-4">{entry.dispatchedBy}</td>
              <td className="py-2 px-4">{entry.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  export default Form163Dispatches;
  