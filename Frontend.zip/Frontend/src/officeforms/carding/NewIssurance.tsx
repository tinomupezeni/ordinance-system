import { Input } from "@/components/ui/input";
import { Trash, Plus, ChevronDown, ChevronUp } from "lucide-react";
import React, { useState, useMemo, useEffect, useCallback } from "react"; // Added useCallback
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Server from "@/server/Server";
import { toast } from "sonner";
import { parseISO, addMonths, isPast } from "date-fns"; // Import date-fns for date calculations

// --- Interface Definitions (copied from ClothingCardViewer to ensure consistency) ---
interface ClothingItemDetails {
  id: number;
  name: string;
  full_name: string | null;
  lifespan_months: number | null;
  category_name: string;
}

interface IssuedItem {
  id: number;
  clothing_item: ClothingItemDetails;
  quantity: number;
}

interface Issuance {
  id: number;
  clNo: string | null;
  date: string; // Date of issuance
  serialNo: string | null;
  issued_by?: string | null;
  issued_by_date?: string | null;
  issued_by_signature?: string | null;
  selectedItems: IssuedItem[];
}

interface OfficerData {
  id: number;
  branch: string;
  certClNo: string;
  dateAttested: string;
  forceNo: string;
  initials: string;
  issuances: Issuance[]; // Array of Issuance objects
  name: string;
  sccNo: string;
  issuedBy?: string | null;
  issuedByDate?: string | null;
  issuedBySignature?: string | null;
}

// Accept initialIssuanceCount AND officerData as props
const NewIssurance = ({ initialIssuanceCount = 0, officerData }) => {
  const [issuances, setIssuances] = useState([
    {
      id: Date.now(),
      serialNo: "",
      date: "",
      clNo: "",
      selectedItems: [],
      isOpen: true,
    },
  ]);

  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>(
    {}
  );

  const [formData, setFormData] = useState({
    forceNo: officerData?.forceNo || "", // Pre-fill from officerData if available
    gender: "M",
    dateAttested: officerData?.dateAttested || "", // Pre-fill
    branch: officerData?.branch || "", // Pre-fill
    name: officerData?.name || "", // Pre-fill
    initials: officerData?.initials || "", // Pre-fill
    certClNo: officerData?.certClNo || "", // Pre-fill
    sccNo: officerData?.sccNo || "", // Pre-fill
    issuedByDate: "", // These are for *new* overall issuance, not pre-filled
    issuedBySignature: "",
    issuedBy: "",
  });

  // Effect to update formData if officerData changes (e.g., a new officer is selected)
  useEffect(() => {
    if (officerData) {
      setFormData((prev) => ({
        ...prev,
        forceNo: officerData.forceNo || "",
        dateAttested: officerData.dateAttested || "",
        branch: officerData.branch || "",
        name: officerData.name || "",
        initials: officerData.initials || "",
        certClNo: officerData.certClNo || "",
        sccNo: officerData.sccNo || "",
      }));
      // Reset issuances when officerData changes to start fresh for a new officer
      setIssuances([
        {
          id: Date.now(),
          serialNo: "",
          date: "",
          clNo: "",
          selectedItems: [],
          isOpen: true,
        },
      ]);
    }
  }, [officerData]);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleIssuanceChange = (id, field, value) => {
    setIssuances((prev) =>
      prev.map((issuance) =>
        issuance.id === id ? { ...issuance, [field]: value } : issuance
      )
    );
  };

  const toggleIssuance = (id) => {
    setIssuances((prev) =>
      prev.map((issuance) =>
        issuance.id === id
          ? { ...issuance, isOpen: !issuance.isOpen }
          : issuance
      )
    );
  };

  const toggleCategory = (category) => {
    setOpenCategories((prev) => ({
      ...prev,
      [category]: !prev[category],
    }));
  };

  const toggleItemSelection = (issuanceId, category, itemName) => {
    setIssuances((prev) =>
      prev.map((issuance) => {
        if (issuance.id !== issuanceId) return issuance;

        const itemKey = `${category}|${itemName}`;
        const selectedItems = issuance.selectedItems.includes(itemKey)
          ? issuance.selectedItems.filter((i) => i !== itemKey)
          : [...issuance.selectedItems, itemKey];

        return { ...issuance, selectedItems };
      })
    );
  };

  const addIssuance = () => {
    setIssuances((prev) => [
      ...prev,
      {
        id: Date.now(),
        serialNo: "",
        date: "",
        clNo: "",
        selectedItems: [],
        isOpen: true,
      },
    ]);
  };

  const removeIssuance = (idToRemove) => {
    setIssuances((prev) =>
      prev.filter((issuance) => issuance.id !== idToRemove)
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Basic validation: Check if forceNo is present
    if (!formData.forceNo) {
      toast.error("Please provide a Force Number for the officer.");
      return;
    }

   // Validate each issuance has a date
  for (let i = 0; i < issuances.length; i++) {
    if (!issuances[i].date) {
      toast.error(`Please provide a date for Issuance ${i + 1}`);
      return;
    }
  }

    const submissionData = {
      issuances: issuances.map((issuance) => ({
        serialNo: issuance.serialNo,
        date: issuance.date,
        clNo: issuance.clNo,
        selectedItems: issuance.selectedItems.map((item) => {
          const [category, itemName] = item.split("|");
          return {
            category,
            item_name: itemName,
            // You might want to include quantity here if needed
          };
        }),
      })),
    };

    console.log(submissionData);

    Server.patchOfficer(formData.forceNo, submissionData)
      .then(() => {
        toast.success("Successfully updated Officer Issuances");
        // Clear form after successful submission
        setFormData({
          forceNo: "",
          gender: "M",
          dateAttested: "",
          branch: "",
          name: "",
          initials: "",
          certClNo: "",
          sccNo: "",
          issuedByDate: "",
          issuedBySignature: "",
          issuedBy: "",
        });
        setIssuances([
          {
            id: Date.now(),
            serialNo: "",
            date: "",
            clNo: "",
            selectedItems: [],
            isOpen: true,
          },
        ]);
      })
      .catch((error) => {
        console.error("Submission error:", error);
        toast.error(
          "An error occurred during submission. Check console for details."
        );
      });
  };

  const [allClothingItemsDetails, setAllClothingItemsDetails] = useState<
    ClothingItemDetails[]
  >([]);

  const getAllClothingItemDetails = () => {
    Server.getAllClothingItem() // Assuming this endpoint returns the full details including lifespan
      .then((response) => {
        // Transform the response if needed to flatten it into an array of ClothingItemDetails
        // Your `allClothingItems` might be a { category: [item_name, item_name, ...] }
        // We need an array of objects like { id, name, lifespan_months, category_name }
        const flattenedItems: ClothingItemDetails[] = [];
        for (const categoryName in response) {
          response[categoryName].forEach((item: any) => {
            // Assuming item might be just string or object
            flattenedItems.push({
              id: item.id, // Assuming your backend provides an ID for each item
              name: item.item_name || item, // Handle if item is just a string name
              full_name: null, // If your backend doesn't provide this, leave null
              lifespan_months: item.lifespan_months, // Make sure this is in your backend response
              category_name: categoryName,
            });
          });
        }
        setAllClothingItemsDetails(flattenedItems);
      })
      .catch((error) => {
        console.error("Error fetching all clothing items:", error);
      });
  };

  useEffect(() => {
    getAllClothingItemDetails();
  }, []);

  // Map of item name to its lifespan and last issue date
  const itemEligibility: Record<
    string,
    { lastIssuedDate: Date | null; lifespanMonths: number | null }
  > = useMemo(() => {
    const eligibilityMap: Record<
      string,
      { lastIssuedDate: Date | null; lifespanMonths: number | null }
    > = {};

    // First, populate with lifespans from all available clothing items
    allClothingItemsDetails.forEach((item) => {
      eligibilityMap[item.name] = {
        lastIssuedDate: null, // Default
        lifespanMonths: item.lifespan_months,
      };
    });

    // Then, override with actual last issue dates from officerData
    if (officerData && officerData.issuances) {
      officerData.issuances.forEach((issuance) => {
        issuance.selectedItems.forEach((issuedItem) => {
          const itemName = issuedItem.clothing_item.name;
          const issueDate = parseISO(issuance.date); // Convert string to Date object

          // Update if this is a more recent issuance for the item
          if (
            !eligibilityMap[itemName] ||
            !eligibilityMap[itemName].lastIssuedDate ||
            issueDate > eligibilityMap[itemName].lastIssuedDate!
          ) {
            eligibilityMap[itemName] = {
              lastIssuedDate: issueDate,
              lifespanMonths: issuedItem.clothing_item.lifespan_months,
            };
          }
        });
      });
    }
    return eligibilityMap;
  }, [officerData, allClothingItemsDetails]);

  const isItemEligibleForIssuance = useCallback(
    (itemName: string) => {
      const itemInfo = itemEligibility[itemName];
      if (!itemInfo || itemInfo.lifespanMonths === null) {
        // If no lifespan defined or never issued, it's always eligible
        return true;
      }

      if (!itemInfo.lastIssuedDate) {
        // If lifespan is defined but never issued, it's eligible
        return true;
      }

      const eligibleDate = addMonths(
        itemInfo.lastIssuedDate,
        itemInfo.lifespanMonths
      );
      return isPast(eligibleDate); // Returns true if eligibleDate is in the past
    },
    [itemEligibility]
  );

  const sortedClothingCategories = useMemo(() => {
    // We need to group by category_name from allClothingItemsDetails now
    const categories: Record<string, ClothingItemDetails[]> = {};
    allClothingItemsDetails.forEach((item) => {
      if (!categories[item.category_name]) {
        categories[item.category_name] = [];
      }
      categories[item.category_name].push(item);
    });

    return Object.entries(categories).sort(([catA], [catB]) =>
      catA.localeCompare(catB)
    );
  }, [allClothingItemsDetails]);

  const getSortedItemsForCategory = useCallback(
    (category: string) => {
      // This now returns ClothingItemDetails objects
      const items = allClothingItemsDetails.filter(
        (item) => item.category_name === category
      );
      return items.sort((a, b) => a.name.localeCompare(b.name));
    },
    [allClothingItemsDetails]
  );

  return (
    <div className="max-w-4xl mx-auto  bg-gradient-to-br from-blue-50 to-indigo-100 rounded-xl  font-sans mt-8">
      {/* Form Header Section */}
      <div className="text-center mb-8 bg-blue-700 text-white py-4 px-6 rounded-t-lg shadow-inner">
        <h2 className="font-extrabold tracking-tight">
          ADD NEW OFFICER & ISSUANCE
        </h2>
        <p className="text-sm opacity-90">Clothing Card Form</p>
      </div>

      {issuances.map((issuance, index) => (
        <Card key={issuance.id} className="mb-6 overflow-hidden ">
          <CardHeader
            className=" py-3 px-5 flex justify-between items-center cursor-pointer  transition-colors duration-200"
            onClick={() => toggleIssuance(issuance.id)}
          >
            <CardTitle className="text-lg font-semibold flex items-center">
              {issuance.isOpen ? (
                <ChevronUp className="h-5 w-5 mr-3" />
              ) : (
                <ChevronDown className="h-5 w-5 mr-3" />
              )}
              ISSUANCE {initialIssuanceCount + index + 1}
            </CardTitle>
            <div className="flex space-x-2">
              {issuances.length > 1 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-red-500 hover:text-white"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeIssuance(issuance.id);
                  }}
                >
                  <Trash className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>

          {issuance.isOpen && (
            <CardContent className="p-6 bg-white">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4 mb-6">
                <Input
                  label="Serial No."
                  name="serialNo"
                  value={issuance.serialNo}
                  onChange={(e) =>
                    handleIssuanceChange(
                      issuance.id,
                      "serialNo",
                      e.target.value
                    )
                  }
                />
                <Input
                  label="Date"
                  type="date"
                  name="date"
                  value={issuance.date}
                  onChange={(e) =>
                    handleIssuanceChange(issuance.id, "date", e.target.value)
                  }
                />
                <Input
                  label="C.L. No."
                  name="clNo"
                  value={issuance.clNo}
                  onChange={(e) =>
                    handleIssuanceChange(issuance.id, "clNo", e.target.value)
                  }
                />
              </div>

              <div className="mb-4">
                <label className="block mb-3 font-semibold text-gray-700">
                  Select Items:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {sortedClothingCategories.map(([categoryName, items]) => (
                    <div
                      key={categoryName}
                      className="border border-gray-200 rounded-lg overflow-hidden shadow-sm"
                    >
                      <div
                        className="flex items-center justify-between p-3 bg-gray-100 cursor-pointer hover:bg-gray-200 transition-colors duration-200"
                        onClick={() => toggleCategory(categoryName)}
                      >
                        <div className="flex items-center">
                          {openCategories[categoryName] ? (
                            <ChevronUp className="h-4 w-4 mr-2 text-gray-600" />
                          ) : (
                            <ChevronDown className="h-4 w-4 mr-2 text-gray-600" />
                          )}
                          <span className="font-medium text-gray-800">
                            {categoryName}{" "}
                            <span className="text-gray-500 text-sm">
                              ({items.length})
                            </span>
                          </span>
                        </div>
                      </div>

                      {openCategories[categoryName] && (
                        <div className="p-3 space-y-2 bg-white">
                          {getSortedItemsForCategory(categoryName).map(
                            (item: ClothingItemDetails) => {
                              const itemKey = `${item.category_name}|${item.name}`;
                              const isEligible = isItemEligibleForIssuance(
                                item.name
                              );
                              const itemClass = isEligible
                                ? "text-gray-700"
                                : "text-gray-400 line-through italic cursor-not-allowed";

                              // Get expiry date for display
                              const lastIssued =
                                itemEligibility[item.name]?.lastIssuedDate;
                              const lifespan =
                                itemEligibility[item.name]?.lifespanMonths;
                              let expiryMessage = "";
                              if (lastIssued && lifespan !== null) {
                                const expiryDate = addMonths(
                                  lastIssued,
                                  lifespan
                                );
                                expiryMessage = ` (Next eligible: ${expiryDate.toLocaleDateString()})`;
                              } else if (lifespan !== null) {
                                expiryMessage = ` (Lifespan: ${lifespan} months)`;
                              }

                              return (
                                <div
                                  key={item.id}
                                  className={`flex items-center justify-between ${itemClass}`}
                                >
                                  <div className="flex items-center space-x-2">
                                    <input
                                      type="checkbox"
                                      checked={issuance.selectedItems.includes(
                                        itemKey
                                      )}
                                      onChange={() =>
                                        toggleItemSelection(
                                          issuance.id,
                                          item.category_name,
                                          item.name
                                        )
                                      }
                                      disabled={!isEligible} // Disable checkbox if not eligible
                                      className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:bg-gray-200 disabled:cursor-not-allowed"
                                    />
                                    <label className="text-sm cursor-pointer">
                                      {item.name}
                                      {!isEligible && (
                                        <span className="ml-2 text-xs text-red-500 font-medium">
                                          Not Eligible {expiryMessage}
                                        </span>
                                      )}
                                    </label>
                                  </div>
                                </div>
                              );
                            }
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {issuance.selectedItems.length > 0 && (
                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <h5 className="font-semibold text-blue-800 mb-3 text-md">
                    Selected Items for this Issuance:
                  </h5>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                    {issuance.selectedItems
                      .slice()
                      .sort((a, b) => {
                        const itemA = a.split("|")[1];
                        const itemB = b.split("|")[1];
                        return itemA.localeCompare(itemB);
                      })
                      .map((item, index) => {
                        const [category, itemName] = item.split("|");
                        return (
                          <li
                            key={index}
                            className="text-sm text-gray-700 flex items-center"
                          >
                            <span className="mr-2 text-blue-500">•</span>
                            <span className="font-medium">{itemName}</span>
                            <span className="ml-2 text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                              {category}
                            </span>
                          </li>
                        );
                      })}
                  </ul>
                </div>
              )}
            </CardContent>
          )}
        </Card>
      ))}

      {/* <Button
        onClick={addIssuance}
        variant="outline"
        className="w-full mb-6 bg-blue-500 text-white py-3 px-6 rounded-lg shadow-md hover:bg-blue-600 transition-colors duration-200 flex items-center justify-center"
      >
        <Plus className="h-4 w-4 mr-2" />
        Add Another Issuance
      </Button> */}

      {/* Overall Issued By Details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4 mt-8 bg-white p-6 rounded-lg border border-gray-200">
        <Input
          label="Overall Issued Date"
          type="date"
          name="issuedByDate"
          value={formData.issuedByDate}
          onChange={handleFormChange}
        />
        <Input
          label="Overall Issued Signature"
          name="issuedBySignature"
          value={formData.issuedBySignature}
          onChange={handleFormChange}
        />
        <Input
          label="Overall Issued By"
          name="issuedBy"
          value={formData.issuedBy}
          onChange={handleFormChange}
        />
      </div>

      <Button
        onClick={handleSubmit}
        className="w-full bg-green-600 text-white py-3 px-6 rounded-lg shadow-md hover:bg-green-700 transition-colors duration-200 mt-6"
      >
        Submit Form
      </Button>

      {/* Footer */}
      <div className="text-center text-xs text-gray-400 mt-10 pt-4 border-t border-gray-200">
        <p>
          © {new Date().getFullYear()} ZRP Asset Management. All rights
          reserved.
        </p>
      </div>
    </div>
  );
};

// Helper component for labeled inputs
const Input = ({ label, ...props }) => (
  <div>
    {label && (
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
    )}
    <input
      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-gray-800"
      {...props}
    />
  </div>
);

export default NewIssurance;
