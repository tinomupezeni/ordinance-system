import Form57Pdf from "@/formPdfs/Form57Pdf";
import { useState } from "react";

const transfers157 = [
  {
    formNumber: "157/2025/022",
    date: "2025-05-02",
    destination: "ZRP Chitungwiza",
    itemsMoved: 60,
    status: "Completed",
  },
  {
    formNumber: "157/2025/021",
    date: "2025-04-28",
    destination: "ZRP Mabvuku",
    itemsMoved: 40,
    status: "In Transit",
  },
];

const TransferLog157 = () => {
  const [showLedger, setShowLedger] = useState(false);

  return (
    <div className="bg-white p-4 shadow rounded">
      <h2 className="text-lg font-semibold mb-3">Form 57 - Main Ledger</h2>

      {!showLedger ? (
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="py-2 px-4">Form #</th>
              <th className="py-2 px-4">Date</th>
              <th className="py-2 px-4">Destination</th>
              <th className="py-2 px-4">Items Moved</th>
              <th className="py-2 px-4">Status</th>
            </tr>
          </thead>
          <tbody>
            {transfers157.map((transfer, i) => (
              <tr
                key={i}
                className="hover:bg-gray-50 cursor-pointer"
                onClick={() => setShowLedger(true)}
              >
                <td className="py-2 px-4">{transfer.formNumber}</td>
                <td className="py-2 px-4">{transfer.date}</td>
                <td className="py-2 px-4">{transfer.destination}</td>
                <td className="py-2 px-4">{transfer.itemsMoved}</td>
                <td className="py-2 px-4">{transfer.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <Form57Pdf
          formData={undefined}
          onBack={() => setShowLedger(false)}
          onPrint={function (): void {
            throw new Error("Function not implemented.");
          }}
        />
      )}
    </div>
  );
};

export default TransferLog157;
