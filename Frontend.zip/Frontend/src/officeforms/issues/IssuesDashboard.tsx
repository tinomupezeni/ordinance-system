import { useEffect, useState } from "react";
import SummaryCard from "@/components/SummaryCard";
import { Button } from "@/components/ui/button";
import Form227 from "@/forms/Form227";
import Form163 from "@/forms/Form163";
import PendingForm51Requests from "@/officeforms/issues/PendingForm51Requests";
import Book2Register from "@/officeforms/issues/Book2Register";
import TransferHistory157 from "@/officeforms/cadex/TransferHistory157";
import Form57Ledger from "@/officeforms/loans/Form57";
import Form163Dispatches from "@/officeforms/dispatch/Form163Dispatches";
import Server from "@/server/Server";

const issuesSummary = [
  { title: "Book2 /I.V", count: 8, forms: "Book2" },
  { title: "Form 227", count: 5, forms: "Form227", notify: 2 },
  { title: "Form 51", count: 3, forms: "Form51" },
  { title: "Form 163", count: 3, forms: "Form163" },
  { title: "Form 57", count: 3, forms: "Form57" },
  { title: "Form 157", count: 3, forms: "Form157" },
];

export default function IssuesOfficerDashboard() {
  const [activeForm, setActiveForm] = useState("Form227"); // Default to Form227



  // Map form keys to components
  const formComponents = {
    Form227: <Form227 onBack={() => setActiveForm("Form227")} />,
    Form163: <Form163 onBack={() => setActiveForm("Form227")} />,
    Form51: <PendingForm51Requests />,
    Book2: <Book2Register />,
    Form157: <TransferHistory157 />,
    Form57: <Form57Ledger />,
    Form163Dispatches: <Form163Dispatches />,
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6 mt-5">
        {issuesSummary.map((item, idx) => (
          <SummaryCard
            key={idx}
            title={item.title}
            count={item.count}
            notify={item.notify}
            forms={item.forms}
            onViewAll={() => setActiveForm(item.forms)}
          />
        ))}
      </div>

      <div className="space-x-4 my-5">
        <Button
          variant={activeForm === "Form227" ? "default" : "outline"}
          onClick={() => setActiveForm("Form227")}
        >
          Issue Voucher [Form 227]
        </Button>
        <Button
          variant={activeForm === "Form163" ? "default" : "outline"}
          onClick={() => setActiveForm("Form163")}
        >
          Requisition Voucher [Form 163]
        </Button>
      </div>

      <div className="mt-5">
        {formComponents[activeForm]}
      </div>
    </>
  );
}
