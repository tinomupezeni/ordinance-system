import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import Form57Pdf from "@/formPdfs/Form57Pdf";
import { useState } from "react";
import { Printer, ArrowLeft } from "lucide-react";

const clothingCards = [
  {
    formNumber: "163/2025/011",
    date: "2025-05-05",
    size: 40,
    status: "Pending",
    officer: "Sgt. B. Dube",
    station: "Harare Central"
  },
  {
    formNumber: "163/2025/010",
    date: "2025-05-04",
    requestedBy: "Trouser Mat",
    size: 120,
    status: "Approved",
    officer: "Insp. T. Moyo",
    station: "Bulawayo Main"
  },
  {
    formNumber: "163/2025/012",
    date: "2025-05-05",
    requestedBy: "Shirt Grey",
    size: 43,
    status: "Pending",
    officer: "Cst. R. Ndlovu",
    station: "Mutare Depot"
  },
  {
    formNumber: "163/2025/013",
    date: "2025-05-06",
    requestedBy: "Jersey Blue",
    size: 38,
    status: "Rejected",
    officer: "Sgt. L. Chuma",
    station: "Gweru HQ"
  },
  {
    formNumber: "163/2025/014",
    date: "2025-05-07",
    requestedBy: "Raincoat",
    size: 45,
    status: "Approved",
    officer: "Insp. K. Sibanda",
    station: "Masvingo Station"
  },
];

const ClothingCardsIssues = () => {
  const [filters, setFilters] = useState({
    date: "",
    requestedBy: "",
    size: "",
    status: "",
    officer: "",
    station: ""
  });

  const [showLedger, setShowLedger] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);

  const uniqueItems = Array.from(new Set(clothingCards.map(f => f.requestedBy)));
  const uniqueStations = Array.from(new Set(clothingCards.map(f => f.station)));
  const uniqueOfficers = Array.from(new Set(clothingCards.map(f => f.officer)));
  const statusOptions = ["Pending", "Approved", "Rejected"];

  const filteredForms = clothingCards.filter(form => {
    return (
      (filters.date === "" || form.date === filters.date) &&
      (filters.requestedBy === "" || form.requestedBy === filters.requestedBy) &&
      (filters.size === "" || form.size === Number(filters.size)) &&
      (filters.status === "" || form.status === filters.status) &&
      (filters.officer === "" || form.officer === filters.officer) &&
      (filters.station === "" || form.station === filters.station)
    );
  });

  const handleViewLedger = (card) => {
    setSelectedCard(card);
    setShowLedger(true);
  };

  const resetFilters = () => {
    setFilters({
      date: "",
      requestedBy: "",
      size: "",
      status: "",
      officer: "",
      station: ""
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 ml-72 mt-20">
          <div className="bg-white p-6 shadow rounded-lg">
            {!showLedger ? (
              <>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold text-gray-800">
                    Clothing Cards Records
                  </h2>
                  
                </div>

                {/* Enhanced Filter Section */}
                <div className="grid grid-cols-1 md:grid-cols-7 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input
                      type="date"
                      className="w-full border rounded px-3 py-2"
                      value={filters.date}
                      onChange={(e) => setFilters({ ...filters, date: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Clothing Item</label>
                    <select
                      className="w-full border rounded px-3 py-2"
                      value={filters.requestedBy}
                      onChange={(e) => setFilters({ ...filters, requestedBy: e.target.value })}
                    >
                      <option value="">All Items</option>
                      {uniqueItems.map((item, index) => (
                        <option key={index} value={item}>
                          {item}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Size</label>
                    <input
                      type="number"
                      className="w-full border rounded px-3 py-2"
                      placeholder="Filter by size"
                      value={filters.size}
                      onChange={(e) => setFilters({ ...filters, size: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      className="w-full border rounded px-3 py-2"
                      value={filters.status}
                      onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                    >
                      <option value="">All Statuses</option>
                      {statusOptions.map((status, index) => (
                        <option key={index} value={status}>
                          {status}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Station</label>
                    <select
                      className="w-full border rounded px-3 py-2"
                      value={filters.station}
                      onChange={(e) => setFilters({ ...filters, station: e.target.value })}
                    >
                      <option value="">All Stations</option>
                      {uniqueStations.map((station, index) => (
                        <option key={index} value={station}>
                          {station}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Officer</label>
                    <select
                      className="w-full border rounded px-3 py-2"
                      value={filters.officer}
                      onChange={(e) => setFilters({ ...filters, officer: e.target.value })}
                    >
                      <option value="">All Officers</option>
                      {uniqueOfficers.map((officer, index) => (
                        <option key={index} value={officer}>
                          {officer}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-end">
                    <button
                      onClick={resetFilters}
                      className="w-full bg-gray-200 text-gray-800 px-4 py-2 rounded hover:bg-gray-300"
                    >
                      Reset Filters
                    </button>
                  </div>
                </div>

                {/* Enhanced Table */}
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Force Number
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        
                       
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Officer
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Station
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredForms.length > 0 ? (
                        filteredForms.map((card, i) => (
                          <tr key={i} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {card.formNumber}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {card.date}
                            </td>
                           
                           
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {card.officer}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {card.station}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs rounded-full ${
                                card.status === "Approved" ? "bg-green-100 text-green-800" :
                                card.status === "Rejected" ? "bg-red-100 text-red-800" :
                                "bg-yellow-100 text-yellow-800"
                              }`}>
                                {card.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <button
                                onClick={() => handleViewLedger(card)}
                                className="text-blue-600 hover:text-blue-900 mr-3"
                              >
                                View
                              </button>
                              <button className="text-gray-600 hover:text-gray-900">
                                <Printer size={16} />
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={8} className="px-6 py-4 text-center text-sm text-gray-500">
                            No clothing cards found matching your filters.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <div>
                <button
                  onClick={() => setShowLedger(false)}
                  className="flex items-center gap-2 mb-4 text-blue-600 hover:text-blue-800"
                >
                  <ArrowLeft size={16} />
                  Back to list
                </button>
                <Form57Pdf
                  formData={selectedCard || clothingCards[0]}
                  onBack={() => setShowLedger(false)}
                  onPrint={() => window.print()}
                />
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default ClothingCardsIssues;