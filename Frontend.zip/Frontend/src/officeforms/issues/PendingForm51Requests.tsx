import { Button } from "@/components/ui/button";
import Form163Pdf from "@/formPdfs/Form163Pdf";
import { Eye, Check, Ban, X, Filter, Download } from "lucide-react";
import { useState } from "react";

const PendingForm51Requests = () => {
  const [requests, setRequests] = useState([
    { 
      id: 1, 
      formNumber: "51/2025/001",
      requester: "ZRP Avondale", 
      item: "Cap STU", 
      quantity: 50, 
      date: "2025-05-05", 
      status: "Pending",
      officerInCharge: "Inspector Chikomo",
      justification: "New recruits onboarding"
    },
    { 
      id: 2, 
      formNumber: "51/2025/002",
      requester: "ZRP Mabvuku", 
      item: "Jersey Blue", 
      quantity: 30, 
      date: "2025-05-04", 
      status: "Processing",
      officerInCharge: "Sergeant Moyo",
      justification: "Uniform replacements"
    },
    { 
      id: 3, 
      formNumber: "51/2025/003",
      requester: "ZRP Hillside", 
      item: "Trousers Mat", 
      quantity: 40, 
      date: "2025-05-06", 
      status: "Pending",
      officerInCharge: "Inspector Makoni",
      justification: "Quarterly replenishment"
    }
  ]);

  const [openForm, setOpenForm] = useState(false);
  const [currentRequest, setCurrentRequest] = useState(null);

  const viewRequest = (request) => {
    setCurrentRequest(request);
    setOpenForm(true);
  };

  const handleApprove = (requestId) => {
    setRequests(prev =>
      prev.map(req =>
        req.id === requestId ? { ...req, status: "Approved" } : req
      )
    );
    setOpenForm(false);
  };

  const handleReject = (requestId) => {
    setRequests(prev =>
      prev.map(req =>
        req.id === requestId ? { ...req, status: "Rejected" } : req
      )
    );
    setOpenForm(false);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Pending Form 51 Requests</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Filter className="w-4 h-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Download className="w-4 h-4" />
            Export
          </Button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <Button
                variant="ghost"
                onClick={() => setOpenForm(false)}
                className="flex items-center gap-2 text-gray-600"
              >
                <X className="w-4 h-4" />
                Back to list
              </Button>
              {currentRequest?.status === "Pending" && (
                <div className="flex gap-3">
                  <Button
                    variant="destructive"
                    onClick={() => handleReject(currentRequest.id)}
                    className="flex items-center gap-2"
                  >
                    <Ban className="w-4 h-4" />
                    Reject Request
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => handleApprove(currentRequest.id)}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4" />
                    Approve Request
                  </Button>
                </div>
              )}
            </div>

            <div className="mt-4">
              <Form163Pdf
                formData={currentRequest}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Form #</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Requester</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {requests.map((form) => (
                <tr key={form.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {form.formNumber}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {form.date}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {form.requester}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {form.item}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {form.quantity}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        form.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : form.status === "Processing"
                          ? "bg-blue-100 text-blue-800"
                          : form.status === "Approved"
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {form.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewRequest(form)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                    {form.status === "Pending" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => handleApprove(form.id)}
                        >
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => handleReject(form.id)}
                        >
                          Reject
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default PendingForm51Requests;