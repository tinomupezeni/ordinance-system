import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  Bell,
  BookMarked,
  File,
  Home,
  Settings,
  Users,
  ClipboardList,
  LogOut,
} from "lucide-react";

type NavItemProps = {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  notificationCount?: number;
};

const NavItem = ({
  href,
  icon,
  label,
  active = false,
  notificationCount = 0,
}: NavItemProps) => (
  <Link
    to={href}
    className={cn(
      "flex items-center px-4 py-3 rounded-lg mb-1 relative transition-colors duration-200",
      active
        ? "bg-blue-50 text-blue-700 font-medium border-l-4 border-blue-600"
        : "text-gray-600 hover:bg-gray-50"
    )}
  >
    <span className={cn("mr-3", active ? "text-blue-600" : "text-gray-500")}>
      {icon}
    </span>
    <span className="flex-1">{label}</span>
    {notificationCount > 0 && (
      <span className="ml-2 flex items-center justify-center w-6 h-6 text-xs font-medium text-white bg-red-500 rounded-full">
        {notificationCount}
      </span>
    )}
  </Link>
);

const Sidebar = () => {
  const location = useLocation();
  const office = localStorage.getItem("office");

  const getOfficeSpecificNavItem = () => {
    const officeRoutes: Record<string, NavItemProps> = {
      "Officer in Charge": {
        href: "/all-forms-109",
        icon: <File size={18} />,
        label: "Endorsement Forms",
        active: location.pathname === "/all-forms-109",
      },
      "Receiving Bay": {
        href: "/all-forms-109",
        icon: <ClipboardList size={18} />,
        label: "All Form Records",
        active: location.pathname === "/all-forms-109",
      },
      "Bulk Officer": {
        href: "/main-ledger-bulk",
        icon: <File size={18} />,
        label: "Main Ledger Records",
        active: location.pathname === "/main-ledger-bulk",
      },
      "Dispatch Officer": {
        href: "/main-ledger-bulk",
        icon: <File size={18} />,
        label: "All Forms",
        active: location.pathname === "/main-ledger-bulk",
      },
      "Issues Officer": {
        href: "/issues/clothing-card",
        icon: <File size={18} />,
        label: "Clothing Cards",
        active: location.pathname === "/issues/clothing-card",
      },
    };

    return (
      officeRoutes[office as string] || {
        href: "/forms",
        icon: <File size={18} />,
        label: "Forms",
        active: location.pathname === "/forms",
      }
    );
  };

  return (
    <aside className="w-64 bg-white border-r border-gray-200 p-4 hidden md:block h-[calc(100vh-56px)] fixed mt-14 z-40">
      <div>
        <div className="space-y-2">
          <NavItem
            href="/dashboard"
            icon={<Home size={18} />}
            label="Dashboard"
            active={location.pathname === "/dashboard"}
          />

          {(office !== "Bulk Officer" && office !== 'Receiving Bay' && office !== 'Issues Officer' && office !== 'Dispatch Officer') && (
            <NavItem
              href="/notifications"
              icon={<Bell size={18} />}
              label="Notifications"
              active={location.pathname === "/notifications"}
              notificationCount={2}
            />
          )}

          <NavItem {...getOfficeSpecificNavItem()} />
        </div>

        <div className="bottom-0">
          <div className="border-t border-gray-200 pt-2 mt-4">
            <NavItem
              href="/settings"
              icon={<Settings size={18} />}
              label="Settings"
              active={location.pathname === "/settings"}
            />
          </div>
          <div className="">
            <NavItem
              href="/login"
              icon={<LogOut size={18} />}
              label="Logout"
              // active={location.pathname === "/logout"}
            />
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
