import { Link } from "react-router-dom";
import logo from "../assets/zrp-logo.png";
import { LogOut, User } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const office = localStorage.getItem("office");

  const renderDashboardContent = (office: string | null) => {
    const officeTitles: Record<string, string> = {
      "Issues Officer": "Issues Officer",
      "Carding Officer": "Carding Officer",
      "Dispatch Officer": "Dispatch Officer",
      "Loans Officer": "Loans Officer",
      "Discharge Officer": "Discharge Officer",
      "Officer in Charge": "Officer in Charge",
      "Receiving Bay": "Receiving Bay Officer",
      "Bulk Officer": "Officer in Charge Bulk",
      "Kardex Officer": "Officer in Charge Kardex",
      "Stores Officer": "Officer in Charge Stores"
    };

    return (
      <span className="text-sm text-gray-600 font-medium mr-4">
        {officeTitles[office as string] || "Office Unknown"}
      </span>
    );
  };

  const handleLogout = () => {
    // Consider adding logout logic here (clear localStorage, etc.)
    navigate("/");
  };

  return (
    <header className="bg-white shadow-sm px-6 py-3 border-b border-gray-200 flex items-center justify-between fixed w-full z-50">
      <div className="flex items-center space-x-8">
        <Link to="/" className="flex items-center space-x-2">
          <div className="w-8 h-8">
            <img
              src={logo}
              alt="ZRP ABIS"
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="font-bold text-xl text-blue-950">ZRP</h1>
        </Link>

        <div className="hidden md:block text-lg font-semibold text-yellow-600 bg-blue-950/10 px-4 py-1 rounded-full">
          ORDNANCE MANAGEMENT SYSTEM
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex items-center bg-gray-50 rounded-full px-4 py-1">
          {renderDashboardContent(office)}
          <div className="w-8 h-8 bg-blue-900 rounded-full flex items-center justify-center text-white">
            <User size={16} />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;