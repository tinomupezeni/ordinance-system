
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type InventoryCardProps = {
  title: string;
  count: number;
  color: "green" | "yellow" | "blue" | "red";
  lastUpdated: string;
  icon: string;
};

const InventoryCard = ({
  title,
  count,
  color = "green",
  lastUpdated,
  icon,
}: InventoryCardProps) => {
  const getIconBasedOnType = () => {
    switch (icon) {
      case "pants":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 2v20M18 2v20M6 7.01h12" />
            <path d="m11 2-5 17M13 2l5 17" />
          </svg>
        );
      case "jacket":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14.5 22H18a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-7.5" />
            <path d="M9 16v-5.5C9 8.5 9.5 6 12 6h0" />
            <path d="M6 16v-5.5C6 8.5 6.5 6 9 6h0" />
            <path d="M9.5 22H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h7.5" />
          </svg>
        );
      case "cap":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 9c0 1 .6 1.1 1 1.5h14c.4-.4 1-.5 1-1.5a5 5 0 0 0-10 0Z" />
            <path d="M14.5 13.5h.5" />
            <path d="M9 13.5h.5" />
            <path d="M16 13.5V18a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-4.5" />
            <path d="M5 13.5V18a2 2 0 0 0 2 2h3" />
            <path d="M19 13.5V18a2 2 0 0 1-2 2h-3" />
          </svg>
        );
      case "shirt":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z" />
          </svg>
        );
      case "jersey":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z" />
            <path d="M10 3h4" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
            <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
          </svg>
        );
    }
  };

  const getStatusColor = () => {
    switch (color) {
      case "green":
        return "bg-green-500";
      case "yellow":
        return "bg-yellow-500";
      case "blue":
        return "bg-blue-500";
      case "red":
        return "bg-red-500";
      default:
        return "bg-green-500";
    }
  };

  return (
    <Card className="bg-white hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className={cn("p-2 rounded-full", getStatusColor())}>
            <div className="text-white">{getIconBasedOnType()}</div>
          </div>
          <div className="flex items-center justify-center w-20 h-20 rounded-full border-[5px] border-blue-900">
            <span className="text-blue-900 font-bold text-xl">{count}</span>
          </div>
        </div>
        
        <div>
          <h3 className="font-semibold">{title}</h3>
          <p className="text-xs text-gray-500">Last {lastUpdated}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default InventoryCard;
