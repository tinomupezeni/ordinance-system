import { cn } from "@/lib/utils";
import { Button } from "./ui/button";
import { useEffect, useState } from "react";

interface SummaryCardProps {
  title: string;
  count: number;
  color?: string;
  icon?: React.ReactNode;
  forms?: string;
  notify?: number;
  onViewAll?: () => void;
}

const SummaryCard = ({
  title,
  count,
  color = "bg-gray-100 text-gray-900 border border-gray-300",
  icon,
  forms,
  notify = 0,
  onViewAll,
}: SummaryCardProps) => {
  return (
    <div
      className={cn(
        "p-4 rounded-lg shadow-lg flex items-center justify-between gap-4 min-h-[100px] relative overflow-hidden",
        color,
        // {
        //   "ring-2 ring-offset-2 ring-red-500": notify > 0,
        // }
      )}
    >
      {/* Continuous pulsing background effect */}
      {/* {notify > 0 && (
        <div className="absolute inset-0 bg-red-100 bg-opacity-30 animate-pulse rounded-lg" />
      )} */}

      <div className="flex items-center z-10">
        {icon && <div className="text-4xl">{icon}</div>}
        <div className="p-5">
          <h2 className="text-sm font-medium uppercase tracking-wide text-gray-600">
            {title}
          </h2>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-semibold">{count}</p>
            {/* {notify > 0 && (
              <span className="relative flex items-center">
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="ml-2 text-xs font-medium text-red-600">
                  {notify} in processing
                </span>
              </span>
            )} */}
          </div>
        </div>
      </div>
      <Button onClick={onViewAll} className="z-10">
        View All
      </Button>
    </div>
  );
};

export default SummaryCard;