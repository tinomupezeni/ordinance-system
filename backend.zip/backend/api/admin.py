from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(RequisitionItem)
admin.site.register(ReplacementItem)

admin.site.register(RejectionCertificate)
admin.site.register(DischargeCertificate)
admin.site.register(ExchangeVoucher)

# -------------------------------
admin.site.register(Form321)
admin.site.register(EquipmentItem)
admin.site.register(PersonInvolved)
# -------------------------------

admin.site.register(Form163)
admin.site.register(RequisitionForm)
admin.site.register(Userprofile)
admin.site.register(ExchangeItem)
admin.site.register(FormSignature)
admin.site.register(Book2IssueVoucher)
# admin.site.register(IssueItem)
admin.site.register(Form109ReceiptItem)
admin.site.register(Form109)



# Register your models here
admin.site.register(Officer)
admin.site.register(Issuance)
admin.site.register(IssuedItem)
admin.site.register(ClothingItem)
admin.site.register(ClothingCategory) # If you want to manage categories too



