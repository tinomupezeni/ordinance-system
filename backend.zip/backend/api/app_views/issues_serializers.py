from rest_framework import serializers
from ..models import (
    Issuance,
    RequisitionForm, 
    Book2IssueVoucher, 
    Form163, 
    Form321,
    Form109,
    ExchangeVoucher,
    RejectionCertificate,
    DischargeCertificate,
    RequisitionItem,
    EquipmentItem,
    PersonInvolved,
    RequisitionItem163,
    IssueItem,
    ExchangeItem,
    RejectedItem
)

class RequisitionItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = RequisitionItem
        fields = '__all__'

class RequisitionFormSerializer(serializers.ModelSerializer):
    items = RequisitionItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = RequisitionForm
        fields = '__all__'

class IssueItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = IssueItem
        fields = '__all__'

class Book2IssueVoucherSerializer(serializers.ModelSerializer):
    items = IssueItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = Book2IssueVoucher
        fields = '__all__'

class RequisitionItem163Serializer(serializers.ModelSerializer):
    class Meta:
        model = RequisitionItem163
        fields = '__all__'

class Form163Serializer(serializers.ModelSerializer):
    items = RequisitionItem163Serializer(many=True, read_only=True)
    
    class Meta:
        model = Form163
        fields = '__all__'

class EquipmentItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentItem
        fields = '__all__'

class PersonInvolvedSerializer(serializers.ModelSerializer):
    class Meta:
        model = PersonInvolved
        fields = '__all__'

class Form321Serializer(serializers.ModelSerializer):
    equipment_items = EquipmentItemSerializer(many=True, read_only=True)
    persons_involved = PersonInvolvedSerializer(many=True, read_only=True)
    
    class Meta:
        model = Form321
        fields = '__all__'

class Form109Serializer(serializers.ModelSerializer):
    class Meta:
        model = Form109
        fields = '__all__'

class ExchangeItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExchangeItem
        fields = '__all__'

class ExchangeVoucherSerializer(serializers.ModelSerializer):
    items = ExchangeItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = ExchangeVoucher
        fields = '__all__'

class RejectedItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = RejectedItem
        fields = '__all__'

class RejectionCertificateSerializer(serializers.ModelSerializer):
    items = RejectedItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = RejectionCertificate
        fields = '__all__'

class DischargeCertificateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DischargeCertificate
        fields = '__all__'
        
class IssuanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Issuance
        fields = '__all__'