# ------------------------------------
# form 109
# ------------------------------------

# views.py
from rest_framework import generics, status
from rest_framework.response import Response
from ..models import Form109
from ..serializers import Form109Serializer
from rest_framework.permissions import IsAuthenticated

class Form109ListCreateView(generics.ListCreateAPIView):
    queryset = Form109.objects.all().prefetch_related('items').order_by('-created_at')
    serializer_class = Form109Serializer
    permission_classes = [IsAuthenticated]
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class Form109RetrieveView(generics.RetrieveAPIView):
    queryset = Form109.objects.all().prefetch_related('items')
    serializer_class = Form109Serializer
    permission_classes = [IsAuthenticated]
    lookup_field = 'id'