from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from ..serializers import Form163Serializer
from ..app_serializers.form163serializer import Form163ApprovalSerializer
from ..models import Form163, Form163ApprovalStatus, RequisitionForm
from rest_framework import generics, permissions, status

class ApproveRequisitionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            requisition = RequisitionForm.objects.get(pk=pk)
            requisition.office_in_charge_status = 'approved'
            requisition.save()
            return Response(
                {"success": True, "message": "Requisition approved."},
                status=status.HTTP_200_OK
            )
        except RequisitionForm.DoesNotExist:
            return Response(
                {"success": False, "message": "Requisition not found."},
                status=status.HTTP_404_NOT_FOUND
            )



from rest_framework.views import APIView
from django.shortcuts import get_object_or_404 # Helper to get object or raise 404

class ApproveForm163APIView(APIView):
    """
    API view to approve a specific Form163 instance using APIView pattern.
    """
    permission_classes = [permissions.IsAuthenticated] # Or specific approver roles

    def patch(self, request, pk):
        try:
            form_163 = get_object_or_404(Form163, pk=pk)
        except Exception: # Catch any other potential errors from get_object_or_404
             return Response(
                {"success": False, "message": "Form 163 not found."},
                status=status.HTTP_404_NOT_FOUND
            )


        if form_163.officer_in_charge_approved != Form163ApprovalStatus.WAITING:
            return Response(
                {"success": False, "message": f"Form is already '{form_163.officer_in_charge_approved}'. Cannot approve."},
                status=status.HTTP_400_BAD_REQUEST
            )

        form_163.officer_in_charge_approved = Form163ApprovalStatus.APPROVED
        form_163.approved_by = request.user
        # form_163.approved_at = timezone.now()
        form_163.rejection_reason = None # Clear any previous rejection reason

        form_163.save()

        return Response(
            {"success": True, "message": f"Form 163 {form_163.pk} approved successfully."},
            status=status.HTTP_200_OK
        )




# In api/views.py
from rest_framework import generics, status, permissions
from rest_framework.response import Response
from django.utils import timezone # Don't forget to import timezone

from ..models import Form163, Form163ApprovalStatus # Assuming Form163ApprovalStatus is an Enum or similar
from ..app_serializers.form163serializer import Form163RejectInputSerializer # Import the new serializer

class RejectForm163View(generics.UpdateAPIView):
    """
    API view to reject a specific Form163 instance.
    Sets status to 'REJECTED', records the rejection reason, and approval details.
    """
    queryset = Form163.objects.all()
    serializer_class = Form163RejectInputSerializer # Use the specific serializer for rejection reason
    lookup_field = 'pk' # Or 'id', based on your URL configuration
    permission_classes = [permissions.IsAuthenticated] # Adjust as per your security model (e.g., IsAdminUser)

    def update(self, request, *args, **kwargs):
        try:
            instance = self.get_object() # Get the Form163 instance by pk
        except Form163.DoesNotExist:
            return Response(
                {"success": False, "message": "Form 163 not found."},
                status=status.HTTP_404_NOT_FOUND
            )

        # Ensure the form is in 'WAITING' status before rejecting
        if instance.officer_in_charge_approved != Form163ApprovalStatus.WAITING:
            return Response(
                {"success": False, "message": f"Form is already '{instance.officer_in_charge_approved}'. Cannot reject."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate the incoming data for rejection reason
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        rejection_reason = serializer.validated_data.get('rejection_reason')

        if not rejection_reason: # Double-check, though serializer should handle required=True
             return Response(
                {"success": False, "message": "Rejection reason cannot be empty."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Set rejection details
        instance.officer_in_charge_approved = Form163ApprovalStatus.REJECTED
        instance.rejection_reason = rejection_reason
        instance.approved_by = request.user # The user performing the action (rejection)
        instance.approved_at = timezone.now() # Record the time of rejection

        instance.save()

        # Return a simple success response
        return Response(
            {"success": True, "message": f"Form 163 {instance.pk} rejected successfully."},
            status=status.HTTP_200_OK
        )


class CardingApproveRequisitionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            requisition = RequisitionForm.objects.get(pk=pk)
            requisition.carding_status = 'approved'
            requisition.save()
            return Response(
                {"success": True, "message": "Requisition approved."},
                status=status.HTTP_200_OK
            )
        except RequisitionForm.DoesNotExist:
            return Response(
                {"success": False, "message": "Requisition not found."},
                status=status.HTTP_404_NOT_FOUND
            )


class RejectRequisitionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            requisition = RequisitionForm.objects.get(pk=pk)
            requisition.office_in_charge_status = 'rejected'
            requisition.save()
            return Response(
                {"success": True, "message": "Requisition rejected."},
                status=status.HTTP_200_OK
            )
        except RequisitionForm.DoesNotExist:
            return Response(
                {"success": False, "message": "Requisition not found."},
                status=status.HTTP_404_NOT_FOUND
            )