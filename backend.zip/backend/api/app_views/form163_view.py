from rest_framework import generics, permissions, status
from rest_framework.response import Response
from django.utils import timezone

from ..app_serializers.form163serializer import Form163ApprovalSerializer

# from ..models import FormSignature, RequisitionItem163 # Import timezone
from ..models import Form163, Form163ApprovalStatus
from ..serializers import Form163Serializer
# Make sure your Form163CreateView is also updated to use the new serializer structure if needed


class Form163WaitingListView(generics.ListAPIView):
    """
    API view to list all Form163 instances that are in 'WAITING' approval status.
    """
    queryset = Form163.objects.filter(officer_in_charge_approved=Form163ApprovalStatus.WAITING)
    serializer_class = Form163Serializer
    permission_classes = [permissions.IsAuthenticated]

class Form163AllListView(generics.ListAPIView):
    """
    API view to list all Form163 instances that are in 'WAITING' approval status.
    """
    queryset = Form163.objects.all().order_by('-created_at')  # Order by creation date
    serializer_class = Form163Serializer
    permission_classes = [permissions.IsAuthenticated] 

class Form163ApproveRejectView(generics.UpdateAPIView):
    """
    API view to update the approval status of a specific Form163 instance.
    Allows changing status to 'APPROVED' or 'REJECTED'.
    """
    queryset = Form163.objects.all()
    serializer_class = Form163ApprovalSerializer # Use the specific approval serializer
    lookup_field = 'pk' # Or 'id', based on your URL configuration
    permission_classes = [permissions.IsAuthenticated] # Or restrict to specific approver roles

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)

        new_status = serializer.validated_data.get('status')
        rejection_reason = serializer.validated_data.get('rejection_reason', None)

        if instance.officer_in_charge_approved != Form163ApprovalStatus.WAITING:
            return Response(
                {"detail": f"Form is already '{instance.officer_in_charge_approved}'. Cannot change status."},
                status=status.HTTP_400_BAD_REQUEST
            )

        instance.officer_in_charge_approved = new_status
        instance.approved_by = request.user
        instance.approved_at = timezone.now() # Record the time of approval/rejection

        if new_status == Form163ApprovalStatus.REJECTED:
            instance.rejection_reason = rejection_reason
        else:
            instance.rejection_reason = None # Clear rejection reason if approved

        instance.save()

        # Return the full Form163 representation
        full_serializer = Form163Serializer(instance)
        return Response(full_serializer.data, status=status.HTTP_200_OK)

