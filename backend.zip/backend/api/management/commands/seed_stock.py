# your_app_name/management/commands/seed_stock.py

import random
from django.core.management.base import BaseCommand
from django.db import transaction
from ...models import ClothingItem, Stock # Adjust 'your_app_name'

class Command(BaseCommand):
    help = 'Seeds random quantities for each ClothingItem into the Stock model.'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Starting stock seeding process...'))

        clothing_items = ClothingItem.objects.all()
        if not clothing_items.exists():
            self.stdout.write(self.style.WARNING('No ClothingItems found in the database. Please add some first.'))
            return

        # Define a default location for initial stock.
        # In a real system, you might loop through multiple locations.
        default_location = 'Main Store'

        with transaction.atomic(): # Use a transaction for atomic operations
            for item in clothing_items:
                # Check if a Stock record for this item and default_location already exists
                stock_record, created = Stock.objects.get_or_create(
                    clothing_item=item,
                    location=default_location,
                    defaults={'quantity': 0} # Set a default quantity if creating
                )

                # Assign a new random quantity if the record was just created or if you want to update existing ones
                # If you only want to add stock if it doesn't exist, remove the next line and just use defaults
                random_quantity = random.randint(100, 500)
                stock_record.quantity = random_quantity
                stock_record.save()

                if created:
                    self.stdout.write(self.style.SUCCESS(
                        f'Created Stock for "{item.name}" at "{default_location}" with quantity: {random_quantity}'
                    ))
                else:
                    self.stdout.write(self.style.WARNING(
                        f'Updated Stock for "{item.name}" at "{default_location}" to quantity: {random_quantity}'
                    ))

        self.stdout.write(self.style.SUCCESS('Stock seeding process completed successfully!'))