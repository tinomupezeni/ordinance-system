from .app_views.issues_serializers import RequisitionItem163Serializer
from .models import *
from rest_framework import serializers



class UserProfileSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(source='user.id', read_only=True)
    name = serializers.CharField(source='user.get_full_name')
    
    
   

    class Meta:
        model = Userprofile
        fields = ['id', 'name',  'rank', 'last_active','office']
        read_only_fields = ['id', 'name', 'rank', 'last_active','office']


from rest_framework import serializers
from .models import RequisitionForm, RequisitionItem, ReplacementItem

class RequisitionItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = RequisitionItem
        fields = '__all__'

class ReplacementItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReplacementItem
        fields = '__all__'

class RequisitionFormSerializer(serializers.ModelSerializer):
    items = RequisitionItemSerializer(many=True, read_only=True)
    replacement_items = ReplacementItemSerializer(many=True, read_only=True)
    created_by = serializers.StringRelatedField()
    
    class Meta:
        model = RequisitionForm
        fields = '__all__'
        read_only_fields = ('created_by', 'created_at', 'updated_at')
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Format the data to match the frontend structure
        representation['collectedBy'] = {
            'no': representation.pop('collected_by_no'),
            'rank': representation.pop('collected_by_rank'),
            'name': representation.pop('collected_by_name'),
        }
        
        representation['officerRecommendation'] = {
            'at': representation.pop('officer_recommendation_at'),
            'rank': representation.pop('officer_recommendation_rank'),
            'expenseType': representation.pop('officer_recommendation_expense_type'),
        }
        
        representation['checkedByOfficer'] = {
            'no': representation.pop('checked_by_officer_no'),
            'rank': representation.pop('checked_by_officer_rank'),
        }
        
        representation['checkedByQuartermaster'] = {
            'no': representation.pop('checked_by_quartermaster_no'),
            'rank': representation.pop('checked_by_quartermaster_rank'),
        }
        
        representation['voucherCheckedBy'] = {
            'initials': representation.pop('voucher_checked_by_initials'),
            'date': representation.pop('voucher_checked_by_date'),
        }
        
        representation['itemsSelectedBy'] = {
            'initials': representation.pop('items_selected_by_initials'),
            'date': representation.pop('items_selected_by_date'),
        }
        
        representation['itemsPackedBy'] = {
            'initials': representation.pop('items_packed_by_initials'),
            'date': representation.pop('items_packed_by_date'),
        }
        
        representation['enteredOnClothingCard'] = {
            'initials': representation.pop('entered_on_clothing_card_initials'),
            'date': representation.pop('entered_on_clothing_card_date'),
        }
        
        representation['ledgerActioned'] = {
            'initials': representation.pop('ledger_actioned_initials'),
            'date': representation.pop('ledger_actioned_date'),
        }
        
        representation['dispatchMethodDetails'] = {
            'collected': representation.pop('dispatch_collected'),
            'rail': representation.pop('dispatch_rail'),
            'road': representation.pop('dispatch_road'),
            'air': representation.pop('dispatch_air'),
            'registeredMail': representation.pop('dispatch_registered_mail'),
            'parcelPost': representation.pop('dispatch_parcel_post'),
            'parcelWarrantNo': representation.pop('dispatch_parcel_warrant_no'),
        }
        
        return representation
    
    # -------------------------
    # Form321
    # -------------------------
    
from rest_framework import serializers
from .models import Form321, EquipmentItem, PersonInvolved

class EquipmentItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentItem
        fields = ['id', 'description', 'number', 'value']

class PersonInvolvedSerializer(serializers.ModelSerializer):
    class Meta:
        model = PersonInvolved
        fields = ['id', 'no', 'rank', 'name', 'home_station']

class Form321Serializer(serializers.ModelSerializer):
    equipment_items = EquipmentItemSerializer(many=True, read_only=True)
    persons_involved = PersonInvolvedSerializer(many=True, read_only=True)
    created_by = serializers.StringRelatedField()
    
    class Meta:
        model = Form321
        fields = '__all__'
        read_only_fields = ('created_by', 'created_at', 'updated_at')
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Format the data to match the frontend structure
        representation['reportNo'] = representation.pop('report_no')
        representation['dateOfIssue'] = representation.pop('date_of_issue')
        representation['dateOfLoss'] = representation.pop('date_of_loss')
        representation['agreeToRefund'] = representation.pop('agree_to_refund')
        representation['officerComment'] = representation.pop('officer_comment')
        representation['awaitDate'] = representation.pop('await_date')
        representation['governmentPayAmount'] = representation.pop('government_pay_amount')
        representation['depreciatedValue'] = representation.pop('depreciated_value')
        representation['governmentPayPercentage'] = representation.pop('government_pay_percentage')
        representation['memberPayPercentage'] = representation.pop('member_pay_percentage')
        representation['boardOfEnquiryReceived'] = representation.pop('board_of_enquiry_received')
        representation['homeAffairsAdvised'] = representation.pop('home_affairs_advised')
        representation['equipmentRecovered'] = representation.pop('equipment_recovered')
        
        # Rename related fields to match frontend
        representation['equipmentItems'] = representation.pop('equipment_items')
        representation['persons'] = representation.pop('persons_involved')
        
        # Convert persons_involved to match frontend structure
        for person in representation['persons']:
            person['homeStation'] = person.pop('home_station')
        
        return representation

# -------------------------
# Form 163
# -------------------------

from rest_framework import serializers
from .models import Form163, RequisitionItem, FormSignature

from rest_framework import serializers
from .models import Form163, RequisitionItem163, FormSignature # Ensure all models are imported, especially RequisitionItem163

# Assuming you have a FormSignatureSerializer
class FormSignatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormSignature
        fields = '__all__' # Or specify individual fields if you prefer
        # You might want to exclude 'form' field from this serializer
        # fields = [
        #     'requested_by_initials', 'requested_by_date',
        #     'issued_by_initials', 'issued_by_date',
        #     'received_by_initials', 'received_by_date',
        #     'ledger_actioned_by_initials', 'ledger_actioned_by_date'
        # ]

# Ensure this serializer points to RequisitionItem163
class RequisitionItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = RequisitionItem163
        fields = ['description', 'size', 'no_regd', 'no_issued'] # Be explicit with fields


# In api/serializers.py
# In api/serializers.py

class Form163Serializer(serializers.ModelSerializer):
    items = RequisitionItem163Serializer(many=True, read_only=True)
    formsignature = FormSignatureSerializer(read_only=True) # THIS IS CORRECT NOW

    created_by = serializers.StringRelatedField() # Assuming created_by is a User model and you want its string representation

    class Meta:
        model = Form163
        fields = '__all__'
        read_only_fields = ('created_by', 'created_at', 'updated_at')

    def to_representation(self, instance):
        representation = super().to_representation(instance)


        # Format items (as before)
        representation['items'] = representation.pop('items', [])
        for item in representation['items']:
            item['noRegd'] = item.pop('no_regd')
            item['noIssued'] = item.pop('no_issued')
            # You might also want to remove 'form' if it's not needed on the frontend
            item.pop('form', None) # Safely remove 'form' field from item representation
            item.pop('id', None) # If you don't need item IDs on frontend for display

        # Handle signatures: CRITICAL CHANGE HERE
        # Get the formsignature data. If it's None, use an empty dictionary.
        signatures_data = representation.pop('formsignature', None)
        if signatures_data is None:
            signatures_data = {} # If no signature exists, default to empty dict

        print(f"DEBUG_SERIALIZER: Signatures data after handling None: {signatures_data}")


        # Assign formatted signature fields
        # Note: I'm using .get(key, None) here, which correctly returns None if key is not present.
        # This is suitable for your frontend where you might expect `null` for missing initials/dates.
        representation['requestedBy'] = {
            'initials': signatures_data.get('requested_by_initials', None),
            'date': signatures_data.get('requested_by_date', None),
        }
        representation['issuedBy'] = {
            'initials': signatures_data.get('issued_by_initials', None),
            'date': signatures_data.get('issued_by_date', None),
        }
        representation['receivedBy'] = {
            'initials': signatures_data.get('received_by_initials', None),
            'date': signatures_data.get('received_by_date', None),
        }
        # Corrected typo for ledger_actioned_by (assuming the model field is 'ledger_actioned_by_initials')
        representation['ledgerActionedBy'] = {
            'initials': signatures_data.get('ledger_actioned_by_initials', None),
            'date': signatures_data.get('ledger_actioned_by_date', None),
        }

        # DEBUG PRINTS - Keep for a moment, then remove for production
        print(f"DEBUG_SERIALIZER: Final representation: {representation}")
        # END DEBUG PRINTS

        return representation
# Rejection Certificate
# --------------------------

from rest_framework import serializers
from .models import RejectionCertificate, RejectedItem

class RejectedItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = RejectedItem
        fields = ['id', 'item', 'quantity', 'delivery_note', 'order_no', 'rejected', 'accepted', 'value']

class RejectionCertificateSerializer(serializers.ModelSerializer):
    items = RejectedItemSerializer(many=True, read_only=True)
    created_by = serializers.StringRelatedField()
    
    class Meta:
        model = RejectionCertificate
        fields = '__all__'
        read_only_fields = ('created_by', 'created_at', 'updated_at')
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Format the data to match the frontend structure
        representation['entryNo'] = representation.pop('entry_no')
        representation['certificateNo'] = representation.pop('certificate_no')
        
        # Inspector Info
        representation['inspectorInfo'] = {
            'number': representation.pop('inspector_number'),
            'rank': representation.pop('inspector_rank'),
            'name': representation.pop('inspector_name'),
        }
        
        # Rejection Details
        representation['rejectionReason'] = representation.pop('rejection_reason')
        representation['allAccepted'] = representation.pop('all_accepted')
        representation['allRejected'] = representation.pop('all_rejected')
        
        # Qualification
        representation['yearsServed'] = representation.pop('years_served')
        
        # Witness Info
        representation['witnessInfo'] = {
            'fNumber': representation.pop('witness_f_number'),
            'rank': representation.pop('witness_rank'),
            'name': representation.pop('witness_name'),
            'officeHeld': representation.pop('witness_office_held'),
        }
        
        # Rename items fields to match frontend
        for item in representation['items']:
            item['qty'] = item.pop('quantity')
            item['dNote'] = item.pop('delivery_note')
            item['orderNo'] = item.pop('order_no')
        
        return representation
    
    # --------------------------
    # Book 2
    # --------------------------

from rest_framework import serializers
from .models import Book2IssueVoucher, IssueItem

class IssueItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = IssueItem
        fields = ['id', 'description', 'quantity', 'remarks']

class Book2IssueVoucherSerializer(serializers.ModelSerializer):
    items = IssueItemSerializer(many=True, read_only=True)
    created_by = serializers.StringRelatedField()
    
    class Meta:
        model = Book2IssueVoucher
        fields = '__all__'
        read_only_fields = ('created_by', 'created_at', 'updated_at')
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Format the data to match the frontend structure
        representation['issuedBy'] = representation.pop('issued_by')
        representation['issuedTo'] = representation.pop('issued_to')
        representation['dispatchMethod'] = representation.pop('dispatch_method')
        
        # Recipient Information
        representation['receivedBy'] = representation.pop('received_by_signature')
        representation['receivedDate'] = representation.pop('received_date')
        representation['recipientNo'] = representation.pop('recipient_no')
        representation['recipientRank'] = representation.pop('recipient_rank')
        representation['recipientName'] = representation.pop('recipient_name')
        representation['recipientStation'] = representation.pop('recipient_station')
        
        # Certification
        representation['certifiedBy'] = representation.pop('certified_by')
        representation['certifiedDate'] = representation.pop('certified_date')
        
        # Voucher Numbers
        representation['ivNo'] = representation.pop('iv_no')
        representation['ivDate'] = representation.pop('iv_date')
        representation['reqnNo'] = representation.pop('reqn_no')
        representation['reqnDate'] = representation.pop('reqn_date')
        
        return representation
# --------------------------
# Exchange Voucher
# --------------------------

from rest_framework import serializers
from .models import ExchangeVoucher, ExchangeItem

class ExchangeItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExchangeItem
        fields = [
            'id', 
            'returned_description', 
            'returned_size', 
            'returned_no',
            'issued_description',
            'issued_size',
            'issued_no'
        ]

class ExchangeVoucherSerializer(serializers.ModelSerializer):
    items = ExchangeItemSerializer(many=True, read_only=True)
    created_by = serializers.StringRelatedField()
    
    class Meta:
        model = ExchangeVoucher
        fields = '__all__'
        read_only_fields = ( 'created_by','created_at', 'updated_at')
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Format the data to match frontend structure
        representation['returnedBy'] = {
            'initials': representation.pop('returned_by_initials'),
            'date': representation.pop('returned_by_date'),
        }
        
        representation['ledgerActionedBy'] = {
            'initials': representation.pop('ledger_actioned_by_initials'),
            'date': representation.pop('ledger_actioned_by_date'),
        }
        
        # Convert snake_case to camelCase for items
        for item in representation['items']:
            item['returnedDescription'] = item.pop('returned_description')
            item['returnedSize'] = item.pop('returned_size')
            item['returnedNo'] = item.pop('returned_no')
            item['issuedDescription'] = item.pop('issued_description')
            item['issuedSize'] = item.pop('issued_size')
            item['issuedNo'] = item.pop('issued_no')
        
        return representation    
    # --------------------------
    # 
    # --------------------------

from rest_framework import serializers
from .models import DischargeCertificate

class DischargeCertificateSerializer(serializers.ModelSerializer):
    created_by = serializers.StringRelatedField()
    
    class Meta:
        model = DischargeCertificate
        fields = '__all__'
        read_only_fields = ('created_by', 'created_at', 'updated_at')
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Format the data to match the frontend structure
        representation['memberInfo'] = {
            'no': representation.pop('member_no'),
            'rank': representation.pop('member_rank'),
            'name': representation.pop('member_name'),
            'station': representation.pop('member_station'),
        }
        
        representation['dischargeInfo'] = {
            'reasons': representation.pop('discharge_reasons'),
            'date': representation.pop('discharge_date'),
        }
        
        representation['repaymentInfo'] = {
            'icDate': representation.pop('repayment_ic_date'),
            'iv': representation.pop('repayment_iv'),
            'ivDate': representation.pop('repayment_iv_date'),
            'acvConfirmed': representation.pop('repayment_acv_confirmed'),
            'total': representation.pop('repayment_total'),
            'noOutstanding': representation.pop('repayment_no_outstanding'),
        }
        
        representation['kitDeficiencies'] = {
            'articlesListed': representation.pop('kit_articles_listed'),
            'date': representation.pop('kit_date'),
            'sum': representation.pop('kit_sum'),
            'noDeficiencies': representation.pop('kit_no_deficiencies'),
        }
        
        representation['summary'] = {
            'kitRepayment': representation.pop('summary_kit_repayment'),
            'deficiencies': representation.pop('summary_deficiencies'),
        }
        
        return representation
    
# --------------------------
# form 109
# --------------------------
# serializers.py
from rest_framework import serializers
from .models import Form109, Form109ReceiptItem

class Form109ReceiptItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = Form109ReceiptItem
        fields = '__all__'

class Form109Serializer(serializers.ModelSerializer):
    # Map camelCase fields to snake_case model fields
    gcsReqnNo = serializers.CharField(source='gcs_reqn_no', required=False)
    supplierRefNo = serializers.CharField(source='supplier_ref_no', required=False)
    
    items = Form109ReceiptItemSerializer(many=True)

    class Meta:
        model = Form109
        fields = '__all__'
        extra_kwargs = {
            'gcs_reqn_no': {'write_only': True},
            'supplier_ref_no': {'write_only': True}
        }

    def create(self, validated_data):
        items_data = validated_data.pop('items', [])
        
        # Handle the camelCase fields
        if 'gcs_reqn_no' not in validated_data and 'gcsReqnNo' in validated_data:
            validated_data['gcs_reqn_no'] = validated_data.pop('gcsReqnNo')
        if 'supplier_ref_no' not in validated_data and 'supplierRefNo' in validated_data:
            validated_data['supplier_ref_no'] = validated_data.pop('supplierRefNo')
        
        form = Form109.objects.create(**validated_data)
        
        # Process items
        for item_data in items_data:
            item_id = item_data.get('id')
            if item_id:
                # Update existing item
                item = Form109ReceiptItem.objects.get(id=item_id)
                for attr, value in item_data.items():
                    setattr(item, attr, value)
                item.save()
            else:
                # Create new item
                item = Form109ReceiptItem.objects.create(**item_data)
            form.items.add(item)
            
        return form

# from .models import Form226, RequisitionItem, ReplacementItem

# class RequisitionItemSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = RequisitionItem
#         fields = '__all__'
#         read_only_fields = ('id', 'form')

# class ReplacementItemSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ReplacementItem
#         fields = '__all__'
#         read_only_fields = ('id', 'form')

# class Form226Serializer(serializers.ModelSerializer):
#     items = RequisitionItemSerializer(many=True)
#     replacement_items = ReplacementItemSerializer(many=True)
    
#     class Meta:
#         model = Form226
#         fields = '__all__'
    
#     def create(self, validated_data):
#         items_data = validated_data.pop('items')
#         replacement_items_data = validated_data.pop('replacement_items')
        
#         form = Form226.objects.create(**validated_data)
        
#         for item_data in items_data:
#             RequisitionItem.objects.create(form=form, **item_data)
            
#         for replacement_item_data in replacement_items_data:
#             ReplacementItem.objects.create(form=form, **replacement_item_data)
            
#         return form


# from .models import ClothingItem, IssuedClothing

# class ClothingItemSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ClothingItem
#         fields = ['id', 'name', 'lifespan_months']

# class IssuedClothingSerializer(serializers.ModelSerializer):
#     next_eligible_date = serializers.SerializerMethodField()
#     clothing_item_name = serializers.CharField(source='clothing_item.name', read_only=True)

#     class Meta:
#         model = IssuedClothing
#         fields = ['id', 'user_profile', 'clothing_item', 'clothing_item_name', 'date_issued', 'next_eligible_date']

#     def get_next_eligible_date(self, obj):
#         return obj.next_eligible_date

# class AllClothingItemsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ClothingCategory
#         fields = '__all__'
#         read_only_fields = ('id', 'form')
#     class Meta:
#         model = ClothingItem
#         fields = '__all__'
#         read_only_fields = ('id', 'form')
# uniform_management/serializers.py

from rest_framework import serializers
from .models import Officer, Issuance, IssuedItem, ClothingItem, ClothingCategory
import datetime

class SimpleClothingItemSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = ClothingItem
        fields = '__all__'

class ClothingItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClothingItem
        fields = '__all__'

class IssuedItemSerializer(serializers.ModelSerializer):
    category = serializers.CharField(write_only=True, required=False)
    item_name = serializers.CharField(write_only=True, required=False)
    clothing_item = SimpleClothingItemSerializer(read_only=True)

    class Meta:
        model = IssuedItem
        fields = ['id', 'clothing_item', 'quantity', 'category', 'item_name']
        extra_kwargs = {
            'quantity': {'required': False, 'default': 1},
        }

    def to_internal_value(self, data):
        try:
            # Process only available fields
            processed_data = {
                'category': data.get('category'),
                'item_name': data.get('item_name'),
                'quantity': data.get('quantity', 1)
            }
            
            # Skip if essential fields are missing
            if not processed_data.get('item_name'):
                return {}
                
            validated_data = super().to_internal_value(processed_data)
            
            # Handle category and item creation
            item_name = validated_data.get('item_name')
            category_name = validated_data.get('category')
            
            if item_name:
                category = None
                if category_name:
                    category, _ = ClothingCategory.objects.get_or_create(name=category_name)
                
                clothing_item, _ = ClothingItem.objects.get_or_create(
                    name=item_name,
                    defaults={
                        'category': category,
                        'lifespan_months': 24 if category else None
                    }
                )
                validated_data['clothing_item'] = clothing_item
            
            return validated_data
            
        except Exception as e:
            # Skip this item if there's an error
            return {}

class IssuanceSerializer(serializers.ModelSerializer):
    selectedItems = IssuedItemSerializer(many=True, source='items', required=False)
    serialNo = serializers.CharField(source='serial_no', required=False, allow_null=True, allow_blank=True)
    clNo = serializers.CharField(source='cl_no', required=False, allow_null=True, allow_blank=True)
    date = serializers.DateField(format='%Y-%m-%d', required=False, allow_null=True)

    class Meta:
        model = Issuance
        fields = ['id', 'clNo', 'date', 'serialNo', 'selectedItems']

    def validate(self, data):
        # Skip validation if essential fields are missing
        if not data.get('date') and not data.get('cl_no') and not data.get('serial_no'):
            return {}
        return data
    
    def update(self, instance, validated_data):
        """
        Updates an existing Issuance instance and its nested IssuedItem instances.
        """
        print(f"\n--- IssuanceSerializer update called for Issuance ID: {instance.id} ---")
        print(f"Validated Data for Issuance: {json.dumps(validated_data, indent=2, default=str)}")

        # 1. Update basic Issuance fields
        instance.cl_no = validated_data.get('cl_no', instance.cl_no)
        instance.serial_no = validated_data.get('serial_no', instance.serial_no)
        instance.date = validated_data.get('date', instance.date)
        instance.save()
        print("Issuance main fields updated.")

        # 2. Handle nested IssuedItems if 'items' key is present in validated_data
        # (This corresponds to 'selectedItems' in the incoming request)
        items_data = validated_data.get('items') 

        if items_data is not None:
            print(f"Handling nested IssuedItems. Incoming items count: {len(items_data)}")
            
            # Keep track of IDs of existing items that are *kept* or updated
            items_to_keep_ids = [] 
            
            # Iterate through incoming items data
            for item_data in items_data:
                clothing_item_instance = item_data.get('clothing_item')
                quantity = item_data.get('quantity', 1)

                if not clothing_item_instance:
                    print(f"Skipping item in update due to missing clothing_item instance after to_internal_value: {item_data}")
                    continue

                # Try to find an existing IssuedItem for this Issuance and ClothingItem
                try:
                    issued_item = instance.items.get(clothing_item=clothing_item_instance)
                    # If found, update its quantity
                    issued_item.quantity = quantity
                    issued_item.save()
                    items_to_keep_ids.append(issued_item.id)
                    print(f"Updated existing IssuedItem (ID: {issued_item.id}): {clothing_item_instance.name}, Quantity: {quantity}")
                except IssuedItem.DoesNotExist:
                    # If not found, it's a new item, so create it
                    new_issued_item = IssuedItem.objects.create(
                        issuance=instance,
                        clothing_item=clothing_item_instance,
                        quantity=quantity
                    )
                    items_to_keep_ids.append(new_issued_item.id)
                    print(f"Created new IssuedItem (ID: {new_issued_item.id}): {clothing_item_instance.name}, Quantity: {quantity}")

            # 3. Delete any IssuedItems that were previously associated with this Issuance
            # but are no longer present in the `items_data` from the request.
            # Get all existing IssuedItem IDs for this Issuance
            all_existing_issued_item_ids = set(instance.items.values_list('id', flat=True))
            
            # Determine which items to delete
            items_to_delete_ids = all_existing_issued_item_ids - set(items_to_keep_ids)
            
            if items_to_delete_ids:
                IssuedItem.objects.filter(id__in=items_to_delete_ids).delete()
                print(f"Deleted {len(items_to_delete_ids)} IssuedItems: {items_to_delete_ids}")
            else:
                print("No IssuedItems to delete.")
        else:
            print("No 'selectedItems' data provided in the request; skipping IssuedItem updates.")

        return instance

class OfficerDataSerializer(serializers.ModelSerializer):
    forceNo = serializers.CharField(source='force_no', required=False)
    dateAttested = serializers.DateField(source='date_attested', required=False, allow_null=True)
    certClNo = serializers.CharField(source='cert_cl_no', required=False, allow_null=True, allow_blank=True)
    sccNo = serializers.CharField(source='scc_no', required=False, allow_null=True, allow_blank=True)
    issuedByDate = serializers.DateField(required=False, allow_null=True)
    issuedBySignature = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    issuedBy = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    issuances = IssuanceSerializer(many=True, required=False)

    class Meta:
        model = Officer
        fields = [
            'forceNo', 'dateAttested', 'branch', 'name', 'initials',
            'certClNo', 'sccNo', 'issuedByDate', 'issuedBySignature', 'issuedBy',
            'issuances'
        ]
        extra_kwargs = {
            'branch': {'required': False},
            'name': {'required': False},
            'initials': {'required': False},
        }

    def create(self, validated_data):
        try:
            # Skip if essential officer data is missing
            if not validated_data.get('force_no'):
                return None
                
            # Pop all nested data and write-only fields
            issuances_data = validated_data.pop('issuances', [])
            issued_by = validated_data.pop('issuedBy', None)
            issued_by_date = validated_data.pop('issuedByDate', None)
            issued_by_signature = validated_data.pop('issuedBySignature', None)

            # Create or update Officer instance
            officer, created = Officer.objects.get_or_create(
                force_no=validated_data.get('force_no'),
                defaults=validated_data
            )

            if not created:
                for attr, value in validated_data.items():
                    if value is not None:  # Only update if value is provided
                        setattr(officer, attr, value)
                officer.save()

            # Handle nested Issuances
            for issuance_data in issuances_data:
                if not issuance_data:  # Skip empty issuance data
                    continue
                    
                issued_items_data = issuance_data.pop('items', [])
                
                # Skip if essential issuance data is missing
                if not issuance_data.get('date'):
                    continue
                    
                issuance = Issuance.objects.create(
                    officer=officer,
                    issued_by=issued_by,
                    issued_by_date=issued_by_date,
                    issued_by_signature=issued_by_signature,
                    **{k: v for k, v in issuance_data.items() if v is not None}
                )

                # Create IssuedItems
                issued_items = []
                for issued_item_data in issued_items_data:
                    if issued_item_data:  # Skip empty item data
                        issued_items.append(IssuedItem(
                            issuance=issuance,
                            clothing_item=issued_item_data.get('clothing_item'),
                            quantity=issued_item_data.get('quantity', 1)
                        ))
                
                if issued_items:  # Only bulk create if there are items
                    IssuedItem.objects.bulk_create(issued_items)

            return officer
            
        except Exception as e:
            # Log the error but don't fail the entire operation
            print(f"Error creating officer data: {str(e)}")
            return None

    def update(self, instance, validated_data):
        try:
            # Skip if no valid data provided
            if not validated_data:
                return instance
                
            issuances_data = validated_data.pop('issuances', [])
            issued_by = validated_data.pop('issuedBy', None)
            issued_by_date = validated_data.pop('issuedByDate', None)
            issued_by_signature = validated_data.pop('issuedBySignature', None)

            # Update Officer fields
            for attr, value in validated_data.items():
                if value is not None:  # Only update if value is provided
                    setattr(instance, attr, value)
            instance.save()

            # Handle nested Issuances - clear existing only if new ones are provided
            if issuances_data:
                instance.issuances.all()

                for issuance_data in issuances_data:
                    if not issuance_data:  # Skip empty issuance data
                        continue
                        
                    issued_items_data = issuance_data.pop('items', [])

                    # Skip if essential issuance data is missing
                    if not issuance_data.get('date'):
                        continue
                        
                    issuance = Issuance.objects.create(
                        officer=instance,
                        issued_by=issued_by,
                        issued_by_date=issued_by_date,
                        issued_by_signature=issued_by_signature,
                        **issuance_data
                    )

                    # Create IssuedItems
                    for issued_item_data in issued_items_data:
                        if issued_item_data:  # Skip empty item data
                            IssuedItem.objects.create(
                                issuance=issuance,
                                clothing_item=issued_item_data.get('clothing_item'),
                                quantity=issued_item_data.get('quantity', 1)
                            )

            return instance
            
        except Exception as e:
            # Log the error but don't fail the entire operation
            print(f"Error updating officer data: {str(e)}")
            return instance

