from django.shortcuts import render

# Create your views here.

import os
from django.shortcuts import render

# Create your views here.
from django.contrib.auth import authenticate, login
from django.http import JsonResponse
  
from .forms import UserRegistrationForm
from .models import *
# from .serializer import EvaluationSerializer, UserProfileSerializer, ProjectsSerializer,InnovationSerializer, AuditTrailSerializer, NotificationSerializer
# from django.contrib.auth.decorators import login_required, user_passes_test
from rest_framework.decorators import api_view
from rest_framework.response import Response
import json

from django.contrib.auth.models import User
# from rest_framework.decorators import api_view, parser_classes
# from rest_framework.parsers import MultiPartParser, FormParser
# from rest_framework.decorators import permission_classes
# from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.views.decorators.csrf import csrf_exempt
import logging







@csrf_exempt  
def login_user(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "message": "Only POST requests are allowed."}, status=405)

    try:
        # Parse JSON data
        data = json.loads(request.body)
        username = data.get("username", "").strip()
        password = data.get("password", "").strip()

        # Validate input fields
        if not username:
            return JsonResponse({"success": False, "message": "Username is required."}, status=400)
        if not password:
            return JsonResponse({"success": False, "message": "Password is required."}, status=400)

        # Authenticate user
        user = authenticate(request, username=username, password=password)
        
        if user is None:
            return JsonResponse({"success": False, "message": "Invalid username or password."}, status=401)

        # Check if user is active
        if not user.is_active:
            return JsonResponse({"success": False, "message": "Your account is disabled. Please contact support."}, status=403)

        # Log user action (only log if authentication is successful)
        # log_user_action(user, 'login')

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        token = str(refresh.access_token)
        refresh_token = str(refresh)

        # Get user role
        try:
            user_profile = Userprofile.objects.get(user=user)
            user_role = user_profile.rank
        except Userprofile.DoesNotExist:
            return JsonResponse({"success": False, "message": "User profile not found."}, status=404)

        return JsonResponse({
            "success": True,
            "message": "Login successful.",
            "access": token,
            "refresh": refresh_token,
            "role": user_role,
            "user_id": user.id,
            "user": user.username,
            "office": user_profile.office
        }, status=200)

    except json.JSONDecodeError:
        return JsonResponse({"success": False, "message": "Invalid JSON format."}, status=400)

    except Exception as e:
        return JsonResponse({"success": False, "message": f"An unexpected error occurred: {str(e)}"}, status=500)

logger = logging.getLogger(__name__)

# #view to log user activities
# def log_user_action(user, action):
#     print(f"Logging action: {action} for user: {user.username}")
#     logger.debug(f"Logging action: {action} for user: {user.username}")
#     UserAction.objects.create(user=user, action=action)



@csrf_exempt  
def register_user(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            print(data)
            form = UserRegistrationForm(data)

            if form.is_valid():
                form.save()  
                return JsonResponse({"success": True, "message": "Registration successful."}, status=201)
            else:
                print(form.errors)
                return JsonResponse({"success": False, "errors": form.errors}, status=400)

        except json.JSONDecodeError:
            return JsonResponse({"success": False, "message": "Invalid JSON format."}, status=400)

    return JsonResponse({"success": False, "message": "Only POST requests are allowed."}), 

# -	Signup
# -	Url => /signup
# -	Method => post
# -	Data sent { sectionNo:String, password:string}
# -	Expected Response {success/error : string, status: number}

# -	Login
# -	Url => /login
# -	Method => post
# -	Data sent {sectionNo:string, password:string}
# -	Expected Response {success/error : string, status: number, authorizationToken : string}


from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import RequisitionForm, RequisitionItem, ReplacementItem
from .serializers import RequisitionFormSerializer
from django.utils import timezone

class RequisitionFormCreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RequisitionFormSerializer
    
    def create(self, request, *args, **kwargs):
        data = request.data
        print(data)
        # Create main form
        form_data = {
            
            'ordinance_control_no': data.get('ordinanceControlNo'),
            'station': data.get('station'),
            'branch': data.get('branch'),
            'dispatch_method': data.get('dispatchMethod'),
            'date': data.get('date'),
            'formType': data.get('formType'),
            
            # Collected By
            'collected_by_no': data.get('collectedBy', {}).get('no'),
            'collected_by_rank': data.get('collectedBy', {}).get('rank'),
            'collected_by_name': data.get('collectedBy', {}).get('name'),
            
            # Officer Recommendations
            'officer_recommendation_at': data.get('officerRecommendation', {}).get('at'),
            'officer_recommendation_rank': data.get('officerRecommendation', {}).get('rank'),
            'officer_recommendation_expense_type': data.get('officerRecommendation', {}).get('expenseType'),
            
            # Checked By
            'checked_by_officer_no': data.get('checkedByOfficer', {}).get('no'),
            'checked_by_officer_rank': data.get('checkedByOfficer', {}).get('rank'),
            'checked_by_quartermaster_no': data.get('checkedByQuartermaster', {}).get('no'),
            'checked_by_quartermaster_rank': data.get('checkedByQuartermaster', {}).get('rank'),
            
            # Initials and Dates
            'voucher_checked_by_initials': data.get('voucherCheckedBy', {}).get('initials'),
            'voucher_checked_by_date': data.get('voucherCheckedBy', {}).get('date'),
            'items_selected_by_initials': data.get('itemsSelectedBy', {}).get('initials'),
            'items_selected_by_date': data.get('itemsSelectedBy', {}).get('date'),
            'items_packed_by_initials': data.get('itemsPackedBy', {}).get('initials'),
            'items_packed_by_date': data.get('itemsPackedBy', {}).get('date'),
            'entered_on_clothing_card_initials': data.get('enteredOnClothingCard', {}).get('initials'),
            'entered_on_clothing_card_date': data.get('enteredOnClothingCard', {}).get('date'),
            'ledger_actioned_initials': data.get('ledgerActioned', {}).get('initials'),
            'ledger_actioned_date': data.get('ledgerActioned', {}).get('date'),
            
            # Dispatch Method Details
            'dispatch_collected': data.get('dispatchMethodDetails', {}).get('collected', False),
            'dispatch_rail': data.get('dispatchMethodDetails', {}).get('rail', False),
            'dispatch_road': data.get('dispatchMethodDetails', {}).get('road', False),
            'dispatch_air': data.get('dispatchMethodDetails', {}).get('air', False),
            'dispatch_registered_mail': data.get('dispatchMethodDetails', {}).get('registeredMail', False),
            'dispatch_parcel_post': data.get('dispatchMethodDetails', {}).get('parcelPost', False),
            'dispatch_parcel_warrant_no': data.get('dispatchMethodDetails', {}).get('parcelWarrantNo', ''),
        }
        
        serializer = self.get_serializer(data=form_data)
        serializer.is_valid(raise_exception=True)
        form = serializer.save(created_by=request.user)
        
        # Create Requisition Items
        items = data.get('items', [])
        for item in items:
            RequisitionItem.objects.create(
                form=form,
                force_no=item.get('forceNo', ''),
                rank=item.get('rank', ''),
                name=item.get('name', ''),
                article=item.get('article', ''),
                size=item.get('size', ''),
                regd_no=item.get('regdNo', ''),
                date_due=item.get('dateDue', ''),
                issued=item.get('issued', ''),
                signature=item.get('signature', ''),
                life=item.get('life', ''),
                reason=item.get('reason', ''),
            )
        
        # Create Replacement Items
        replacement_items = data.get('replacementItems', [])
        for item in replacement_items:
            ReplacementItem.objects.create(
                form=form,
                force_no=item.get('forceNo', ''),
                life=item.get('life', ''),
                date_due=item.get('dateDue', ''),
                issued=item.get('issued', ''),
                reason=item.get('reason', ''),
            )
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

class RequisitionFormListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RequisitionFormSerializer
    
    def get_queryset(self):
        return RequisitionForm.objects.filter(created_by=self.request.user).order_by('-created_at')

class RequisitionFormListViewOfficerInChargeAuth(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RequisitionFormSerializer
    
    def get_queryset(self):
        # Only show requisitions that are 'awaiting' approval
        return RequisitionForm.objects.filter(
            office_in_charge_status='awaiting'
        ).order_by('-created_at')


class RequisitionFormDetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RequisitionFormSerializer
    queryset = RequisitionForm.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this form.")
        return obj
    


    # ------------------------------
    # Form321 View 
    # ------------------------------

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import Form321, EquipmentItem, PersonInvolved
from .serializers import Form321Serializer
from django.utils import timezone

class Form321CreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Form321Serializer
    
    def create(self, request, *args, **kwargs):
        data = request.data
        
        # Create main form
        form_data = {
            'created_by': request.user,
            'report_no': data.get('reportNo'),
            'province': data.get('province'),
            'station': data.get('station'),
            'condition': data.get('condition'),
            'date_of_issue': data.get('dateOfIssue'),
            'date_of_loss': data.get('dateOfLoss'),
            'circumstances': data.get('circumstances'),
            'agree_to_refund': data.get('agreeToRefund'),
            'officer_comment': data.get('officerComment'),
            'negligence': data.get('negligence'),
            'await_date': data.get('awaitDate'),
            'government_pay_amount': data.get('governmentPayAmount'),
            'depreciated_value': data.get('depreciatedValue'),
            'government_pay_percentage': data.get('governmentPayPercentage'),
            'member_pay_percentage': data.get('memberPayPercentage'),
            'board_of_enquiry_received': data.get('boardOfEnquiryReceived', False),
            'home_affairs_advised': data.get('homeAffairsAdvised', False),
            'equipment_recovered': data.get('equipmentRecovered', False),
        }
        
        serializer = self.get_serializer(data=form_data)
        serializer.is_valid(raise_exception=True)
        form = serializer.save(created_by=request.user)
        
        # Create Equipment Items
        equipment_items = data.get('equipmentItems', [])
        for item in equipment_items:
            EquipmentItem.objects.create(
                form=form,
                description=item.get('description', ''),
                number=item.get('number', ''),
                value=item.get('value', ''),
            )
        
        # Create Persons Involved
        persons = data.get('persons', [])
        for person in persons:
            PersonInvolved.objects.create(
                form=form,
                no=person.get('no', ''),
                rank=person.get('rank', ''),
                name=person.get('name', ''),
                home_station=person.get('homeStation', ''),
            )
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

class Form321ListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Form321Serializer
    
    def get_queryset(self):
        return Form321.objects.filter(created_by=self.request.user).order_by('-created_at')

class Form321DetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Form321Serializer
    queryset = Form321.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this form.")
        return obj
    
    # ------------------------------------
    # Form 163
    # ------------------------------------

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import Form163, RequisitionItem, FormSignature
from .serializers import Form163Serializer
from django.utils import timezone
# In api/views.py

from .models import Form163, RequisitionItem163, FormSignature # Make sure RequisitionItem163 is imported

class Form163CreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Form163Serializer

    def create(self, request, *args, **kwargs):
        data = request.data

        form = Form163.objects.create(
            created_by=request.user,
            officer_in_charge_approved=Form163ApprovalStatus.WAITING,
             formType=data.get('form_type', Form163FormType.ISSUES_REQUEST) # 'form_type' is the key you'd send from frontend
        )

        # Create Requisition Items (assuming this part is working)
        items_data = data.get('items', [])
        for item_data in items_data:
            # Ensure field names match your RequisitionItem163 model fields
            RequisitionItem163.objects.create(
                form=form,
                description=item_data.get('description', ''),
                size=item_data.get('size', ''),
                # Ensure these keys match what frontend sends (e.g., 'noRegd' vs 'no_regd')
                no_regd=item_data.get('noRegd', ''), # Frontend 'noRegd' maps to backend 'no_regd'
                no_issued=item_data.get('noIssued', ''), # Frontend 'noIssued' maps to backend 'no_issued'
            )

        # Extract signature data safely
        requested_by_data = data.get('requestedBy', {})
        issued_by_data = data.get('issuedBy', {})
        received_by_data = data.get('receivedBy', {})
        ledger_actioned_by_data = data.get('ledgerActionedBy', {})

        # --- Debugging additions ---
        print(f"DEBUG: extracted requested_by_data: {requested_by_data}")
        # --- End Debugging additions ---

        # Create FormSignature instance
        FormSignature.objects.create(
            form=form,
            requested_by_initials=requested_by_data.get('initials', None), # Use None for null if DB field is null=True
            requested_by_date=requested_by_data.get('date', None),         # Use None for null if DB field is null=True
            issued_by_initials=issued_by_data.get('initials', None),
            issued_by_date=issued_by_data.get('date', None),
            received_by_initials=received_by_data.get('initials', None),
            received_by_date=received_by_data.get('date', None),
            ledger_actioned_by_initials=ledger_actioned_by_data.get('initials', None),
            ledger_actioned_by_date=ledger_actioned_by_data.get('date', None),
        )

        serializer = self.get_serializer(form)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)



class Form163ListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Form163Serializer
    
    def get_queryset(self):
        return Form163.objects.filter(created_by=self.request.user).order_by('-created_at')

class Form163DetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Form163Serializer
    queryset = Form163.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this form.")
        return obj
    

# ------------------------------------
# Rejection Certificate
# ------------------------------------

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import RejectionCertificate, RejectedItem
from .serializers import RejectionCertificateSerializer
from django.utils import timezone

class RejectionCertificateCreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RejectionCertificateSerializer
    
    def create(self, request, *args, **kwargs):
        data = request.data
        
        # Create main certificate
        certificate_data = {
           
            'entry_no': data.get('entryNo'),
            'certificate_no': data.get('certificateNo'),
            'inspector_number': data.get('inspectorInfo', {}).get('number'),
            'inspector_rank': data.get('inspectorInfo', {}).get('rank'),
            'inspector_name': data.get('inspectorInfo', {}).get('name'),
            'supplier': data.get('supplier'),
            'rejection_reason': data.get('rejectionReason'),
            'all_accepted': data.get('allAccepted', False),
            'all_rejected': data.get('allRejected', False),
            'qualification': data.get('qualification'),
            'years_served': data.get('yearsServed'),
            'signature': data.get('signature'),
            'date': data.get('date'),
            'witness_f_number': data.get('witnessInfo', {}).get('fNumber'),
            'witness_rank': data.get('witnessInfo', {}).get('rank'),
            'witness_name': data.get('witnessInfo', {}).get('name'),
            'witness_office_held': data.get('witnessInfo', {}).get('officeHeld'),
        }
        
        serializer = self.get_serializer(data=certificate_data)
        serializer.is_valid(raise_exception=True)
        certificate = serializer.save(created_by=request.user)
        
        # Create Rejected Items
        items = data.get('items', [])
        for item in items:
            RejectedItem.objects.create(
                certificate=certificate,
                item=item.get('item', ''),
                quantity=item.get('qty', ''),
                delivery_note=item.get('dNote', ''),
                order_no=item.get('orderNo', ''),
                rejected=item.get('rejected', ''),
                accepted=item.get('accepted', ''),
                value=item.get('value', ''),
            )
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

class RejectionCertificateListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RejectionCertificateSerializer
    
    def get_queryset(self):
        return RejectionCertificate.objects.filter(created_by=self.request.user).order_by('-created_at')

class RejectionCertificateDetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = RejectionCertificateSerializer
    queryset = RejectionCertificate.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this certificate.")
        return obj
    
    # ------------------------------------
    # Book 2 IssueVoucher 
    # ------------------------------------ 

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import Book2IssueVoucher, IssueItem
from .serializers import Book2IssueVoucherSerializer
from django.utils import timezone

class Book2IssueVoucherCreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Book2IssueVoucherSerializer
    
    def create(self, request, *args, **kwargs):
        data = request.data
        
        # Create main voucher
        voucher_data = {
            
            'issued_by': data.get('issuedBy'),
            'issued_to': data.get('issuedTo'),
            'dispatch_method': data.get('dispatchMethod'),
            
            # Recipient Information
            'received_by_signature': data.get('receivedBy'),
            'received_date': data.get('receivedDate'),
            'recipient_no': data.get('recipientNo'),
            'recipient_rank': data.get('recipientRank'),
            'recipient_name': data.get('recipientName'),
            'recipient_station': data.get('recipientStation'),
            
            # Certification
            'certified_by': data.get('certifiedBy'),
            'certified_date': data.get('certifiedDate'),
            
            # Voucher Numbers
            'iv_no': data.get('ivNo'),
            'iv_date': data.get('ivDate'),
            'reqn_no': data.get('reqnNo'),
            'reqn_date': data.get('reqnDate'),
        }
        
        serializer = self.get_serializer(data=voucher_data)
        serializer.is_valid(raise_exception=True)
        voucher = serializer.save(created_by=request.user)
        
        # Create Issue Items
        items = data.get('items', [])
        for item in items:
            IssueItem.objects.create(
                voucher=voucher,
                description=item.get('description', ''),
                quantity=item.get('quantity', ''),
                remarks=item.get('remarks', ''),
            )
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

class Book2IssueVoucherListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Book2IssueVoucherSerializer
    
    def get_queryset(self):
        return Book2IssueVoucher.objects.filter(created_by=self.request.user).order_by('-created_at')

class Book2IssueVoucherDetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = Book2IssueVoucherSerializer
    queryset = Book2IssueVoucher.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this voucher.")
        return obj
    
    # ------------------------------------
    # Exchange Voucher
    # -------------------------------------

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import ExchangeVoucher, ExchangeItem
from .serializers import ExchangeVoucherSerializer

class ExchangeVoucherCreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ExchangeVoucherSerializer

    def create(self, request, *args, **kwargs):
        data = request.data

        # Create main voucher
        voucher_data = {
            # 'created_by': request.user,  # << Correct: pass the User object, not user.id
            'returned_by_initials': data.get('returnedBy', {}).get('initials'),
            'returned_by_date': data.get('returnedBy', {}).get('date'),
            'ledger_actioned_by_initials': data.get('ledgerActionedBy', {}).get('initials'),
            'ledger_actioned_by_date': data.get('ledgerActionedBy', {}).get('date'),
        }

        serializer = self.get_serializer(data=voucher_data)
        serializer.is_valid(raise_exception=True)
        # voucher = serializer.save()
        voucher = serializer.save(created_by=request.user)

        # Create Exchange Items
        items = data.get('items', [])
        for item in items:
            ExchangeItem.objects.create(
                voucher=voucher,
                returned_description=item.get('returnedDescription', ''),
                returned_size=item.get('returnedSize', ''),
                returned_no=item.get('returnedNo', ''),
                issued_description=item.get('issuedDescription', ''),
                issued_size=item.get('issuedSize', ''),
                issued_no=item.get('issuedNo', ''),
            )

        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

class ExchangeVoucherListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ExchangeVoucherSerializer
    
    def get_queryset(self):
        return ExchangeVoucher.objects.filter(created_by=self.request.user).order_by('-created_at')

class ExchangeVoucherDetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ExchangeVoucherSerializer
    queryset = ExchangeVoucher.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this voucher.")
        return obj    

# ------------------------------------
# Discharge Voucher
# ------------------------------------

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import DischargeCertificate
from .serializers import DischargeCertificateSerializer
from django.utils import timezone

class DischargeCertificateCreateView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = DischargeCertificateSerializer
    
    def create(self, request, *args, **kwargs):
        data = request.data
        
        certificate_data = {
            
            # Member Information
            'member_no': data.get('memberInfo', {}).get('no'),
            'member_rank': data.get('memberInfo', {}).get('rank'),
            'member_name': data.get('memberInfo', {}).get('name'),
            'member_station': data.get('memberInfo', {}).get('station'),
            
            # Discharge Information
            'discharge_reasons': data.get('dischargeInfo', {}).get('reasons'),
            'discharge_date': data.get('dischargeInfo', {}).get('date'),
            
            # Repayment Information
            'repayment_ic_date': data.get('repaymentInfo', {}).get('icDate'),
            'repayment_iv': data.get('repaymentInfo', {}).get('iv'),
            'repayment_iv_date': data.get('repaymentInfo', {}).get('ivDate'),
            'repayment_acv_confirmed': data.get('repaymentInfo', {}).get('acvConfirmed', False),
            'repayment_total': data.get('repaymentInfo', {}).get('total'),
            'repayment_no_outstanding': data.get('repaymentInfo', {}).get('noOutstanding', False),
            
            # Kit Deficiencies
            'kit_articles_listed': data.get('kitDeficiencies', {}).get('articlesListed'),
            'kit_date': data.get('kitDeficiencies', {}).get('date'),
            'kit_sum': data.get('kitDeficiencies', {}).get('sum'),
            'kit_no_deficiencies': data.get('kitDeficiencies', {}).get('noDeficiencies', False),
            
            # Summary
            'summary_kit_repayment': data.get('summary', {}).get('kitRepayment'),
            'summary_deficiencies': data.get('summary', {}).get('deficiencies'),
        }
        
        serializer = self.get_serializer(data=certificate_data)
        serializer.is_valid(raise_exception=True)
        certificate = serializer.save(created_by=request.user)
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

class DischargeCertificateListView(generics.ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = DischargeCertificateSerializer
    
    def get_queryset(self):
        return DischargeCertificate.objects.filter(created_by=self.request.user).order_by('-created_at')

class DischargeCertificateDetailView(generics.RetrieveAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = DischargeCertificateSerializer
    queryset = DischargeCertificate.objects.all()
    
    def get_object(self):
        obj = super().get_object()
        if obj.created_by != self.request.user:
            raise PermissionDenied("You don't have permission to access this certificate.")
        return obj
    


    
    # from rest_framework import generics
# from rest_framework.response import Response
# from rest_framework import status
# from .models import Form226
# from .serializers import Form226Serializer

# class Form226ListCreateView(generics.ListCreateAPIView):
#     queryset = Form226.objects.all()
#     serializer_class = Form226Serializer
    
#     def create(self, request, *args, **kwargs):
#         serializer = self.get_serializer(data=request.data)
#         if serializer.is_valid():
#             self.perform_create(serializer)
#             headers = self.get_success_headers(serializer.data)
#             return Response(
#                 {"message": "Form successfully added", "data": serializer.data},
#                 status=status.HTTP_201_CREATED,
#                 headers=headers
#             )
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# class Form226RetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Form226.objects.all()
#     serializer_class = Form226Serializer
#     lookup_field = 'id'
    
#     def update(self, request, *args, **kwargs):
#         partial = kwargs.pop('partial', False)
#         instance = self.get_object()
#         serializer = self.get_serializer(instance, data=request.data, partial=partial)
#         if serializer.is_valid():
#             self.perform_update(serializer)
#             return Response(
#                 {"message": "Form successfully updated", "data": serializer.data},
#                 status=status.HTTP_200_OK
#             )
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
#     def destroy(self, request, *args, **kwargs):
#         instance = self.get_object()
#         self.perform_destroy(instance)
#         return Response(
#             {"message": "Form successfully deleted"},
#             status=status.HTTP_204_NO_CONTENT
#         )