from django import forms
from django.contrib.auth.models import User
from .models import Userprofile

class UserRegistrationForm(forms.ModelForm):
    username = forms.CharField(max_length=150, required=False)
    password = forms.CharField(widget=forms.PasswordInput, required=True)
    
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=150, required=True)
    rank = forms.CharField(max_length=100, required=True)
    office = forms.CharField(max_length=100)
    province = forms.CharField(max_length=100)
    station = forms.CharField(max_length=100)

    class Meta:
        model = Userprofile
        fields = ['username', 'password', 'first_name', 'last_name', 'rank', 'office', 'province', 'station']

    def save(self, commit=True):
        # Create the User object with additional fields
        user = User.objects.create_user(
            username =self.cleaned_data['username'],
            
            password=self.cleaned_data['password'],
            first_name=self.cleaned_data['first_name'],
            last_name=self.cleaned_data['last_name']
        )
        
        # Create the UserProfile object
        user_profile = Userprofile(
            user=user,
            rank=self.cleaned_data['rank'],
            office=self.cleaned_data['office'],
            province=self.cleaned_data['province'],
            station=self.cleaned_data['station']
            
        )
        
        if commit:
            user.save()
            user_profile.save()
        
        return user_profile
    
