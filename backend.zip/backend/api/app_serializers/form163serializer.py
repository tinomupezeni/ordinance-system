from rest_framework import serializers
from ..models import Form163, Form163ApprovalStatus # Make sure to import your models and the choices

# Assuming Form163, Form163ApprovalStatus are defined in models.py as previously discussed

class Form163ApprovalSerializer(serializers.ModelSerializer):
    """
    Serializer specifically for updating the approval status (APPROVED/REJECTED)
    of a Form163 instance.
    """
    # The 'status' field will correspond to 'officer_in_charge_approved' on the model.
    # We use a ChoiceField to ensure only valid choices are provided.
    status = serializers.ChoiceField(
        choices=Form163ApprovalStatus.choices,
        help_text="The approval status: 'APPROVED' or 'REJECTED'."
    )
    
    # 'rejection_reason' is optional but required if status is 'REJECTED'.
    rejection_reason = serializers.CharField(
        required=False, 
        allow_blank=True, 
        help_text="Reason for rejection (required if status is 'REJECTED')."
    )

    class Meta:
        model = Form163
        # Only include the fields that this serializer is responsible for updating.
        fields = ['status', 'rejection_reason']
        # No fields are read-only when using this serializer for updates,
        # as its purpose is to write these specific fields.
        read_only_fields = [] 

    def validate_status(self, value):
        """
        Custom validation to ensure the provided status is either APPROVED or REJECTED
        for this specific endpoint.
        """
        if value not in [Form163ApprovalStatus.APPROVED, Form163ApprovalStatus.REJECTED]:
            raise serializers.ValidationError("Status must be 'APPROVED' or 'REJECTED' for this operation.")
        return value

    def validate(self, data):
        """
        Object-level validation to ensure a rejection reason is provided if the
        status is set to 'REJECTED'.
        """
        status = data.get('status')
        rejection_reason = data.get('rejection_reason')

        if status == Form163ApprovalStatus.REJECTED and not rejection_reason:
            raise serializers.ValidationError(
                {"rejection_reason": "Rejection reason is required when status is 'REJECTED'."}
            )
        # Ensure that if status is APPROVED, rejection_reason is cleared (handled in view, but good practice here too)
        if status == Form163ApprovalStatus.APPROVED and rejection_reason:
             data['rejection_reason'] = None # Clear if accidentally sent with approval
        
        return data
    
# In api/serializers.py (or a new file if you prefer to organize serializers)
from rest_framework import serializers

class Form163RejectInputSerializer(serializers.Serializer):
    rejection_reason = serializers.CharField(max_length=500, required=True,
                                             error_messages={'required': 'Rejection reason is required.'})