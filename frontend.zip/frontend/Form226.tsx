import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import Form227Pdf from "../formPdfs/Form227Pdf";
import Server from "@/server/Server";
import Form226Pdf from "@/formPdfs/Form226Pdf";

type RequisitionItem = {
  id: number;
  forceNo: string;
  rank: string;
  name: string;
  article: string;
  size: string;
  regdNo: string;
  dateDue: string;
  issued: string;
  signature: string;
  life?: string;
  reason?: string;
  isExpanded?: boolean;
};
type ReplacementItem = {
  id: number;
  forceNo: string;
  life?: string;
  dateDue: string;
  issued: string;
  reason?: string;
  isExpanded?: boolean;
};

type CollectedBy = {
  no: string;
  rank: string;
  name: string;
};

type OfficerRecommendation = {
  at: string;
  rank: string;
  expenseType: "GOVERNMENT" | "MEMBER";
};

type CheckedBy = {
  no: string;
  rank: string;
  name?: string;
};

type InitialsAndDate = {
  initials: string;
  date: string;
};

type DispatchMethod = {
  collected: boolean;
  rail: boolean;
  road: boolean;
  air: boolean;
  registeredMail: boolean;
  parcelPost: boolean;
  parcelWarrantNo: string;
};

const Form226 = () => {
  // Form state
  const [ordinanceControlNo, setOrdinanceControlNo] = useState("");
  const [station, setStation] = useState("");
  const [branch, setBranch] = useState("");
  const [dispatchMethod, setDispatchMethod] = useState<
    "CALLED FOR" | "DESPATCHED"
  >("CALLED FOR");
  const [date, setDate] = useState<string>(
    new Date().toISOString().split("T")[0]
  );

  // Items state
  const [items, setItems] = useState<RequisitionItem[]>([
    createEmptyRequiredItem(1),
  ]);
  const [replacementItems, setReplacementItems] = useState<RequisitionItem[]>([
    createEmptyRequiredItem(1),
  ]);

  // Collected by state
  const [collectedBy, setCollectedBy] = useState<CollectedBy>({
    no: "",
    rank: "",
    name: "",
  });

  // Officer recommendations state
  const [officerRecommendation, setOfficerRecommendation] =
    useState<OfficerRecommendation>({
      at: "",
      rank: "",
      expenseType: "GOVERNMENT",
    });

  // Checked by states
  const [checkedByOfficer, setCheckedByOfficer] = useState<CheckedBy>({
    no: "",
    rank: "",
  });

  const [checkedByQuartermaster, setCheckedByQuartermaster] =
    useState<CheckedBy>({
      no: "",
      rank: "",
    });

  // Various initials and dates
  const [voucherCheckedBy, setVoucherCheckedBy] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  const [itemsSelectedBy, setItemsSelectedBy] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  const [itemsPackedBy, setItemsPackedBy] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  const [enteredOnClothingCard, setEnteredOnClothingCard] =
    useState<InitialsAndDate>({
      initials: "",
      date: "",
    });

  const [ledgerActioned, setLedgerActioned] = useState<InitialsAndDate>({
    initials: "",
    date: "",
  });

  // Dispatch method checkboxes
  const [dispatchMethodDetails, setDispatchMethodDetails] =
    useState<DispatchMethod>({
      collected: false,
      rail: false,
      road: false,
      air: false,
      registeredMail: false,
      parcelPost: false,
      parcelWarrantNo: "",
    });

  const [showPreview, setShowPreview] = useState(false);

  // Helper function to create empty items
  function createEmptyRequiredItem(id: number): RequisitionItem {
    return {
      id,
      forceNo: "",
      rank: "",
      name: "",
      article: "",
      size: "",
      regdNo: "",
      dateDue: "",
      issued: "",
      signature: "",
      life: "",
      reason: "",
      isExpanded: id === 1,
    };
  }
  function createEmptyReplacementItem(id: number): ReplacementItem {
    return {
      id,
      forceNo: "",
      dateDue: "",
      issued: "",
      life: "",
      reason: "",
      isExpanded: id === 1,
    };
  }

  // Add new row when last row starts being filled
  useEffect(() => {
    const lastItem = items[items.length - 1];
    if (
      lastItem &&
      (lastItem.forceNo ||
        lastItem.rank ||
        lastItem.name ||
        lastItem.article ||
        lastItem.size ||
        lastItem.regdNo ||
        lastItem.dateDue ||
        lastItem.issued ||
        lastItem.signature)
    ) {
      // Add new empty row
      setItems((prev) => [...prev, createEmptyRequiredItem(prev.length + 1)]);
    }

    const replacementLastItem = replacementItems[replacementItems.length - 1];
    if (
      replacementLastItem &&
      (replacementLastItem.forceNo ||
        replacementLastItem.dateDue ||
        replacementLastItem.issued ||
        replacementLastItem.reason)
    ) {
      // Add new empty row
      setReplacementItems((prev) => [
        ...prev,
        createEmptyReplacementItem(prev.length + 1),
      ]);
    }
  }, [items]);

  const handleItemChange = (
    id: number,
    field: keyof RequisitionItem,
    value: string
  ) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };
  const handleReplacementItemChange = (
    id: number,
    field: keyof ReplacementItem,
    value: string
  ) => {
    setReplacementItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleDispatchMethodChange = (
    field: keyof DispatchMethod,
    value: boolean | string
  ) => {
    setDispatchMethodDetails((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out completely empty items
    const submittedItems = items.filter(
      (item) =>
        item.forceNo ||
        item.rank ||
        item.name ||
        item.article ||
        item.size ||
        item.regdNo ||
        item.dateDue ||
        item.issued ||
        item.signature
    );

    const submittedReplacementItems = replacementItems.filter(
      (item) => item.forceNo || item.dateDue || item.issued || item.reason
    );

    setItems(submittedItems);
    setReplacementItems(submittedReplacementItems);

    // Create the complete form data object to log
    const completeFormData = {
      ordinanceControlNo,
      station,
      branch,
      dispatchMethod,
      date,
      items: submittedItems,
      replacementItems: submittedReplacementItems,
      collectedBy,
      officerRecommendation,
      checkedByOfficer,
      checkedByQuartermaster,
      voucherCheckedBy,
      itemsSelectedBy,
      dispatchMethodDetails,
      itemsPackedBy,
      enteredOnClothingCard,
      ledgerActioned,
    };

    // Log all form data to console
    console.log("Form submitted with data:", completeFormData);
    // Server.addForm227(completeFormData)
    //   .then(() => {
    //     toast.success("form successfully added");
    //   })
    //   .catch((error) => {
    //     toast.error(error);
    //   });

    setShowPreview(true);
  };

  const handlePrint = () => {
    window.print();
  };

  // Form data object to pass to PDF
  const formData = {
    ordinanceControlNo,
    station,
    branch,
    dispatchMethod,
    date,
    items: items.filter(
      (item) =>
        item.forceNo ||
        item.rank ||
        item.name ||
        item.article ||
        item.size ||
        item.regdNo ||
        item.dateDue ||
        item.issued ||
        item.signature
    ),
    replacementItems: replacementItems.filter(
      (item) => item.forceNo || item.dateDue || item.issued || item.reason
    ),
    collectedBy,
    officerRecommendation,
    checkedByOfficer,
    checkedByQuartermaster,
    voucherCheckedBy,
    itemsSelectedBy,
    dispatchMethodDetails,
    itemsPackedBy,
    enteredOnClothingCard,
    ledgerActioned,
  };

  return (
    <>
      {!showPreview ? (
        <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm">
          <CardHeader className="pb-0">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-blue-900">
                POLICE ORDINANCE STORE REQUISITION
              </h1>
              <p className="text-sm text-gray-600">Issue Voucher [FORM 226]</p>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Basic Information Section */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div>
                  <Label className="block mb-1 font-medium">
                    Ordinance Control No.
                  </Label>
                  <Input
                    value={ordinanceControlNo}
                    onChange={(e) => setOrdinanceControlNo(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-1 font-medium">Rank</Label>
                  <Input
                    value={ordinanceControlNo}
                    onChange={(e) => setOrdinanceControlNo(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-1 font-medium">Name</Label>
                  <Input
                    value={ordinanceControlNo}
                    onChange={(e) => setOrdinanceControlNo(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-1 font-medium">Force No.</Label>
                  <Input
                    value={ordinanceControlNo}
                    onChange={(e) => setOrdinanceControlNo(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-1 font-medium">Station</Label>
                  <Input
                    value={station}
                    onChange={(e) => setStation(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-1 font-medium">Branch</Label>
                  <Input
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <Label className="block mb-1 font-medium">
                    Dispatch Method
                  </Label>
                  <div className="flex gap-4">
                    <Button
                      type="button"
                      variant={
                        dispatchMethod === "CALLED FOR" ? "default" : "outline"
                      }
                      onClick={() => setDispatchMethod("CALLED FOR")}
                    >
                      Called For
                    </Button>
                    <Button
                      type="button"
                      variant={
                        dispatchMethod === "DESPATCHED" ? "default" : "outline"
                      }
                      onClick={() => setDispatchMethod("DESPATCHED")}
                    >
                      Despatched
                    </Button>
                  </div>
                </div>
              </div>

              {/* Items Section */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Items Required</h3>
                <div className="space-y-2">
                  <Card className="overflow-hidden">
                    <CardHeader className="py-2 px-4 bg-gray-50 cursor-pointer"></CardHeader>

                    <CardContent className="p-4">
                      <div className="grid grid-cols-9 font-semibold border-b pb-2 mb-2">
                        <div>Articles Required</div>
                        <div>Size</div>
                        <div>No. Reqd.</div>
                        <div>No. Supplied</div>
                        <div>Priced at</div>
                        <div>$</div>
                        <div>c</div>
                        <div>Remarks</div>
                      </div>

                      {items.map((item) => (
                        <div
                          key={item.id}
                          className="grid grid-cols-9 gap-2 items-center border-b py-2"
                        >
                          <Input
                            value={item.forceNo}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "forceNo",
                                e.target.value
                              )
                            }
                          />
                          <Input
                            value={item.rank}
                            onChange={(e) =>
                              handleItemChange(item.id, "rank", e.target.value)
                            }
                          />
                          <Input
                            value={item.name}
                            onChange={(e) =>
                              handleItemChange(item.id, "name", e.target.value)
                            }
                          />
                          <Input
                            value={item.article}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "article",
                                e.target.value
                              )
                            }
                          />
                          <Input
                            value={item.size}
                            onChange={(e) =>
                              handleItemChange(item.id, "size", e.target.value)
                            }
                          />
                          <Input
                            value={item.regdNo}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "regdNo",
                                e.target.value
                              )
                            }
                          />

                          <Input
                            type="number"
                            value={item.issued}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "issued",
                                e.target.value
                              )
                            }
                          />
                          <Input
                            value={item.signature}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "signature",
                                e.target.value
                              )
                            }
                          />
                        </div>
                      ))}
                      <div className="flex py-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label className="block mb-1 font-medium">
                            Total No.
                          </Label>
                          <Input
                            value={branch}
                            onChange={(e) => setBranch(e.target.value)}
                            required
                          />
                        </div>
                        <div>
                          <Label className="block mb-1 font-medium">
                            Total Cost
                          </Label>
                          <Input
                            value={branch}
                            onChange={(e) => setBranch(e.target.value)}
                            required
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="mb-6">
                <p className="font-bold">
                  I cetify that the articles requisitioned for above are for my
                  own personal use.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label>Date</Label>
                    <Input
                      value={collectedBy.no}
                      type="date"
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, no: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>No.</Label>
                    <Input
                      value={collectedBy.rank}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, rank: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Rank</Label>
                    <Input
                      value={collectedBy.rank}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, rank: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Name</Label>
                    <Input
                      value={collectedBy.name}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, name: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <p className="font-bold">
                  I cetify that the above-named member-.
                </p>
                <p className="">* Is not due for discharge</p>

                <div className="flex align-center text-center justify-start">
                  <Label> * Is due for discharge on </Label>{" "}
                  <Input
                    className="w-[300px]"
                    value={collectedBy.no}
                    type="date"
                    onChange={(e) =>
                      setCollectedBy({ ...collectedBy, no: e.target.value })
                    }
                    required
                  />
                  <p> but the items are necessary for police duties</p>
                </div>
                <p className="text-xs">(*Delete inapplicable)</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label>Date</Label>
                    <Input
                      value={collectedBy.no}
                      type="date"
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, no: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>No.</Label>
                    <Input
                      value={collectedBy.rank}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, rank: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Rank</Label>
                    <Input
                      value={collectedBy.rank}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, rank: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Name</Label>
                    <Input
                      value={collectedBy.name}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, name: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Officer/Member-in-Charge</Label>
                    <Input
                      value={collectedBy.name}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, name: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <p className="font-bold">
                  I cetify that the above articles have been received by me in
                  good order and condition.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label>Date</Label>
                    <Input
                      value={collectedBy.no}
                      type="date"
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, no: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>No.</Label>
                    <Input
                      value={collectedBy.rank}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, rank: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Rank</Label>
                    <Input
                      value={collectedBy.rank}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, rank: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Name</Label>
                    <Input
                      value={collectedBy.name}
                      onChange={(e) =>
                        setCollectedBy({ ...collectedBy, name: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Voucher Checked By</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={voucherCheckedBy.initials}
                        onChange={(e) =>
                          setVoucherCheckedBy({
                            ...voucherCheckedBy,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={voucherCheckedBy.date}
                        onChange={(e) =>
                          setVoucherCheckedBy({
                            ...voucherCheckedBy,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Items Selected By</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={itemsSelectedBy.initials}
                        onChange={(e) =>
                          setItemsSelectedBy({
                            ...itemsSelectedBy,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={itemsSelectedBy.date}
                        onChange={(e) =>
                          setItemsSelectedBy({
                            ...itemsSelectedBy,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Method of Issue/Despatch</p>
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={dispatchMethodDetails.collected}
                        onChange={(e) =>
                          handleDispatchMethodChange(
                            "collected",
                            e.target.checked
                          )
                        }
                      />
                      <Label>Collected</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={dispatchMethodDetails.rail}
                        onChange={(e) =>
                          handleDispatchMethodChange("rail", e.target.checked)
                        }
                      />
                      <Label>Rail</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={dispatchMethodDetails.road}
                        onChange={(e) =>
                          handleDispatchMethodChange("road", e.target.checked)
                        }
                      />
                      <Label>Road</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={dispatchMethodDetails.air}
                        onChange={(e) =>
                          handleDispatchMethodChange("air", e.target.checked)
                        }
                      />
                      <Label>Air</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={dispatchMethodDetails.registeredMail}
                        onChange={(e) =>
                          handleDispatchMethodChange(
                            "registeredMail",
                            e.target.checked
                          )
                        }
                      />
                      <Label>Registered Mail</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={dispatchMethodDetails.parcelPost}
                        onChange={(e) =>
                          handleDispatchMethodChange(
                            "parcelPost",
                            e.target.checked
                          )
                        }
                      />
                      <Label>Parcel Post</Label>
                    </div>
                  </div>
                  <div>
                    <Label>Parcel/Warrant No.</Label>
                    <Input
                      type="text"
                      value={dispatchMethodDetails.parcelWarrantNo}
                      onChange={(e) =>
                        handleDispatchMethodChange(
                          "parcelWarrantNo",
                          e.target.value
                        )
                      }
                    />
                  </div>
                </div>

                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Items Packed By</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={itemsPackedBy.initials}
                        onChange={(e) =>
                          setItemsPackedBy({
                            ...itemsPackedBy,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={itemsPackedBy.date}
                        onChange={(e) =>
                          setItemsPackedBy({
                            ...itemsPackedBy,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Items Checked By</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={itemsPackedBy.initials}
                        onChange={(e) =>
                          setItemsPackedBy({
                            ...itemsPackedBy,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={itemsPackedBy.date}
                        onChange={(e) =>
                          setItemsPackedBy({
                            ...itemsPackedBy,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Items Costed By</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={itemsPackedBy.initials}
                        onChange={(e) =>
                          setItemsPackedBy({
                            ...itemsPackedBy,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={itemsPackedBy.date}
                        onChange={(e) =>
                          setItemsPackedBy({
                            ...itemsPackedBy,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">Ledger Actioned</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={ledgerActioned.initials}
                        onChange={(e) =>
                          setLedgerActioned({
                            ...ledgerActioned,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={ledgerActioned.date}
                        onChange={(e) =>
                          setLedgerActioned({
                            ...ledgerActioned,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 border border-black p-4">
                  <p className="font-bold">S.F.S Action Taken by</p>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label>Initials</Label>
                      <Input
                        value={enteredOnClothingCard.initials}
                        onChange={(e) =>
                          setEnteredOnClothingCard({
                            ...enteredOnClothingCard,
                            initials: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={enteredOnClothingCard.date}
                        onChange={(e) =>
                          setEnteredOnClothingCard({
                            ...enteredOnClothingCard,
                            date: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-between mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Reset all form fields
                    setOrdinanceControlNo("");
                    setStation("");
                    setBranch("");
                    setDispatchMethod("CALLED FOR");
                    setDate(new Date().toISOString().split("T")[0]);
                    setItems([createEmptyRequiredItem(1)]);
                    setReplacementItems([createEmptyReplacementItem(1)]);
                    setCollectedBy({ no: "", rank: "", name: "" });
                    setOfficerRecommendation({
                      at: "",
                      rank: "",
                      expenseType: "GOVERNMENT",
                    });
                    setCheckedByOfficer({ no: "", rank: "" });
                    setCheckedByQuartermaster({ no: "", rank: "" });
                    setVoucherCheckedBy({ initials: "", date: "" });
                    setItemsSelectedBy({ initials: "", date: "" });
                    setDispatchMethodDetails({
                      collected: false,
                      rail: false,
                      road: false,
                      air: false,
                      registeredMail: false,
                      parcelPost: false,
                      parcelWarrantNo: "",
                    });
                    setItemsPackedBy({ initials: "", date: "" });
                    setEnteredOnClothingCard({ initials: "", date: "" });
                    setLedgerActioned({ initials: "", date: "" });

                    toast.info("Form has been reset");
                  }}
                >
                  Reset Form
                </Button>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowPreview(true)}
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Print Preview
                  </Button>
                  <Button type="submit">Submit Requisition</Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Form226Pdf
          formData={formData}
          onBack={() => setShowPreview(false)}
          onPrint={handlePrint}
        />
      )}
    </>
  );
};

export default Form226;
