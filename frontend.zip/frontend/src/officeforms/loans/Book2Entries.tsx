const loanBook2Entries = [
    { id: 1, item: "Handcuffs", officer: "Constable B. Ncube", date: "2025-04-01", action: "Issued" },
    { id: 2, item: "Riot Gear", officer: "Inspector Chari", date: "2025-04-05", action: "Returned" },
  ];
  
  const Book2LoanLog = () => (
    <div className="bg-white p-4 rounded shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Book 2 - Loan Transactions</h2>
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2 px-4">Item</th>
            <th className="py-2 px-4">Officer</th>
            <th className="py-2 px-4">Date</th>
            <th className="py-2 px-4">Action</th>
          </tr>
        </thead>
        <tbody>
          {loanBook2Entries.map((entry) => (
            <tr key={entry.id} className="hover:bg-gray-50">
              <td className="py-2 px-4">{entry.item}</td>
              <td className="py-2 px-4">{entry.officer}</td>
              <td className="py-2 px-4">{entry.date}</td>
              <td className="py-2 px-4">{entry.action}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  export default Book2LoanLog;
  