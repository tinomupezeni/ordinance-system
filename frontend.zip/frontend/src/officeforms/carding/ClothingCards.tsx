import Form57Pdf from "@/formPdfs/Form57Pdf";
import { useEffect, useState } from "react";
import { Printer, ArrowLeft, Eye, Trash } from "lucide-react";
import Server from "@/server/Server";
import ClothingCardViewer from "@/formPdfs/ClothingCardViewer";

const ClothingCards = () => {
  const [filters, setFilters] = useState({
    date: "",
    requestedBy: "",
    size: "",
    status: "",
    officer: "",
    station: "",
  });

  const [showLedger, setShowLedger] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);

  const [clothingData, setClothingData] = useState([]);

  const handleViewLedger = (card) => {
    setSelectedCard(card);
    setShowLedger(true);
  };

  const resetFilters = () => {
    setFilters({
      date: "",
      requestedBy: "",
      size: "",
      status: "",
      officer: "",
      station: "",
    });
  };

  useEffect(() => {
    Server.getAllOfficers()
      .then((response) => {
        console.log(response);
        setClothingData(response);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const filteredForms = clothingData.filter((form) => {
    return (
      (filters.date === "" || form.date === filters.date) &&
      (filters.requestedBy === "" ||
        form.requestedBy === filters.requestedBy) &&
      (filters.size === "" || form.size === Number(filters.size)) &&
      (filters.status === "" || form.status === filters.status) &&
      (filters.officer === "" || form.officer === filters.officer) &&
      (filters.station === "" || form.station === filters.station)
    );
  });

  const uniqueItems = Array.from(
    new Set(clothingData.map((f) => f.requestedBy))
  );
  const uniqueStations = Array.from(
    new Set(clothingData.map((f) => f.station))
  );
  const uniqueOfficers = Array.from(
    new Set(clothingData.map((f) => f.officer))
  );
  const statusOptions = ["Pending", "Approved", "Rejected"];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* <Header /> */}
      <div className="flex">
        {/* <Sidebar /> */}
        <main className="flex-1 p-6">
          <div className="bg-white p-6 shadow rounded-lg">
            {!showLedger ? (
              <>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold text-gray-800">
                    Clothing Cards Records
                  </h2>
                </div>

                {/* Enhanced Filter Section */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      className="w-full border rounded px-3 py-2"
                      value={filters.date}
                      onChange={(e) =>
                        setFilters({ ...filters, date: e.target.value })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Station
                    </label>
                    <select
                      className="w-full border rounded px-3 py-2"
                      value={filters.station}
                      onChange={(e) =>
                        setFilters({ ...filters, station: e.target.value })
                      }
                    >
                      <option value="">All Stations</option>
                      {uniqueStations.map((station, index) => (
                        <option key={index} value={station}>
                          {station}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Officer
                    </label>
                    <select
                      className="w-full border rounded px-3 py-2"
                      value={filters.officer}
                      onChange={(e) =>
                        setFilters({ ...filters, officer: e.target.value })
                      }
                    >
                      <option value="">All Officers</option>
                      {uniqueOfficers.map((officer, index) => (
                        <option key={index} value={officer}>
                          {officer}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-end">
                    <button
                      onClick={resetFilters}
                      className="w-full bg-gray-200 text-gray-800 px-4 py-2 rounded hover:bg-gray-300"
                    >
                      Reset Filters
                    </button>
                  </div>
                </div>

                {/* Enhanced Table */}
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Force Number
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date Attested
                        </th>

                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Officer
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Branch
                        </th>

                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredForms.length > 0 ? (
                        filteredForms.map((card, i) => (
                          <tr key={i} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {card.forceNo}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {card.dateAttested}
                            </td>

                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {card.name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {card.branch}
                            </td>

                            <td className="px-6 py-4 flex whitespace-nowrap text-sm font-medium">
                              <button
                                onClick={() => handleViewLedger(card)}
                                className="text-blue-600 hover:text-blue-900 mr-3"
                              >
                                View
                              </button>
                              <button
                                onClick={() => handleViewLedger(card)}
                                className="text-red-600 hover:text-red-900 mr-3"
                              >
                                Delete
                                {/* <Trash className="w-4 h-6"/> */}
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td
                            colSpan={8}
                            className="px-6 py-4 text-center text-sm text-gray-500"
                          >
                            No clothing cards found matching your filters.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <div>
                <button
                  onClick={() => setShowLedger(false)}
                  className="flex items-center gap-2 mb-4 text-blue-600 hover:text-blue-800"
                >
                  <ArrowLeft size={16} />
                  Back to list
                </button>
                <ClothingCardViewer officerData={selectedCard} />
                {/* <Form57Pdf
                  formData={selectedCard || clothingCards[0]}
                  onBack={() => setShowLedger(false)}
                  onPrint={() => window.print()}
                /> */}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default ClothingCards;
