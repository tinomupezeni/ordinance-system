import SummaryCard from "@/components/SummaryCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Form51B from "@/forms/Form51B";
import { FileCheck, FileText, Plus, Search } from "lucide-react";
import React, { useState } from "react";
import Form227Transactions from "../cadex/DamagedStock227";
import Book2Entries from "../loans/Book2Entries";
import Form57 from "@/forms/Form57";
import { toast } from "sonner";
import Server from "@/server/Server";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useNavigate } from "react-router-dom";
import ClothingCardsIssues from "../issues/IssuesClothingCards";
import ClothingCards from "./ClothingCards";
import ClothingCardViewer from "@/formPdfs/ClothingCardViewer";

export default function CardingDash({
  allClothingItems,
  dashboardData,
  forms227,
  updateDashboardData,
}) {
  const [activeCardingForm, setActiveCardingForm] = useState<string | null>(
    null
  );
  const navigate = useNavigate();
  const [searchForceNumber, setSearchForceNumber] = useState("");

  // Add these state variables to CardingDash
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{
    category: string;
    item?: string;
  } | null>(null);

  // Add this delete handler function
  const handleDeleteItem = async () => {
    if (!itemToDelete) return;

    try {
      await Server.deleteClothingItem(itemToDelete.category, itemToDelete.item);
      toast.success(
        itemToDelete.item
          ? `Item "${itemToDelete.item}" deleted successfully!`
          : `Category "${itemToDelete.category}" deleted successfully!`
      );
      updateDashboardData();
    } catch (error) {
      toast.error("Failed to delete item: " + (error as Error).message);
    } finally {
      setDeleteConfirmOpen(false);
      setItemToDelete(null);
    }
  };

  const [cardingSelectedOption, setCardingSelectedOption] = useState(true);
  const handleCardingViewAll = (formType: string) => {
    setActiveCardingForm(formType);
    setCardingSelectedOption(false);
  };

  const cardingForms = {
    "Form 227": <Form227Transactions items={forms227} />,
    Book2: <Book2Entries />,
    "Form 57": <ClothingCards />,
  };

  const cardingData = [
    {
      title: "Form 227 ",
      count: dashboardData?.form227?.total,
      color: "bg-blue-100 border border-blue-200",
      icon: <FileText className="text-blue-500" />,
      formType: "Form 227",
      notify: 3,
    },
    {
      title: "Clothing Card Records [Form 51]",
      count: dashboardData?.clothing_cards?.total,
      color: "bg-green-100 border border-green-200",
      icon: <FileCheck className="text-green-500" />,
      formType: "Form 57",
    },
  ];

  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategory, setNewCategory] = useState("");

  const [newEntryData, setNewEntryData] = useState({
    category: "",
    itemName: "",
    lifespan: "",
  });

  const handleCategoryChange = (value) => {
    if (value === "__new__") {
      setIsAddingCategory(true);
      setNewEntryData((prev) => ({ ...prev, category: newCategory }));
    } else {
      setIsAddingCategory(false);
      setNewEntryData((prev) => ({ ...prev, category: value }));
    }
  };

  const handleSubmit = () => {
    const finalCategory = isAddingCategory
      ? newCategory
      : newEntryData.category;

    if (!finalCategory || !newEntryData.itemName || !newEntryData.lifespan) {
      toast.error("Please fill in all fields.");
      return;
    }

    console.log("Submitting new entry:", { newEntryData });

    Server.addNewClothingItem(newEntryData)
      .then(() => {
        toast.success("New clothing item added successfully!");
        updateDashboardData();
        // Clear form
        setNewEntryData({ category: "", itemName: "", lifespan: "" });
        setIsAddingCategory(false);
        setNewCategory("");
      })
      .catch((error) => {
        console.error("Error adding new clothing item:", error);
        toast.error(
          "Failed to add new clothing item: " + (error.message || "")
        );

        if (
          error.message === "Failed to refresh token" ||
          error.message?.toLowerCase().includes("refresh")
        ) {
          // Token refresh failed, so force logout
          localStorage.removeItem("access_token");
          localStorage.removeItem("refresh_token");
          navigate("/login"); // or '/'
        }
      });

    //     // console.log(newEntryData);
  };

  const handleCancel = () => {
    setNewEntryData({ category: "", itemName: "", lifespan: "" });
    setIsAddingCategory(false);
    setNewCategory("");
  };

 const [searchOfficeData, setSearchOfficerData] = useState()

  const handleSearch = async () => {
    if (!searchForceNumber.trim()) {
      alert("Please enter a force number");
      return;
    }

    try {
      // Replace with your actual API endpoint
      const response = Server.getOfficerByForceNo(searchForceNumber);

      if (!response.ok) {
        toast.error("Failed to fetch officer data");
      }

      const data = await response;
      // Handle the response data (e.g., display in your UI)
      console.log("Officer data:", data);
      setSearchOfficerData(data)
      setCardingSelectedOption(false)

      // You might want to pass this data to a parent component or update state
    } catch (error) {
      console.error("Error searching for officer:", error);
      toast.error("Error searching for officer. Please try again.");
    }
  };

  return (
    <div>
      <>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6 mt-5">
          {cardingData.map((item, index) => (
            <SummaryCard
              key={index}
              title={item.title}
              count={item.count}
              color={item.color}
              icon={item.icon}
              notify={item.notify}
              onViewAll={() => handleCardingViewAll(item.formType)}
            />
          ))}
        </div>
        <div className="my-8 p-4 bg-white shadow rounded-lg flex flex-col sm:flex-row sm:items-end gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Search Form 51 by Officer's Force Number
            </label>
            <Input
              placeholder="e.g. ZRP-1223"
              className="w-full"
              value={searchForceNumber}
              onChange={(e) => setSearchForceNumber(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
          </div>

          <Button
            className="self-start sm:self-auto bg-blue-600 hover:bg-blue-700 text-white"
            onClick={handleSearch}
          >
            <Search className="mr-2 h-4 w-4" />
            Search
          </Button>

          <Button
            className="self-start sm:self-auto bg-green-600 hover:bg-green-700 text-white"
            onClick={() => setCardingSelectedOption(!cardingSelectedOption)}
          >
            <Plus className="mr-2 h-4 w-4" /> New Form 51
          </Button>
        </div>

        {searchOfficeData && (
          <ClothingCardViewer officerData={searchOfficeData} clothingItems={allClothingItems} />
        )}

        {/* Add New Entry Section */}
        {cardingSelectedOption && (
          <div className="bg-white shadow rounded-lg p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4 text-gray-800">
              Add New Entry
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                {!isAddingCategory ? (
                  <select
                    className="w-full p-2 border border-gray-300 rounded"
                    value={newEntryData.category}
                    onChange={(e) => handleCategoryChange(e.target.value)}
                    name="Category"
                  >
                    <option value="" disabled>
                      Select Category
                    </option>
                    {Object.entries(allClothingItems).map(([category]) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                    <option value="__new__">+ Add new category</option>
                  </select>
                ) : (
                  <input
                    type="text"
                    placeholder="Enter new category name"
                    className="w-full p-2 border border-blue-400 rounded"
                    value={newCategory}
                    onChange={(e) => {
                      const value = e.target.value;
                      setNewCategory(value);
                      setNewEntryData((prev) => ({ ...prev, category: value }));
                    }}
                  />
                )}
              </div>
              <Input
                placeholder="Item Name"
                value={newEntryData.itemName}
                onChange={(e) =>
                  setNewEntryData((prev) => ({
                    ...prev,
                    itemName: e.target.value,
                  }))
                }
              />

              <Input
                placeholder="Lifespan in months (e.g 6)"
                type="number"
                value={newEntryData.lifespan}
                onChange={(e) =>
                  setNewEntryData((prev) => ({
                    ...prev,
                    lifespan: e.target.value,
                  }))
                }
              />

              <div className="flex gap-2">
                <Button onClick={handleSubmit}>Done</Button>
                <Button variant="outline" onClick={handleCancel}>
                  Cancel
                </Button>
              </div>
            </div>
            {/* Optional additional logic or save button here */}
            <Form51B
              clothingItems={allClothingItems}
              approveDelete={(category, item) => {
                setItemToDelete({ category, item });
                setDeleteConfirmOpen(true);
              }}
            />
          </div>
        )}

        {activeCardingForm && cardingForms[activeCardingForm]}
      </>

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
            <AlertDialogDescription>
              {itemToDelete?.item
                ? `Are you sure you want to delete "${itemToDelete.item}" from "${itemToDelete.category}"?`
                : `Are you sure you want to delete the entire category "${itemToDelete?.category}" and all its items?`}
              <br />
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={handleDeleteItem}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
