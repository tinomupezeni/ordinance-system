import { useState } from "react";
import Form109 from "@/forms/Form109";

const IncomingStockEntryForm = () => {
  // State to track selected button
  const [selectedOption, setSelectedOption] = useState<"bulk_stock" | "made_to_measure" | "loan">("bulk_stock");

  return (
    <div className="bg-white p-6 rounded-xl shadow mb-6 flex flex-col">
      <h2 className="text-lg font-semibold mb-4">📦 Record Incoming Stock</h2>
      
      {/* Button Group */}
      <div className="flex gap-4 mb-6">
        <button
          className={`px-4 py-2 rounded-lg border transition-all ${
            selectedOption === "bulk_stock"
              ? "bg-blue-600 text-white border-blue-600"
              : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
          }`}
          onClick={() => setSelectedOption("bulk_stock")}
        >
          Incoming Bulk Stock
        </button>
        <button
          className={`px-4 py-2 rounded-lg border transition-all ${
            selectedOption === "made_to_measure"
              ? "bg-blue-600 text-white border-blue-600"
              : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
          }`}
          onClick={() => setSelectedOption("made_to_measure")}
        >
          Incoming Made-to-Measure
        </button>
        <button
          className={`px-4 py-2 rounded-lg border transition-all ${
            selectedOption === "loan"
              ? "bg-blue-600 text-white border-blue-600"
              : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
          }`}
          onClick={() => setSelectedOption("loan")}
        >
          Loan
        </button>
      </div>

      {/* Form Container */}
      <div className="flex justify-center">
        <Form109 stockType={selectedOption} />
      </div>
    </div>
  );
};

export default IncomingStockEntryForm;