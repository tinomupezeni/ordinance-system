import React, { useState } from "react";
import { CheckCircle, Clock, XCircle, Eye, X, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import Form163Pdf from "@/formPdfs/Form163Pdf";
// No need to import Server and toast directly here if no API call is made within this component for preview
// import Server from "@/server/Server";
// import { toast } from "sonner";

// --- Type Definitions ---
// This type should now represent the *full* data structure for a Form 163
// as it comes from your backend and as Form163Pdf expects it.
// It effectively combines Form163Entry and Form163PdfData from the previous example.
interface FullForm163Data {
  id: number;
  created_by: string;
  created_at: string;
  updated_at: string;
  officer_in_charge_approved: "WAITING" | "APPROVED" | "REJECTED";
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  items: any[]; // Adjust with actual RequisitionItem163Data type if you have it
  requestedBy: { initials: string; date: string }; // Assuming this structure is present in your forms163 data
  issuedBy: { initials: string; date: string };    // Assuming this structure is present in your forms163 data
  receivedBy: { initials: string; date: string };  // Assuming this structure is present in your forms163 data
  ledgerActionedBy: { initials: string; date: string }; // Assuming this structure is present in your forms163 data
  // Add any other fields Form163Pdf expects that are part of your full form data
}

interface Form163DispatchesProps {
  forms163: FullForm163Data[]; // The prop now expects the full data for each form
}

const Form163Dispatches: React.FC<Form163DispatchesProps> = ({ forms163 }) => {
  const [showPreview, setShowPreview] = useState(false);
  const [previewFormData, setPreviewFormData] = useState<FullForm163Data | null>(null);

  // Helper function to render status badges with styling
  const getStatusBadge = (status: "WAITING" | "APPROVED" | "REJECTED") => {
    switch (status) {
      case "APPROVED":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-green-100 text-green-800 font-medium capitalize">
            <CheckCircle className="w-4 h-4" />
            {status.toLowerCase()}
          </span>
        );
      case "REJECTED":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-red-100 text-red-800 font-medium capitalize">
            <XCircle className="w-4 h-4" />
            {status.toLowerCase()}
          </span>
        );
      case "WAITING":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-3 rounded-full bg-yellow-100 text-yellow-800 font-medium capitalize">
            <Clock className="w-4 h-4" />
            {status.toLowerCase()}
          </span>
        );
      default:
        return <span className="capitalize">{status.toLowerCase()}</span>;
    }
  };

  // MODIFIED: Find form data directly from the forms163 prop
  const handleViewForm = (formId: number) => {
    const selectedForm = forms163.find(form => form.id === formId);
    if (selectedForm) {
      setPreviewFormData(selectedForm);
      setShowPreview(true);
    } else {
      // You might want to use toast here if you still have it,
      // or simply console.error if this scenario should theoretically not happen.
      console.error(`Form with ID ${formId} not found in the list.`);
      // toast.error("Selected form data not found."); // Uncomment if toast is available
    }
  };

  const handleBackToTable = () => {
    setShowPreview(false);
    setPreviewFormData(null); // Clear data when going back
  };

  const handlePrintPreview = () => {
    window.print();
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow mb-6">
      <h2 className="font-bold text-lg mb-3">Form 163 - Dispatch Log</h2>
      <div className="overflow-x-auto">
        {showPreview && previewFormData ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <Button
                variant="ghost"
                onClick={handleBackToTable}
                className="flex items-center gap-2 text-gray-600"
              >
                <X className="w-4 h-4" />
                Back to list
              </Button>
              <Button
                variant="default"
                onClick={handlePrintPreview}
                className="flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                Print Form
              </Button>
            </div>

            <div className="mt-4">
              <Form163Pdf
                formData={previewFormData} // Pass the found data
                onBack={handleBackToTable}
                onPrint={handlePrintPreview}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full table-auto text-sm">
            <thead>
              <tr className="border-b">
                <th className="py-2 px-4 text-left">Form ID</th>
                <th className="py-2 px-4 text-left">Number of Items</th>
                <th className="py-2 px-4 text-left">Status</th>
                <th className="py-2 px-4 text-left">Date Created</th>
                <th className="py-2 px-4 text-left">Action</th>
              </tr>
            </thead>
            <tbody>
              {forms163?.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-500">
                    No Form 163 dispatches found.
                  </td>
                </tr>
              ) : (
                forms163.map((entry) => (
                  <tr key={entry.id} className="border-b hover:bg-gray-50">
                    <td className="py-2 px-4">{entry.id}</td>
                    <td className="py-2 px-4">{entry.items.length}</td>
                    <td className="py-2 px-4">
                      {getStatusBadge(entry.officer_in_charge_approved)}
                    </td>
                    <td className="py-2 px-4">
                      {new Date(entry.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-2 px-4">
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                        onClick={() => handleViewForm(entry.id)} // Call local handler
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Form163Dispatches;