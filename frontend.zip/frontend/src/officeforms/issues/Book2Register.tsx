import { Button } from "@/components/ui/button";
import Book2Pdf from "@/formPdfs/Book2Pdf";
import { Edit, Trash2, Eye, Plus, Check } from "lucide-react";
import { useState } from "react";

const Book2Register = () => {
  const [entries, setEntries] = useState([
    { 
      id: 1, 
      item: "Trousers Mat", 
      quantity: 100, 
      issuedTo: "ZRP Hillside", 
      date: "2025-05-01",
      status: "Completed"
    },
    { 
      id: 2, 
      item: "Cap STU", 
      quantity: 40, 
      issuedTo: "ZRP Avondale", 
      date: "2025-04-30",
      status: "Completed"
    },
    { 
      id: 3, 
      item: "Jacket Mat", 
      quantity: 25, 
      issuedTo: "ZRP Mbare", 
      date: "2025-05-02",
      status: "Pending"
    },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [currentEntry, setCurrentEntry] = useState(null);

  const viewEntry = (entry) => {
    setCurrentEntry(entry);
    setShowForm(true);
  };

  const handleEdit = (entryId) => {
    // Edit logic here
    console.log("Editing entry:", entryId);
  };

  const handleDelete = (entryId) => {
    setEntries(prev => prev.filter(entry => entry.id !== entryId));
  };

  const handleApprove = (entryId) => {
    setEntries(prev =>
      prev.map(entry =>
        entry.id === entryId ? { ...entry, status: "Completed" } : entry
      )
    );
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          Book 2 Dispatch Register
        </h2>
       
      </div>
      
      <div className="overflow-x-auto">
        {showForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setShowForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  Back to list
                </Button>
              </div>
              {currentEntry?.status === "Pending" && (
                <div className="flex gap-3">
                  <Button
                    variant="destructive"
                    onClick={() => handleDelete(currentEntry.id)}
                    className="flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Reject
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => handleApprove(currentEntry.id)}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </Button>
                </div>
              )}
            </div>
            {/* Entry detail view would go here */}
            <div className="mt-4 p-4">
            
              <Book2Pdf
                formData={entries}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            
            </div>
          </div>
        ) : (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issued To</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {entries.map((entry) => (
                <tr key={entry.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{entry.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{entry.item}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{entry.quantity}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{entry.issuedTo}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        entry.status === "Completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {entry.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewEntry(entry)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(entry.id)}
                      className="flex items-center gap-1"
                    >
                      <Edit className="w-4 h-4" />
                      Edit
                    </Button>
                    {entry.status === "Pending" && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => handleDelete(entry.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Book2Register;