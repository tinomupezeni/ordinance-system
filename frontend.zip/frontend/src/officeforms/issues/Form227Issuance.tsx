import { Button } from "@/components/ui/button";
import Form227Pdf from "@/formPdfs/Form227Pdf";
import Server from "@/server/Server";
import { Eye, Printer, Plus, X, CheckCircle2Icon, CheckCircle, XCircle, Clock } from "lucide-react";
import { log } from "node:console";
import { useEffect, useState } from "react";

const Form227IssuanceLog = () => {


  const [issuanceLogs, setIssuanceLogs] = useState([]);

  const [openForm, setOpenForm] = useState(false);
  const [currentIssuance, setCurrentIssuance] = useState(null);
  const [formData, setFormData] = useState();

  const viewIssuance = (id) => {
  const foundIssuance = issuanceLogs.find((item) => item.id === id);
  if (foundIssuance) {
    setCurrentIssuance(foundIssuance);
    setFormData(foundIssuance); // No need to filter if you just want the single item
    setOpenForm(true);
  } else {
    console.error(`No issuance found with id: ${id}`);
    // Optionally handle the not-found case (show error, etc.)
  }
};

  const getForm227 = () => {
    Server.getForms('form227').then((response) => {
      console.log(response);
      setIssuanceLogs(response.results)
      
    }).catch((error) => {
      console.log(error);
      
    })
  }

  useEffect(() => {
    getForm227()
  }, [])

  const handlePrint = (issuanceId) => {
    // Print logic would go here
    console.log("Printing issuance:", issuanceId);

    // fetch form data based on formId
    Server.getForm227(issuanceId)
      .then((response) => {
        setFormData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Form 227 Issuance Log</h2>
      </div>

      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <Button
                variant="ghost"
                onClick={() => setOpenForm(false)}
                className="flex items-center gap-2 text-gray-600"
              >
                <X className="w-4 h-4" />
                Back to list
              </Button>
              <Button
                variant="default"
                onClick={() => handlePrint(currentIssuance.id)}
                className="flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                Print Form
              </Button>
            </div>

            <div className="mt-4">
              <Form227Pdf
                formData={formData}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Form #
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date Issued
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Station
                </th>
                
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {issuanceLogs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {log.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {log.date}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {log.station}
                  </td>
                
                  <td className="px-6 py-4 whitespace-nowrap flex-col space-y-2">
  {/* Officer-in-Charge Status */}
  <span
    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
      log.office_in_charge_status === 'approved'
        ? 'bg-green-100 text-green-800'
        : log.office_in_charge_status === 'rejected'
        ? 'bg-red-100 text-red-800'
        : 'bg-yellow-100 text-yellow-800'
    }`}
  >
    {log.office_in_charge_status === 'approved' ? (
      <CheckCircle className="w-4 h-4" />
    ) : log.office_in_charge_status === 'rejected' ? (
      <XCircle className="w-4 h-4" />
    ) : (
      <Clock className="w-4 h-4" />
    )}
    Officer-in-Charge: {log.office_in_charge_status.charAt(0).toUpperCase() + 
                       log.office_in_charge_status.slice(1)}
  </span>

  {/* Carding Status */}
  <span
    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
      log.carding_status === 'approved'
        ? 'bg-green-100 text-green-800'
        : log.carding_status === 'rejected'
        ? 'bg-red-100 text-red-800'
        : 'bg-yellow-100 text-yellow-800'
    }`}
  >
    {log.carding_status === 'approved' ? (
      <CheckCircle className="w-4 h-4" />
    ) : log.carding_status === 'rejected' ? (
      <XCircle className="w-4 h-4" />
    ) : (
      <Clock className="w-4 h-4" />
    )}
    Carding: {log.carding_status.charAt(0).toUpperCase() + 
                       log.carding_status.slice(1)}
  </span>
</td>

                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewIssuance(log.id)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Form227IssuanceLog;
