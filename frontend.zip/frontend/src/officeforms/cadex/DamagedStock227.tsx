import { Button } from "@/components/ui/button";
import Form227Pdf from "@/formPdfs/Form227Pdf";
import { FileText, Eye, Check, Ban, X, CheckCircle, XCircle, Clock } from "lucide-react";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import Server from "@/server/Server";
import { toast } from "sonner";

const Form227Transactions = ({ items }) => {
  // Static data for Form 227 transactions
  const [displayItems, setDisplayItems] = useState(
    items
  );
  
  
  const [openForm, setOpenForm] = useState(false);
  const [showApproveConfirm, setShowApproveConfirm] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState(null);

  const viewForm = (transaction) => {
    setCurrentTransaction(transaction);
    setOpenForm(true);
  };

  const handleComplete = (transactionId) => {
    setDisplayItems(prev =>
      prev.map(item =>
        item.id === transactionId ? { ...item, status: "Completed" } : item
      )
    );
    setOpenForm(false);
    setShowApproveConfirm(true)
  };

   const handleApprove = (formId) => {
    if (formId !== null) {
      
      Server.cardingAuthorizeForm227(formId).then(() => {
      setShowApproveConfirm(false);
      }).catch((error) => {
        toast.error('An error occurred: ' + (error?.message || 'Unknown error'));
console.error(error);

        console.log(error);
        
      })
    }
    setShowApproveConfirm(false)
  };

  const handleCancel = (transactionId) => {
    setDisplayItems(prev =>
      prev.map(item =>
        item.id === transactionId ? { ...item, status: "Cancelled" } : item
      )
    );
    setOpenForm(false);
  };

  return (
    <div className="bg-white p-4 shadow rounded-lg mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <FileText className="text-blue-500" /> Form 227 - Stock Transactions
        </h2>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setOpenForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  <X className="w-4 h-4" />
                  Back to list
                </Button>
              </div>
              {currentTransaction?.carding_status === "awaiting" && (
                <div className="flex gap-3">
                  <Button
                    variant="destructive"
                    onClick={() => handleCancel(currentTransaction.id)}
                    className="flex items-center gap-2"
                  >
                    <Ban className="w-4 h-4" />
                    Reject
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => handleComplete(currentTransaction.id)}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </Button>
                </div>
              )}
            </div>

            <div className="mt-4">
              <Form227Pdf
                formData={currentTransaction}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b">
                <th className="py-3 px-4 text-left">Form id #</th>
                <th className="py-3 px-4 text-left">Date</th>
                <th className="py-3 px-4 text-left">Form Type</th>
                <th className="py-3 px-4 text-left">Station</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayItems.map((transaction) => (
                <tr key={transaction.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium">
                    {transaction.id}
                  </td>
                  <td className="py-3 px-4">{transaction.date}</td>
                  <td className="py-3 px-4 capitalize">{transaction.formType}</td>
                  <td className="py-3 px-4">{transaction.station}</td>
                            <td className="px-6 py-4 whitespace-nowrap flex-col space-y-2">
  {/* Officer-in-Charge Status */}
  <span
    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
      transaction.carding_status === 'approved'
        ? 'bg-green-100 text-green-800'
        : transaction.carding_status === 'rejected'
        ? 'bg-red-100 text-red-800'
        : 'bg-yellow-100 text-yellow-800'
    }`}
  >
    {transaction.carding_status === 'approved' ? (
      <CheckCircle className="w-4 h-4" />
    ) : transaction.carding_status === 'rejected' ? (
      <XCircle className="w-4 h-4" />
    ) : (
      <Clock className="w-4 h-4" />
    )}
    Carding Approval: {transaction.carding_status.charAt(0).toUpperCase() + 
                       transaction.carding_status.slice(1)}
  </span>

 
</td>
                  <td className="py-3 px-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewForm(transaction)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                    {transaction.status === "Pending" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => handleCancel(transaction.id)}
                        >
                          Cancel
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => handleComplete(transaction.id)}
                        >
                          Complete
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      <div className="mt-4 flex justify-between items-center text-sm text-gray-500">
        <div>
          Showing {displayItems.length} of {displayItems.length} transactions
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled>
            Previous
          </Button>
          <Button variant="outline" size="sm" disabled>
            Next
          </Button>
        </div>
      </div>
      {/* Approval Confirmation Dialog */}
      <AlertDialog
  open={showApproveConfirm}
  onOpenChange={setShowApproveConfirm}
>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>Confirm Approval</AlertDialogTitle>
      <AlertDialogDescription>
        Are you sure you want to approve this form? This action cannot be
        undone.
      </AlertDialogDescription>
    </AlertDialogHeader>
    <AlertDialogFooter>
      <AlertDialogCancel>Cancel</AlertDialogCancel>
      <AlertDialogAction
        className="bg-green-600 hover:bg-green-700"
        onClick={() => handleApprove(currentTransaction?.id)}
      >
        Approve
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
    </div>
  );
};

export default Form227Transactions;