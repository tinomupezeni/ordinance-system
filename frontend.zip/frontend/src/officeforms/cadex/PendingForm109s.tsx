import { Button } from "@/components/ui/button";
import Form109Pdf from "@/formPdfs/Form109Pdf";
import { ClipboardList, Eye, Check, Ban, X } from "lucide-react";
import { useState } from "react";

const PendingForm109s = ({ forms }) => {
  // Static data for Form 109 orders
  const [displayForms, setDisplayForms] = useState(
    forms || [
      {
        id: 1,
        formNumber: "109-2023-001",
        date: "2023-05-10",
        receivedFrom: "Harare Central Armory",
        itemsReceived: "Trousers (50), Jackets (30)",
        status: "Pending Verification",
      },
      {
        id: 2,
        formNumber: "109-2023-002",
        date: "2023-05-11",
        receivedFrom: "Bulawayo Main Depot",
        itemsReceived: "Shirts (100), Caps (80)",
        status: "Partially Received",
      },
      {
        id: 3,
        formNumber: "109-2023-003",
        date: "2023-05-12",
        receivedFrom: "Mutare Regional Store",
        itemsReceived: "Boots (60), Belts (45)",
        status: "Verified",
      },
      {
        id: 4,
        formNumber: "109-2023-004",
        date: "2023-05-13",
        receivedFrom: "Gweru Central Warehouse",
        itemsReceived: "Raincoats (25), Flashlights (30)",
        status: "Pending Verification",
      },
      {
        id: 5,
        formNumber: "109-2023-005",
        date: "2023-05-14",
        receivedFrom: "Masvingo Supply Depot",
        itemsReceived: "Jerseys (45), Socks (90)",
        status: "Discrepancy Found",
      },
      {
        id: 6,
        formNumber: "109-2023-006",
        date: "2023-05-15",
        receivedFrom: "Chitungwiza Station",
        itemsReceived: "Boots (25), Gloves (50)",
        status: "Completed",
      },
    ]
  );

  const [openForm, setOpenForm] = useState(false);
  const [currentForm, setCurrentForm] = useState(null);

  const viewForm = (form) => {
    setCurrentForm(form);
    setOpenForm(true);
  };

  const handleVerify = (formId) => {
    setDisplayForms(prev =>
      prev.map(form =>
        form.id === formId ? { ...form, status: "Verified" } : form
      )
    );
    setOpenForm(false);
  };

  const handleReject = (formId) => {
    setDisplayForms(prev =>
      prev.map(form =>
        form.id === formId ? { ...form, status: "Rejected" } : form
      )
    );
    setOpenForm(false);
  };

  return (
    <div className="bg-white p-4 shadow rounded-lg mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <ClipboardList className="text-green-500" /> Form 109 - Incoming Orders
        </h2>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setOpenForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  <X className="w-4 h-4" />
                  Back to list
                </Button>
              </div>
              {currentForm?.status === "Pending Verification" && (
                <div className="flex gap-3">
                  <Button
                    variant="destructive"
                    onClick={() => handleReject(currentForm.id)}
                    className="flex items-center gap-2"
                  >
                    <Ban className="w-4 h-4" />
                    Reject Order
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => handleVerify(currentForm.id)}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4" />
                    Verify Order
                  </Button>
                </div>
              )}
            </div>

            <div className="mt-4">
              <Form109Pdf
                formData={currentForm}
                onBack={() => setOpenForm(false)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b">
                <th className="py-3 px-4 text-left">Form #</th>
                <th className="py-3 px-4 text-left">Date</th>
                <th className="py-3 px-4 text-left">Received From</th>
                <th className="py-3 px-4 text-left">Items Received</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayForms.map((order) => (
                <tr key={order.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium">{order.formNumber}</td>
                  <td className="py-3 px-4">{order.date}</td>
                  <td className="py-3 px-4">{order.receivedFrom}</td>
                  <td className="py-3 px-4">{order.itemsReceived}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        order.status === "Verified"
                          ? "bg-green-100 text-green-800"
                          : order.status === "Completed"
                          ? "bg-blue-100 text-blue-800"
                          : order.status === "Partially Received"
                          ? "bg-yellow-100 text-yellow-800"
                          : order.status === "Discrepancy Found" || order.status === "Rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewForm(order)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                    {order.status === "Pending Verification" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => handleReject(order.id)}
                        >
                          Reject
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => handleVerify(order.id)}
                        >
                          Verify
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      <div className="mt-4 flex justify-between items-center text-sm text-gray-500">
        <div>
          Showing {displayForms.length} of {displayForms.length} forms
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled>
            Previous
          </Button>
          <Button variant="outline" size="sm" disabled>
            Next
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PendingForm109s;