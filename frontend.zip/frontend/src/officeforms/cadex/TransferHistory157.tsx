import { Button } from "@/components/ui/button";
import { Ban, Check, X, Eye } from "lucide-react";
import { useState } from "react";

const Form57Ledger = () => {
  const [form57Transactions, setForm57Transactions] = useState([
    { 
      id: 1, 
      officer: "Sergeant L. Dube", 
      item: "Binoculars", 
      transactionDate: "2025-04-15", 
      transactionType: "Pending",
      quantity: 1,
      reference: "ORD/2025/015"
    },
    { 
      id: 2, 
      officer: "Inspector Chari", 
      item: "Walkie Talkie", 
      transactionDate: "2025-04-18", 
      transactionType: "Approved",
      quantity: 2,
      reference: "ORD/2025/018"
    },
    { 
      id: 3, 
      officer: "Constable Moyo", 
      item: "First Aid Kit", 
      transactionDate: "2025-04-20", 
      transactionType: "Pending",
      quantity: 1,
      reference: "ORD/2025/022"
    },
  ]);

  const [openForm, setOpenForm] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);

  const viewForm = (transaction) => {
    setCurrentTransaction(transaction);
    setOpenForm(true);
  };

  const confirmAction = (action) => {
    setPendingAction(action);
    setShowConfirmDialog(true);
  };

  const executeAction = () => {
    if (pendingAction === 'approve') {
      handleApprove(currentTransaction.id);
    } else if (pendingAction === 'reject') {
      handleReject(currentTransaction.id);
    }
    setShowConfirmDialog(false);
  };

  const handleApprove = (transactionId) => {
    setForm57Transactions(prev =>
      prev.map(transaction =>
        transaction.id === transactionId ? { ...transaction, transactionType: "Approved" } : transaction
      )
    );
    setOpenForm(false);
  };

  const handleReject = (transactionId) => {
    setForm57Transactions(prev =>
      prev.map(transaction =>
        transaction.id === transactionId ? { ...transaction, transactionType: "Rejected" } : transaction
      )
    );
    setOpenForm(false);
  };

  return (
    <div className="bg-white p-4 shadow rounded mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">
          Form 57 - Ordnance Ledger Cards
        </h2>
      </div>
      
      <div className="overflow-x-auto">
        {openForm ? (
          <div className="relative">
            <div className="sticky top-0 bg-white py-4 flex justify-between items-center border-b z-10">
              <div>
                <Button
                  variant="ghost"
                  onClick={() => setOpenForm(false)}
                  className="flex items-center gap-2 text-gray-600"
                >
                  <X className="w-4 h-4" />
                  Back to list
                </Button>
              </div>
              {currentTransaction?.transactionType === "Pending" && (
                <div className="flex gap-3">
                  <Button
                    variant="destructive"
                    onClick={() => confirmAction('reject')}
                    className="flex items-center gap-2"
                  >
                    <Ban className="w-4 h-4" />
                    Reject Transaction
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => confirmAction('approve')}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4" />
                    Approve Transaction
                  </Button>
                </div>
              )}
            </div>

            <div className="mt-4 p-4 border rounded">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Reference Number</p>
                  <p className="font-medium">{currentTransaction?.reference}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Officer</p>
                  <p className="font-medium">{currentTransaction?.officer}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Item</p>
                  <p className="font-medium">{currentTransaction?.item}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Quantity</p>
                  <p className="font-medium">{currentTransaction?.quantity}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Transaction Date</p>
                  <p className="font-medium">{currentTransaction?.transactionDate}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <p className={`font-medium ${
                    currentTransaction?.transactionType === "Approved" ? "text-green-600" :
                    currentTransaction?.transactionType === "Rejected" ? "text-red-600" :
                    "text-yellow-600"
                  }`}>
                    {currentTransaction?.transactionType}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b">
                <th className="py-3 px-4 text-left">Reference</th>
                <th className="py-3 px-4 text-left">Officer</th>
                <th className="py-3 px-4 text-left">Item</th>
                <th className="py-3 px-4 text-left">Quantity</th>
                <th className="py-3 px-4 text-left">Date</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {form57Transactions.map((transaction) => (
                <tr key={transaction.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4">{transaction.reference}</td>
                  <td className="py-3 px-4">{transaction.officer}</td>
                  <td className="py-3 px-4">{transaction.item}</td>
                  <td className="py-3 px-4">{transaction.quantity}</td>
                  <td className="py-3 px-4">{transaction.transactionDate}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        transaction.transactionType === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : transaction.transactionType === "Rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {transaction.transactionType}
                    </span>
                  </td>
                  <td className="py-3 px-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewForm(transaction)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                    {transaction.transactionType === "Pending" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => confirmAction('reject')}
                        >
                          Reject
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={() => confirmAction('approve')}
                        >
                          Approve
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Confirmation Dialog */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h3 className="text-lg font-semibold mb-4">
              {pendingAction === 'approve' ? 'Approve Transaction' : 'Reject Transaction'}
            </h3>
            <p className="mb-6">
              Are you sure you want to {pendingAction === 'approve' ? 'approve' : 'reject'} this transaction?
              This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirmDialog(false)}
              >
                Cancel
              </Button>
              <Button
                variant={pendingAction === 'approve' ? 'default' : 'destructive'}
                onClick={executeAction}
                className={pendingAction === 'approve' ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                {pendingAction === 'approve' ? 'Approve' : 'Reject'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Form57Ledger;