import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { AlertTriangle, Book, Bookmark, BookOpenText, ClipboardList, File, FileText, FileX, PackageCheck, RefreshCw, Shirt, UserCheck } from "lucide-react";
import { useState } from "react";
import MainLedger from "@/forms/Form51B";
import Form227 from "@/forms/Form227";
import Form163 from "@/forms/Form163";
import Form321 from "@/forms/Form321";
import Form157 from "@/forms/Form157";
import Form109 from "@/forms/Form109";
import Form99 from "@/forms/Form99";
import Book2 from "@/forms/Book2";
import Form57 from "@/forms/Form57";
import RejectionCertificate from "@/forms/RejectionCertificate";
import DischargeCertificate from "@/forms/DischargeCertificate";
import Form226 from "@/forms/Form226";
import TallySheet from "@/forms/TallySheet";

const Index = () => {
  const [openForm, setOpenForm] = useState(false);
  const [selectedForm, setSelectedForm] = useState("");

  const handleFormPreview = (form) => {
    setSelectedForm(form);
    setOpenForm(true);
  };

  const renderFormComponent = () => {
    switch (selectedForm) {
      case "FORM 227":
        return <Form227 />;
      case "FORM 163":
        return <Form163 />;
      case "FORM 321":
        return <Form321 />;
      case "FORM 157":
        return <Form157 />;
      case "FORM 109":
        return <Form109 />;
      case "FORM 99":
        return <Form99 />;
      case "FORM 57":
        return <Form57 />;
      case "Tally Sheet":
        return <TallySheet />;
      case "Book 2":
        return <Book2 />;
      case "FORM 226":
        return <Form226 />;
      case "Rejection Certificate":
        return <RejectionCertificate />;
      case "Discharge Certificate":
        return <DischargeCertificate />;
      default:
        return <MainLedger />;
    }
  };

  const forms = [
    {
      name: "Main ledger",
      icon: BookOpenText, // Better for ledgers/books
      form: "Tally Sheet",
      btn_color: "bg-blue-600",
      color: "bg-blue-100",
    },
    {
      name: "Ordinance Store Requisition - Issue Voucher",
      icon: ClipboardList, // For requisition forms
      form: "FORM 227",
      btn_color: "bg-indigo-600",
      color: "bg-indigo-100",
    },
    {
      name: "Requisition On Bulk Store",
      icon: ClipboardList, // Consistent for requisitions
      form: "FORM 163",
      btn_color: "bg-purple-600",
      color: "bg-purple-100",
    },
    {
      name: "Exchange Voucher",
      icon: RefreshCw, // Represents exchange/transfer
      form: "FORM 157",
      btn_color: "bg-orange-500",
      color: "bg-orange-100",
    },
    {
      name: "Ordnance Ledger",
      icon: Bookmark, // Alternative ledger icon
      form: "FORM 57",
      btn_color: "bg-teal-600",
      color: "bg-teal-100",
    },
    {
      name: "Ordnance Store Receipt Voucher",
      icon: PackageCheck, // For receipt confirmation
      form: "FORM 109",
      btn_color: "bg-green-700",
      color: "bg-green-200",
    },
    {
      name: "Report Of Missing/Damaged Equipment",
      icon: AlertTriangle, // For reports/issues
      form: "FORM 321",
      btn_color: "bg-red-600",
      color: "bg-red-100",
    },
    {
      name: "Kit Handed In On Discharge",
      icon: Shirt, // Represents clothing/kit
      form: "FORM 99",
      btn_color: "bg-blue-600",
      color: "bg-blue-100",
    },
    {
      name: "Issue Voucher",
      icon: FileText, // General voucher/document
      form: "Book 2",
      btn_color: "bg-blue-600",
      color: "bg-blue-100",
    },
    {
      name: "Ordnance Stores Rejection Certificate",
      icon: FileX, // For rejection documents
      form: "Rejection Certificate",
      btn_color: "bg-blue-600",
      color: "bg-blue-100",
    },
    {
      name: "ZRP Certificate Discharge",
      icon: UserCheck, // For personnel discharge
      form: "Discharge Certificate",
      btn_color: "bg-blue-600",
      color: "bg-blue-100",
    },
    {
      name: "Clothing Card",
      icon: Shirt, // Consistent with clothing/kit
      form: "FORM 51",
      btn_color: "bg-blue-600",
      color: "bg-blue-100",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 ml-72 mt-20">
          <div className="mb-6 flex justify-between w-[50%] border-t-1 mx-auto">
            <h1 className="text-2xl font-bold mb-2">Forms</h1>
            <Button onClick={() => setOpenForm(false)}>All forms</Button>
          </div>
          {!openForm ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {forms.map((form) => {
                const Icon = form.icon;
                return (
                  <Card
                    className={`${form.color} hover:shadow-md transition-shadow cursor-pointer`}
                    onClick={() => handleFormPreview(form.form)}
                  >
                    <CardContent className="flex items-center p-6">
                      <div className={`${form.btn_color} p-3 rounded-lg mr-3`}>
                        <Icon />
                      </div>
                      <div className="flex flex-col">
                        <h3 className="font-semibold text-lg">{form.name}</h3>
                        <p className="text-sm text-gray-600">{form.form}</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            renderFormComponent()
          )}
        </main>
      </div>
    </div>
  );
};

export default Index;
