import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import logo from "@/assets/zrp-logo.png";
import { BASE_URL } from "@/constants";
// const BASE_URL = ' http://127.0.0.1:5005'
// const BASE_URL = "http://192.168.80.92:5005"
const Signup = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    
    email: "",
    password: "",
    username: "",
    rank: "",
    first_name: "",
    last_name: "",
    acceptTerms: false,
    office :"",
    province :"",
    station :"",
   
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await axios.post(
        `${BASE_URL}/api/signup/`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 201) {
        toast.success("Account created successfully!");
        navigate("/login");
      }
    } catch (error: any) {
      console.error("Signup error:", error);
      
      let errorMessage = "An error occurred during signup";
      if (error.response) {
        // Handle backend validation errors
        if (error.response.data?.errors) {
          errorMessage = Object.values(error.response.data.errors)
            .flat()
            .join("\n");
        } else if (error.response.data?.message) {
          errorMessage = error.response.data.message;
        }
      } else if (error.request) {
        errorMessage = "No response received from server";
      }

      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="flex justify-center mb-6">
          <Link to="/" className="flex items-center">
            <div className="w-12 h-12 mr-2">
              <img
                src={logo}
                alt="ZRP ABIS"
                className="w-full h-full object-contain"
              />
            </div>
            <h1 className="font-bold text-2xl">
              <span className="text-blue-950">ZRP</span>
              <span className="text-yellow-500">ORDNANCE </span>
            </h1>
          </Link>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">
              Create an account
            </CardTitle>
            <CardDescription className="text-center">
              Enter your details below to create your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="last_name">Surname *</Label>
                <Input
                  id="last_name"
                  name="last_name"
                  placeholder="John Doe"
                  required
                  value={formData.last_name}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="first_name">First Name *</Label>
                <Input
                  id="first_name"
                  name="first_name"
                  type="text"
                  placeholder="ZRP-123"
                  required
                  value={formData.first_name}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="name@example.com"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
              <Label htmlFor="rank">Police Rank *</Label>
              <select
                id="rank"
                name="rank"
                required
                value={formData.rank}
                onChange={handleChange}
                disabled={isLoading}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="">Select your rank</option>
                <option value="Commissioner">Officer-In-Charge</option>
                <option value="Deputy Commissioner">Chief Stuff Officer</option>
                <option value="Assistant Commissioner">Assistant Commissioner</option>
                <option value="Chief Superintendent">Chief Superintendent</option>
                <option value="Superintendent">Superintendent</option>
                <option value="Chief Inspector">Chief Inspector</option>
                <option value="Inspector">Inspector</option>
                <option value="Sergeant">Sergeant</option>
                <option value="Constable">Constable</option>
                <option value="Trainee">Trainee</option>
              </select>
            </div>

              <div className="space-y-2">
                <Label htmlFor="username">Force Number *</Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="ZRP-123"
                  required
                  value={formData.username}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
              <Label htmlFor="office">Office *</Label>
              <select
                id="office"
                name="office"
                required
                value={formData.office}
                onChange={handleChange}
                disabled={isLoading}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="">Select your office</option>
                <option value="Kardex">Kardex</option>
                <option value="Bulk">Bulk</option>
                <option value="Stores">Stores</option>
                <option value="Loans">Loans</option>
                <option value="Audit">Audit</option>
                <option value="Receiving Bay">Receiving Bay</option>
                <option value="Issues">Issues</option>
                <option value="Dispatch">Dispatch</option>
                <option value="Carding">Carding</option>
                <option value="Admin">Admin</option>
                
              </select>
            </div>
              

              <div className="space-y-2">
                <Label htmlFor="province">Province *</Label>
                <Input
                  id="province"
                  name="province"
                  type="text"
                  placeholder="ZRP-123"
                  required
                  value={formData.province}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="station">Station *</Label>
                <Input
                  id="station"
                  name="station"
                  type="text"
                  placeholder="ZRP-123"
                  required
                  value={formData.station}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    required
                    minLength={8}
                    value={formData.password}
                    onChange={handleChange}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  id="terms"
                  name="acceptTerms"
                  type="checkbox"
                  checked={formData.acceptTerms}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  required
                  disabled={isLoading}
                />
                <Label htmlFor="terms" className="text-sm">
                  I agree to the{" "}
                  <Link
                    to="/terms"
                    className="text-blue-600 hover:underline"
                  >
                    terms and conditions
                  </Link>
                </Label>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating account...
                  </>
                ) : (
                  "Create account"
                )}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <div className="text-center text-sm text-gray-600">
              Already have an account?{" "}
              <Link
                to="/login"
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                Sign in
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Signup;