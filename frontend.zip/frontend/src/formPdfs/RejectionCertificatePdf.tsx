import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const RejectionCertificatePdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  return (
    <div className="w-[210mm] min-h-[297mm] mx-auto bg-white p-6 print:p-0 text-black rejectionpdf">
      {/* Form Header */}
      <div className="text-center mb-4 ">
        <p className="font-bold text-2xl">
          Goods Received Register entry No
          <span>
            {formData.entryNo ? (
              <span className="form-entry">{formData.entryNo}</span>
            ) : (
              <span>.........</span>
            )}
          </span>
          /2025
        </p>
        <p className="font-bold">ORDNANCE STORES REJECTION CERTIFICATE</p>
      </div>
      <div className="relative mb-4">
        <p className="absolute right-0 font-bold">
          CERTIFICATE NUMBER{" "}
          <span>
            {formData.certificateNo ? (
              <span className="form-entry">{formData.certificateNo}</span>
            ) : (
              <span>...................</span>
            )}
          </span>
        </p>
      </div>

      <div className="spacing-2 mt-10">
        <div className="flex">
          <p>
            I, Number{" "}
            <span>
              {formData.inspectorInfo.number ? (
                <span className="form-entry">
                  {formData.inspectorInfo.number}
                </span>
              ) : (
                <span>...............................</span>
              )}
            </span>
          </p>
          <p>
            RANK{" "}
            {formData.inspectorInfo.rank ? (
              <span className="form-entry">{formData.inspectorInfo.rank}</span>
            ) : (
              <span>..........................................</span>
            )}
          </p>
          <p>
            NAME{" "}
            {formData.inspectorInfo.name ? (
              <span className="form-entry">{formData.inspectorInfo.name}</span>
            ) : (
              <span>.....................................................</span>
            )}
          </p>
        </div>
        <div className="flex-col">
          <p>
            of <span className="font-bold">PGHQ TAILORS / SADDLERS</span> have
            on this date examined the following items from{" "}
            <span className="font-bold">SUPPLIER</span>
            <span>
              {formData.supplier ? (
                <span className="form-entry">{formData.supplier}</span>
              ) : (
                <span>
                  {" "}
                  ...................................................................................................
                </span>
              )}
            </span>
          </p>
        </div>
      </div>
      <div className="my-5">
        <table className="w-full text-xsm form227">
          <thead>
            <tr className="">
              <th className="">Item</th>
              <th className="">Qty</th>
              <th className="">D/Note</th>
              <th className="">Order No.</th>
              <th className="">Rejected</th>
              <th className="">Accepted</th>
              <th className="">Value</th>
            </tr>
          </thead>
          <tbody>
            {formData?.items &&
            formData?.items.some((item: any) => item.article !== "")
              ? formData?.items.map((item: any) => (
                  <tr key={item.id} className="form-rows">
                    <td className="">{item.item}</td>
                    <td className="">{item.qty}</td>
                    <td className="">{item.dNote}</td>
                    <td className="">{item.orderNo}</td>
                    <td className="">{item.rejected}</td>
                    <td className="">{item.accepted}</td>
                    <td className="">{item.value}</td>
                  </tr>
                ))
              : Array.from({ length: 5 }).map((_, index) => (
                  <tr key={`empty-row-${index}`} className="form-rows">
                    <td className="h-7"></td>
                    <td className=""></td>
                    <td className=""></td>
                    <td className=""></td>
                    <td className=""></td>
                    <td className=""></td>
                    <td className="last-column"></td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>

      <div className="t-10">
        <p>
          I certify that the above goods / items have been examined by me and
          that:-
        </p>
        <div className="ml-10">
          <p>
            <span className="px-10">*</span> all of them are of good quality and
            workmanship and must be taken into stock.
          </p>
          <p>
            <span className="px-10">*</span> I have rejected{" "}
            <span>
              {formData.allRejected ? (
                formData.allRejected ? (
                  "Rejected "
                ) : (
                  "Accepted "
                )
              ) : (
                <span>............/............</span>
              )}
            </span>{" "}
            all of them for the following reasons:-
          </p>
        </div>
        {formData.rejectionReason ? (
          <span className="form-entry">{formData.rejectionReason}</span>
        ) : (
          <>
            <p>
              ......................................................................................................................................................................................
            </p>
            <p>
              ......................................................................................................................................................................................
            </p>
          </>
        )}
        <p>
          I have also counter-signed the Delivery Note and the Purchase Order.
        </p>
        <p>
          My Qualification is that of{" "}
          <span>
            {formData.qualification ? (
              <span className="form-entry">{formData.qualification}</span>
            ) : (
              <span>
                .......................................................
              </span>
            )}
          </span>
        </p>
        <p>
          I have served for{" "}
          <span>
            {formData.yearsServed ? (
              <span className="form-entry">{formData.yearsServed}</span>
            ) : (
              <span>..................................</span>
            )}
          </span>{" "}
          years
        </p>
      </div>

      <div className="w-[100%]  flex justify-between">
        <p>
          SIGNATURE
          <span>
            {formData.signature || (
              <span>...................................................</span>
            )}
          </span>
          <span className="font-bold">[QUALITY CONTROLLER]</span>
        </p>
        <span>
          DATE{" "}
          {formData.date ? (
            <span className="form-entry">{formData.date}</span>
          ) : (
            <span>.........................</span>
          )}
        </span>
      </div>

      <div className="mt-10">
        <p>Witnessed by ................................................</p>
        <p className="flex justify-between w-[100%]">
          b)
          <span>
            F/Number{" "}
            {formData.witnessInfo.fNumber ? (
              <span className="form-entry">{formData.witnessInfo.fNumber}</span>
            ) : (
              <span>..............................................</span>
            )}
          </span>
          <span>
            RANK{" "}
            {formData.witnessInfo.rank ? (
              <span className="form-entry">{formData.witnessInfo.rank}</span>
            ) : (
              <span>.............................................</span>
            )}
          </span>
          <span>
            NAME{" "}
            {formData.witnessInfo.name ? (
              <span className="form-entry">{formData.witnessInfo.name}</span>
            ) : (
              <span>...........................................</span>
            )}
          </span>
        </p>
        <p>
          OFFICE HELD{" "}
          {formData.witnessInfo.officeHeld ? (
            <span className="form-entry">
              {formData.witnessInfo.officeHeld}
            </span>
          ) : (
            <span>................................................</span>
          )}
        </p>
      </div>

      {/* Collection Confirmation */}

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default RejectionCertificatePdf;
