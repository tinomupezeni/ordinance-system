import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { Menu, Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const Book2Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  return (
    <div className="w-[210mm] min-h-[297mm] mx-auto bg-white border border-black p-6 print:p-0 text-black book2pdf">
      {/* Form Header */}
      <div className="text-center ">
        <div className="flex space-between align-center w-full bk2-header">
          <p className="flex right-0">Z.R.P</p>
          <p className="flex right-0">Z.R.P.BOOK 2.</p>
        </div>
        <div className="flex bk2-subheader">
          <h1 className="text-xxl font-bold flex justify-center w-[100%] ml-6">
            ZIMBABWE REPUBLIC POLICE: <br /> ISSUE VOUCHER
          </h1>
          <div>
            <div className="box">
              <p>
                I.V. No.{" "}
                <span>
                  {formData.ivNo || (
                    <span>................................</span>
                  )}
                </span>
              </p>
              <p>
                Date {" "}
                <span>
                  {formData.ivDate || (
                    <span>.....................................</span>
                  )}
                </span>
              </p>
            </div>
            <div className="box">
              <p>
                Reqd. No. {" "}
                <span>
                  {formData.reqnNo || <span>...........................</span>}
                </span>
              </p>
              <p>
                Date {" "}
                <span>
                  {formData.reqnDate || (
                    <span>......................................</span>
                  )}
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="issued text-sm">
        <p>
          Issued by{" "}
          <span>
            {formData.issuedBy || (
              <span>
                ...................................................................................................................................................................
              </span>
            )}
          </span>
        </p>
        <p>
          Issued to{" "}
          <span>
            {formData.issuedTo || (
              <span>
                ....................................................................................................................................................................
              </span>
            )}
          </span>
        </p>
      </div>
      <div className="issued text-sm">
        <p>
          How despatched{" "}
          <span>
            {formData.dispatchMethod || (
              <span>
                ........................................................................................................................................................
              </span>
            )}
          </span>
        </p>
      </div>

      {/* Items Table */}
      <table className="w-full text-xs book2">
        <thead>
          <tr className="">
            <th className="">Description</th>
            <th className="">Quantity</th>
            <th className="last-col">Remarks</th>
          </tr>
        </thead>
        <tbody>
          {formData?.items &&
          formData?.items.some((item: any) => item.article !== "")
            ? formData?.items.map((item: any) => (
                <tr key={item.id}>
                  <td className="">{item.description}</td>
                  <td className="">{item.quantity}</td>
                  <td className="last-col">{item.remarks}</td>
                </tr>
              ))
            : Array.from({ length: 15 }).map((_, index) => (
                <tr key={`empty-row-${index}`} className="form-rows">
                  <td className="h-5"></td>
                  <td className="w-14"></td>
                  <td className="last-col"></td>
                </tr>
              ))}
        </tbody>
      </table>

      <div className="issued text-sm">
        <p>
          Received by (Signature)
          <span>
            ............................................................................................
          </span>
          Date{" "}
          <span>
            {formData.receivedDate || (
              <span>.......................................</span>
            )}
          </span>
        </p>
        <span>
          No.{" "}
          {formData?.recipientNo || <span>.............................</span>}
          Rank{" "}
          {formData?.recipientRank || (
            <span>.................................</span>
          )}{" "}
          Name{" "}
          {formData?.recipientName || (
            <span>............................................</span>
          )}
          Station{" "}
          {formData?.recipientStation || (
            <span>.................................</span>
          )}
        </span>
      </div>
      <div className="issued text-sm">
        <p>CERTIFIED that items marked * have been recorded on Inventory</p>
        <span>
          Officer/Member-in-Charge (Signature){" "}
          {formData?.collectedBy?.signature ? (
            formData?.collectedBy?.signature
          ) : (
            <span>
              ......................................................................
            </span>
          )}
          Date{" "}
          {formData?.collectedBy?.station ? (
            formData?.collectedBy?.station
          ) : (
            <span>......................................</span>
          )}
        </span>
      </div>
      <div className="mb-6 pt-4 rounded flex">
        <p>NOTES--</p>
        <p className="text-xs">
          Issue Voucher will be completed in QUADRUPLICATE, the ORIGINAL and
          SECOND copy being forwarded to the receiving Station under separate
          cover. The THIRD copy will be marked PACKING NOTE and enclosed with
          the consignment. The FOURTH copy will be retained in the Issue Voucher
          Book of the issuing Station. The ORIGINAL will, on receipt of the
          consignment, be receipted and returned to the issuing Station where it
          will be pasted to the FOURTH copy in the Issue Voucher Book, except
          when it is required to support other documents, e.g., Arms and
          Ammunition Returns, when suitable endorsement will be made on the
          FOURTH copy.
        </p>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Book2Pdf;
