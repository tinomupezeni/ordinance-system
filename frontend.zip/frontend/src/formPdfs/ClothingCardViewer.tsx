import React, { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import NewIssurance from "@/officeforms/carding/NewIssurance"; // Correct path

// --- Interface Definitions (as previously defined) ---
interface ClothingItemDetails {
  id: number;
  name: string;
  full_name: string | null;
  lifespan_months: number | null;
  category_name: string;
}

interface IssuedItem {
  id: number;
  clothing_item: ClothingItemDetails;
  quantity: number;
}

interface Issuance {
  id: number;
  clNo: string | null;
  date: string;
  serialNo: string | null;
  issued_by?: string | null;
  issued_by_date?: string | null;
  issued_by_signature?: string | null;
  selectedItems: IssuedItem[];
}

interface OfficerData {
  id: number;
  branch: string;
  certClNo: string;
  dateAttested: string;
  forceNo: string;
  initials: string;
  issuances: Issuance[];
  name: string;
  sccNo: string;
  issuedBy?: string | null;
  issuedByDate?: string | null;
  issuedBySignature?: string | null;
}

interface ClothingCardViewerProps {
  officerData: OfficerData | null;
  clothingItems: any; // You might want to define a proper interface for clothingItems
}

const InfoDisplay: React.FC<{ label: string; value: string | null | undefined }> = ({
  label,
  value,
}) => (
  <div>
    <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
    <p className="text-sm font-semibold text-gray-800 break-words">
      {value || "N/A"}
    </p>
  </div>
);

const ClothingCardViewer: React.FC<ClothingCardViewerProps> = ({
  officerData,
  clothingItems, // Keeping this prop for consistency, though not used in this specific file
}) => {
  if (!officerData) {
    return (
      <div className="max-w-4xl mx-auto p-8 mt-10 bg-white rounded-xl shadow-lg border border-gray-200 text-center text-gray-600">
        <p className="text-lg font-medium">No officer data to display.</p>
        <p className="mt-2 text-sm">Please select an officer or ensure data is loaded.</p>
      </div>
    );
  }

  const [openIssuances, setOpenIssuances] = useState<Record<number, boolean>>(
    () => {
      const initialOpenState: Record<number, boolean> = {};
      officerData.issuances.forEach((issuance) => {
        initialOpenState[issuance.id] = true; // All open by default
      });
      return initialOpenState;
    }
  );

  const toggleIssuance = (id: number) => {
    setOpenIssuances((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Calculate the initial count for NewIssurance
  const initialIssuanceCount = officerData.issuances ? officerData.issuances.length : 0;

  return (
    <div className="max-w-4xl mx-auto p-8 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-xl shadow-2xl border border-blue-200 font-sans">
      {/* Header Section */}
      <div className="text-center mb-8 bg-blue-700 text-white py-4 px-6 rounded-t-lg shadow-inner">
        <h2 className="text-3xl font-extrabold tracking-tight">Z.R.P.</h2>
        <h3 className="text-xl font-bold mt-1">CLOTHING CARD</h3>
        <p className="text-sm opacity-90">FORM 51</p>
      </div>

      {/* Officer Force Number */}
      <div className="flex justify-center items-center mb-8 px-4 py-3 bg-blue-100 rounded-lg  border border-blue-200">
        <span className="mr-3 text-lg font-medium text-blue-800">FORCE No.</span>
        <span className="text-2xl font-extrabold text-blue-900 tracking-wide">
          {officerData.forceNo || "N/A"}
        </span>
      </div>

      {/* Officer Personal Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 mb-8 bg-white p-6 rounded-lg  border border-gray-200">
        <InfoDisplay label="Name" value={officerData.name} />
        <InfoDisplay label="Initials" value={officerData.initials} />
        <InfoDisplay label="Branch" value={officerData.branch} />
        <InfoDisplay label="Date Attested" value={officerData.dateAttested} />
      </div>

      {/* Certification Details */}
      <div className="mb-8 p-6 bg-gray-50 rounded-lg  border border-gray-200 italic text-gray-700">
        <p className="mb-4 leading-relaxed">
          Certified that I have received all items of kit enumerated hereon and
          as per
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
          <InfoDisplay label="C.L. No." value={officerData.certClNo} />
          <InfoDisplay label="S.C.C. No." value={officerData.sccNo} />
        </div>
      </div>

      {/* Issuances Section */}
      <h4 className="text-xl font-bold text-gray-700 mb-6 border-b-2 border-blue-300 pb-2">
        Clothing Issuances
      </h4>
      {officerData.issuances.length > 0 ? (
        officerData.issuances.map((issuance, index) => (
          <Card key={issuance.id} className="mb-6 shadow-lg rounded-xl overflow-hidden border border-blue-100">
            <CardHeader
              className="bg-blue-600 text-white py-3 px-5 flex justify-between items-center cursor-pointer hover:bg-blue-700 transition-colors duration-200"
              onClick={() => toggleIssuance(issuance.id)}
            >
              <CardTitle className="text-lg font-semibold flex items-center">
                {openIssuances[issuance.id] ? (
                  <ChevronUp className="h-5 w-5 mr-3" />
                ) : (
                  <ChevronDown className="h-5 w-5 mr-3" />
                )}
                Issuance {index + 1}
                <span className="ml-3 text-sm opacity-80">
                  (Serial No: {issuance.serialNo || 'N/A'})
                </span>
              </CardTitle>
            </CardHeader>

            {openIssuances[issuance.id] && (
              <CardContent className="p-6 bg-white">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4 mb-6">
                  <InfoDisplay label="Issuance Serial No." value={issuance.serialNo} />
                  <InfoDisplay label="Issuance Date" value={issuance.date} />
                  <InfoDisplay label="Issuance C.L. No." value={issuance.clNo} />
                </div>

                {issuance.selectedItems && issuance.selectedItems.length > 0 ? (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <h5 className="font-semibold text-blue-800 mb-3 text-md">
                      Issued Items:
                    </h5>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                      {issuance.selectedItems
                        .slice()
                        .sort((a, b) =>
                          a.clothing_item.name.localeCompare(
                            b.clothing_item.name
                          )
                        )
                        .map((issuedItem) => (
                          <li key={issuedItem.id} className="text-sm text-gray-700 flex items-center">
                            <span className="mr-2 text-blue-500">•</span>
                            <span className="font-medium">
                              {issuedItem.clothing_item.name}
                            </span>
                            {issuedItem.quantity > 1 && (
                              <span className="ml-1 text-gray-600">
                                (x{issuedItem.quantity})
                              </span>
                            )}
                            {issuedItem.clothing_item.category_name && (
                              <span className="ml-2 text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                                {issuedItem.clothing_item.category_name}
                              </span>
                            )}
                          </li>
                        ))}
                    </ul>
                  </div>
                ) : (
                  <p className="text-center text-gray-500 italic py-4">
                    No items recorded for this issuance.
                  </p>
                )}
              </CardContent>
            )}
          </Card>
        ))
      ) : (
        <p className="text-center text-gray-500 italic py-6 bg-white rounded-lg  border border-gray-200">
          No issuances recorded for this officer.
        </p>
      )}

      {/* Render NewIssurance and pass the initial count */}
      <NewIssurance officerData={officerData} initialIssuanceCount={initialIssuanceCount} />

      {/* Issued By Signature */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4 mt-8 bg-white p-6 rounded-lg  border border-gray-200">
        <InfoDisplay label="Overall Issued Date" value={officerData.issuedByDate} />
        <InfoDisplay label="Overall Issued Signature" value={officerData.issuedBySignature} />
        <InfoDisplay label="Overall Issued By" value={officerData.issuedBy} />
      </div>

      {/* Footer */}
      <div className="text-center text-xs text-gray-400 mt-10 pt-4 border-t border-gray-200">
        <p>© {new Date().getFullYear()} ZRP Asset Management. All rights reserved.</p>
      </div>
    </div>
  );
};

export default ClothingCardViewer;