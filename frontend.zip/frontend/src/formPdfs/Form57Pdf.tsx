import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";

// Preview Component (matches PDF layout exactly)
const Form57Pdf = ({
  formData,
  onBack,
  onPrint,
}: {
  formData: any;
  onBack: () => void;
  onPrint: () => void;
}) => {
  console.log(formData);

  return (
    <div className="w-[210mm] min-h-[297mm] border border-black mx-auto bg-white p-6 print:p-0 text-black form57pdf">
      {/* Form Header */}
      <div className="text-center mb-4">
        <div className="flex justify-between align-center w-full ">
          <p className="flex right-0">Z.R.P</p>
          <h1 className="text-xxl font-bold flex justify-center ">
            ORDNANCE LEDGER CARD
          </h1>
          <p className="flex right-0">FORM 57.</p>
        </div>
      </div>

      <div className="relative w-full">
        {/* Group Label Positioned Above */}
        <div className="absolute left-[33.5%] w-[33%]  text-center -top-5 font-bold text-xs">
          BULK STOCK
        </div>

        {/* Table */}
        <table className="w-full text-sm form227">
          <thead>
            <tr>
              <th>Date</th>
              <th>Voucher</th>
              <th>Receipts</th>
              <th>Issues</th>
              <th>Balance</th>
              <th>Outstanding Orders</th>
            </tr>
          </thead>
          <tbody>
            {formData?.ledger_entries &&
            formData?.ledger_entries.some((item: any) => item.article !== "")
              ? formData?.ledger_entries.map((item: any) => (
                  <tr key={item.id} className="form-rows capitalize">
                    <td>{item.date}</td>
                    <td>{item.voucher}</td>
                    <td>{item.receipts}</td>
                    <td>{item.issues}</td>
                    <td>{item.balance}</td>
                    <td>{item.outstanding_orders}</td>
                  </tr>
                ))
              : Array.from({ length: 15 }).map((_, index) => (
                  <tr key={`empty-row-${index}`} className="form-rows">
                    <td className="h-5"></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>

      {/* Collection Confirmation */}
      <div className="w-full mt-10">
        <p>
          Description:{" "}
          <span className="mr-5 font-bold capitalize">
            {formData?.description  || (
              <span>............................... </span>
            )}
          </span>
          Price{" "}
          <span className="mr-5 font-bold capitalize">
            {formData?.price || <span>..........................</span>}
          </span>
          Re-order Level:{" "}
          <span className="mr-5 font-bold capitalize">
            {formData?.reorder_level || (
              <span>................................</span>
            )}
          </span>
          Re-order Amount:{" "}
          <span className="mr-5 font-bold capitalize">
            {formData?.reorder_amount || <span>.......................</span>}
          </span>
        </p>
      </div>

      {/* Action Buttons (hidden when printing) */}
      <div className="flex justify-between mt-6 no-print">
        <Button variant="outline" onClick={onBack}>
          Back to Edit
        </Button>
        <Button onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Form
        </Button>
      </div>
    </div>
  );
};

export default Form57Pdf;
