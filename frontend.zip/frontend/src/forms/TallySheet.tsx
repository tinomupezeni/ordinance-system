import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Printer, ChevronDown, ChevronUp, List, Search } from "lucide-react";
import { toast } from "sonner";
import TallySheetPdf from "@/formPdfs/TallySheetPdf";

type TallyItem = {
  id: number;
  description: string;
  numberIssued: string;
  total: string;
  voucherNo: string;
  isGroup?: boolean;
  groupItems?: TallyItem[];
  expanded?: boolean;
};

const TallySheet = () => {
  const [sheetNo, setSheetNo] = useState("");
  const [date, setDate] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  // Mixed array with both standalone items and groups
  const mixedTallyItems = [
    "Anklets, Web",
    {
      name: "Aiguilletes",
      items: ["Aiguillete, Gold Wire", "Aiguillete, Gilt Wire"],
    },
    " J/Off",
    {
      name: "Badges",
      items: [
        "Badge, Cap S/Off",
        "Badge, Cap, Anodised",
        "Badge, Collar, Gilt",
        "Badge Hat, EMB, W/P",
        "Badge, s/on, various",
        "Badge Collar Miniature",
      ],
    },
    {
      name: "Bag",
      items: ["Bag, Sleeping", "Bag, Kit", "Bag, Shoulder, W/P"],
    },
    {
      name: "Baton",
      items: [
        "Baton Holder, Riot",
        "Baton, Police Rubber",
        "Baton, Police Riot",
      ],
    },
    "Battery, Wonder",
    {
      name: "Belts",
      items: ["Belt, Leather Brown", "Belt Stable", "Belt web"],
    },
    "Blanket, Acrilic",
    "Bottle Water",
    {
      name: "Book",
      items: ["Book, Instruction, A.P.", "Book, Instruction, E.P."],
    },
    {
      name: "Boots",
      items: [
        "Boots, Black L.S.",
        "Boots, Riding",
        "Half Wellington",
        "Boots, Brown, L/S",
        "Boots, Veldskoen",
        "Boots, Combat",
        "Boots Creep sole",
        "Boots, Rubber, Knee",
        "Boots, S/Pro",
      ],
    },
    "Half, Wellington",
    {
      name: "Brush",
      items: ["Brush, Blacking", "Brush, Clothes", "Brush Polishing"],
    },
    "Buckle Anodised",
    "Titles, N/S Anodised",
    {
      name: "Buttons",
      items: [
        "Buttons, Anodised, 'L'",
        "Buttons, Anodised, 'M'",
        "Buttons, Anodised, 'S'",
      ],
    },
    {
      name: "Cap",
      items: [
        "Cap, Drap",
        "Cap, Black Officer",
        "Cap, Blue Band",
        "Cap, STU",
        "Cape, Poncho",
      ],
    },
    "Carrier, Water Bottle",
    "Cardigan, Blue, W/P",
    {
      name: "Coat",
      items: ["Coat, Blue W/P", "Coat, Plastic", "Coat, Trench Grey"],
    },
    "Cover, Notebook",
    "Curtain, Mosquito, White",
    "Curtain, Mosquito, Green",
    "Chevron, Anodised",
    "Chevron, EMB, G.B",
    "Cord, Shoulder",
    "Cane, Leather",
    "Case, Despatch",
    "Despatch, W/P",
    "Dust, Coat, White",
    {
      name: "Flag",
      items: ["Flag, Zimbabwe (6x3)", "Flag, Police (6x3)"],
    },
    "Frog Sword",
    "Fork, Table",
    "Frog, Bayonet",
    "Gauntlets, M/C",
    {
      name: "Gloves",
      items: [
        "Gloves, L, Unlined",
        "Gloves, Driving, W/P",
        "Gloves, N/Blue, W/P",
        "Gloves, Traffic, W/P",
        "Gloves, Traffic, White",
        "Gloves, Stringback",
        "Gloves, White W/P",
        "Gloves, K/H, Wool",
      ],
    },
    "Goggles, M/Cycle",
    "Holdalls",
    "Holster, P.I. Various",
    "Handcuffs",
    "Hat, Blue W/P",
    "Hat, Blue Officer",
    "Haversack, Web",
    "Helmet, Riding White",
    "Housewife",
    "Jacket, STU",
    {
      name: "Jersey",
      items: ["Jersey, Blue, W/P", "Jersey, Grey", "Jersey, Blue, CIV"],
    },
    "Knot Sword",
    "Knife, Table",
    "Lamp, Police",
    "Lantern, Hunter",
    "Lanyard, Whistle",
    "Lanyard, Gold (Cotton)",
    "Manual, First Aid",
    "Mug, Plastic",
    {
      name: "Overalls",
      items: [
        "Overalls, Blue, Combination",
        "Overalls,  Acidproof",
        "Overalls, K/H, Dogs STU",
      ],
    },
    "Pantihose",
    "Patches Gorgette Various",
    "Pack, Back  Small",
    "Pillows",
    "Pouch, Basic, Single",
    "Respirator, A/Gas",
    "Satchel, Blue, W/P",
    "Sheet, Bed",
    {
      name: "Shirts",
      items: [
        "Shirt, Blue, W/P",
        "Shirt, Blue, Civ",
        "Shirt, Blue Band",
        "Shirt, DrabL/S",
        "Shirt, Drab, S/S",
        "Shirt, K/H Tech.",
        "Shirt, Grey",
        "Shirt,  White Band",
        "Shirt, White",
        "Shirt, White Patrol",
      ],
    },
    {
      name: "Shoes",
      items: [
        "Shoes, Brown  L/S",
        "Shoes, Black Band",
        "Shoes, Black, W/P",
        "Shoes, Black W/p Officers",
        "Shoes, Court",
        "Shoes, Canvas",
        "Shoes, Safety",
      ],
    },
    "Shorts, P.T",
    "Slips, Pillow",
    "Sleeves, Traffic, White",
    "Sleeves, Reflective",
    "Sling, Haversack",
    "Sling, Rifle",
    {
      name: "Socks",
      items: [
        "Socks,  Back, Band & Civ",
        "Socks, White W/P",
        "Socks, K/H, Wool",
        "Socks, K/H, Nylon",
      ],
    },
    "Sword, Officer",
    "Scabbard",
    "Stocking, K/H, Tech",
    "Stars, Gilt",
    "Stars,  Gilded",
    {
      name: "Suits",
      items: [
        "Suit, F/Dress",
        "Suit, Track",
        "Suit, Summer S/S",
        "Suit, Summer L/S",
        "Suit, Dress Mess",
        "Suit, Winter W/P",
        "Suit, Fawn",
      ],
    },
    "Slacks, Blue W/P",
    "Spoon, Table",
    "Tin, Mess",
    {
      name: "Tie",
      items: [
        "Tie, Blue",
        "Tie, Blue Civ",
        "Tie, Black",
      ],
    },
    "Titles, Z.R.P. Anodised",
    {
      name: "Tipstaves",
      items: [
        "Tipstaves F/S",
        "Tipstaves EMB",
        "Tipstaves MIN",
      ],
    },
    "Towels, Hand",
    "Torch, CID",
    {
      name: "Trousers",
      items: [
        "Trousers, Tech",
        "Tipstaves, Blue Civ",
        "Tipstaves, Fawn",
        "Tipstaves, Riot",
      ],
    },
    "Vest, Various",
    "Whistle",
    "Zimbird in Wreath F/S",
    "Zimbird in Wreath EMB",
  ];

  // Initialize state with mixed items
  const [items, setItems] = useState<TallyItem[]>(() => {
    let id = 1;
    const result: TallyItem[] = [];

    mixedTallyItems.forEach((item) => {
      if (typeof item === "string") {
        // Standalone item
        result.push({
          id: id++,
          description: item,
          numberIssued: "",
          total: "",
          voucherNo: "",
        });
      } else {
        // Grouped item
        const groupItems = item.items.map((subItem) => ({
          id: id++,
          description: subItem,
          numberIssued: "",
          total: "",
          voucherNo: "",
        }));

        result.push({
          id: id++,
          description: item.name,
          numberIssued: "",
          total: "",
          voucherNo: "",
          isGroup: true,
          groupItems,
          expanded: false,
        });
      }
    });

    return result;
  });

  const [firstColumnTotal, setFirstColumnTotal] = useState("");
  const [secondColumnTotal, setSecondColumnTotal] = useState("");
  const [thirdColumnTotal, setThirdColumnTotal] = useState("");
  const [grandTotal, setGrandTotal] = useState("");

  const handleItemChange = (
    id: number,
    field: keyof TallyItem,
    value: string
  ) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return { ...item, [field]: value };
        }

        if (item.isGroup && item.groupItems) {
          const updatedGroupItems = item.groupItems.map((groupItem) => {
            if (groupItem.id === id) {
              return { ...groupItem, [field]: value };
            }
            return groupItem;
          });

          return { ...item, groupItems: updatedGroupItems };
        }

        return item;
      })
    );
  };

  const toggleGroup = (id: number) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, expanded: !item.expanded } : item
      )
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Tally sheet submitted successfully");
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredItems = items.filter(
    (item) =>
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.isGroup &&
        item.groupItems?.some((subItem) =>
          subItem.description.toLowerCase().includes(searchTerm.toLowerCase())
        ))
  );
  const [showPreview, setShowPreview] = useState(false);
  return (
    <div className="flex">
       {!showPreview ? (
      <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
        <CardHeader className="pb-0">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
            <p className="text-sm text-gray-600">
              FORM 51B - MAIN LEDGER TALLY SHEET
            </p>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <form onSubmit={handleSubmit}>
            {/* Sheet Information */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <Label>Sheet No.</Label>
                <Input
                  value={sheetNo}
                  onChange={(e) => setSheetNo(e.target.value)}
                  placeholder="Enter sheet number"
                />
              </div>
              <div>
                <Label>Date</Label>
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>
            </div>

            {/* Search */}
            <div className="mb-4">
              <div className="relative flex items-center">
                <Input
                  aria-label="Search items"
                  className="w-full pl-4 pr-10 py-2"
                  id="search"
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search items..."
                  type="text"
                  value={searchTerm}
                />
                <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                  <Search className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Tally Sheet Table */}
            <div className="mb-6 border rounded-lg overflow-hidden">
              <div className="grid grid-cols-4 gap-2 font-semibold bg-gray-50 p-2">
                <div>Description</div>
                <div>Number Issued</div>
                <div>Total</div>
                <div>Voucher No.</div>
              </div>

              <div className="max-h-[500px] overflow-y-auto">
                {filteredItems.map((item) => (
                  <div key={item.id}>
                    <div className="grid grid-cols-4 gap-2 items-center border-b p-2">
                      <div className="text-sm flex items-center">
                        {item.isGroup ? (
                          <button
                            type="button"
                            onClick={() => toggleGroup(item.id)}
                            className="mr-2"
                          >
                            {item.expanded ? (
                              <ChevronUp className="h-4 w-4" />
                            ) : (
                              <ChevronDown className="h-4 w-4" />
                            )}
                          </button>
                        ) : null}
                        {item.description}
                      </div>
                      {item.isGroup ? (
                        <div className="col-span-3 text-sm text-gray-500">
                          {item.groupItems?.length} items
                        </div>
                      ) : (
                        <>
                          <Input
                            type="number"
                            value={item.numberIssued}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "numberIssued",
                                e.target.value
                              )
                            }
                            className="h-8"
                          />
                          <Input
                            type="number"
                            value={item.total}
                            onChange={(e) =>
                              handleItemChange(item.id, "total", e.target.value)
                            }
                            className="h-8"
                          />
                          <Input
                            value={item.voucherNo}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                "voucherNo",
                                e.target.value
                              )
                            }
                            className="h-8"
                          />
                        </>
                      )}
                    </div>

                    {/* Render group items if expanded */}
                    {item.isGroup &&
                      item.expanded &&
                      item.groupItems?.map((groupItem) => (
                        <div
                          key={groupItem.id}
                          className="grid grid-cols-4 gap-2 items-center border-b p-2 pl-8 bg-gray-50"
                        >
                          <div className="text-sm">{groupItem.description}</div>
                          <Input
                            type="number"
                            value={groupItem.numberIssued}
                            onChange={(e) =>
                              handleItemChange(
                                groupItem.id,
                                "numberIssued",
                                e.target.value
                              )
                            }
                            className="h-8"
                          />
                          <Input
                            type="number"
                            value={groupItem.total}
                            onChange={(e) =>
                              handleItemChange(
                                groupItem.id,
                                "total",
                                e.target.value
                              )
                            }
                            className="h-8"
                          />
                          <Input
                            value={groupItem.voucherNo}
                            onChange={(e) =>
                              handleItemChange(
                                groupItem.id,
                                "voucherNo",
                                e.target.value
                              )
                            }
                            className="h-8"
                          />
                        </div>
                      ))}
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="font-bold">First Column Total:</div>
              <Input
                value={firstColumnTotal}
                onChange={(e) => setFirstColumnTotal(e.target.value)}
              />
              <div className="font-bold">Second Column Total:</div>
              <Input
                value={secondColumnTotal}
                onChange={(e) => setSecondColumnTotal(e.target.value)}
              />
              <div className="font-bold">Third Column Total:</div>
              <Input
                value={thirdColumnTotal}
                onChange={(e) => setThirdColumnTotal(e.target.value)}
              />
              <div className="font-bold">GRAND TOTAL:</div>
              <Input
                value={grandTotal}
                onChange={(e) => setGrandTotal(e.target.value)}
              />
            </div>

            {/* Form Actions */}
            <div className="flex justify-between mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  let id = 1;
                  const newItems: TallyItem[] = [];

                  mixedTallyItems.forEach((item) => {
                    if (typeof item === "string") {
                      newItems.push({
                        id: id++,
                        description: item,
                        numberIssued: "",
                        total: "",
                        voucherNo: "",
                      });
                    } else {
                      const groupItems = item.items.map((subItem) => ({
                        id: id++,
                        description: subItem,
                        numberIssued: "",
                        total: "",
                        voucherNo: "",
                      }));

                      newItems.push({
                        id: id++,
                        description: item.name,
                        numberIssued: "",
                        total: "",
                        voucherNo: "",
                        isGroup: true,
                        groupItems,
                        expanded: false,
                      });
                    }
                  });

                  setItems(newItems);
                  setSheetNo("");
                  setDate("");
                  setFirstColumnTotal("");
                  setSecondColumnTotal("");
                  setThirdColumnTotal("");
                  setGrandTotal("");
                  toast.info("Form reset");
                }}
              >
                Reset Form
              </Button>
              <div className="flex gap-2">
                <Button type="button" variant="secondary" onClick={() => setShowPreview(true)}>
                  <Printer className="mr-2 h-4 w-4" />
                  Print
                </Button>
                <Button type="submit">Submit Form</Button>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
      ) : (
        <TallySheetPdf
          formData={null}
          // formData={{
          //   ...formData,
          //   items: formData.items.filter(
          //     (item) => item.description.trim() !== ""
          //   ),
          // }}
          onBack={() => setShowPreview(false)}
          onPrint={handlePrint}
        />
      )}

      {/* Recent Reports Sidebar */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6 w-80">
        <div className="space-y-4">
          <h3 className="text-xl font-semibold flex items-center gap-2">
            Recent Tally Sheets
          </h3>

          <div className="relative flex items-center">
            <input
              aria-label="Search"
              className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              id="search-reports"
              placeholder="Search by sheet no..."
              type="text"
            />
            <button className="absolute right-3 text-gray-500 hover:text-blue-600">
              <Search className="h-4 w-4" />
            </button>
          </div>

          <div className="overflow-y-auto max-h-96">
            <div className="space-y-2">
              {/* Sample recent reports */}
              <div className="p-3 border rounded hover:bg-gray-50 cursor-pointer">
                <div className="font-medium">Tally Sheet #00123</div>
                <div className="text-sm text-gray-500">2023-05-15</div>
              </div>
              <div className="p-3 border rounded hover:bg-gray-50 cursor-pointer">
                <div className="font-medium">Tally Sheet #00122</div>
                <div className="text-sm text-gray-500">2023-05-14</div>
              </div>
              <div className="p-3 border rounded hover:bg-gray-50 cursor-pointer">
                <div className="font-medium">Tally Sheet #00121</div>
                <div className="text-sm text-gray-500">2023-05-13</div>
              </div>
              <div className="p-3 border rounded hover:bg-gray-50 cursor-pointer">
                <div className="font-medium">Tally Sheet #00120</div>
                <div className="text-sm text-gray-500">2023-05-12</div>
              </div>
            </div>
          </div>

          <a
            className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
            href="#"
          >
            <List className="h-4 w-4" /> View All Sheets
          </a>
        </div>
      </div>
    </div>
  );
};

export default TallySheet;
