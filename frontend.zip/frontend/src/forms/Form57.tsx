import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import Form57Pdf from "@/formPdfs/Form57Pdf";
import Server from "@/server/Server"; // Make sure this import is correct

// --- Re-iterating Type Definitions (from previous successful interaction) ---
type LedgerEntry = {
  id?: number; // Optional for new entries, required for existing ones
  date: string;
  voucher: string;
  receipts: string | number | null; // Allow string from input, convert to number or null for API
  issues: string | number | null;
  balance: string | number | null;
  outstanding_orders: string; // Match backend field name
};

type FormDataForAPI = {
  description: string;
  price: number | null; // Changed to number | null as we convert strings
  reorder_level: number | null;
  reorder_amount: number | null;
  office: string; // Match backend field name
  ledger_entries: LedgerEntry[]; // Match backend field name
};

type Form57DataFromAPI = {
  id: number;
  description: string;
  price: number;
  reorder_level: number;
  reorder_amount: number;
  office: string;
  ledger_entries: LedgerEntry[];
  created_by: number;
  created_at: string;
  updated_at: string;
};


const Form57 = ({ formId, onSubmissionSuccess, formType }) => {
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [reorderLevel, setReorderLevel] = useState("");
  const [reorderAmount, setReorderAmount] = useState("");

  const [entries, setEntries] = useState<LedgerEntry[]>([
    {
      id: 1, // Frontend local ID for unique keying
      date: "",
      voucher: "",
      receipts: "",
      issues: "",
      balance: "",
      outstanding_orders: "", // Ensure this is initialized
    },
  ]);

  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState<Form57DataFromAPI | null>(null);

  const [isEditMode, setIsEditMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (formId) {
      setIsEditMode(true);
      setIsLoading(true);
      Server.getForm57(formId)
        .then((response: Form57DataFromAPI) => {
          setDescription(response.description);
          setPrice(response.price.toString());
          setReorderLevel(response.reorder_level.toString());
          setReorderAmount(response.reorder_amount.toString());
          // Assuming formType prop is for creation context, not for overriding loaded office
          // If you want to use the loaded office: setOffice(response.office);

          const loadedEntries = response.ledger_entries.map((entry, index) => ({
            ...entry,
            id: entry.id || (index + 1), // Use backend ID if available, else local
          }));
          // Add an empty row if the last loaded entry is complete
          if (loadedEntries.length > 0 && Object.values(loadedEntries[loadedEntries.length - 1]).some(v => v !== "" && v !== null)) {
               setEntries([...loadedEntries, { id: loadedEntries.length + 1, date: "", voucher: "", receipts: "", issues: "", balance: "", outstanding_orders: "" }]);
          } else if (loadedEntries.length > 0) {
              setEntries(loadedEntries);
          } else {
              setEntries([{ id: 1, date: "", voucher: "", receipts: "", issues: "", balance: "", outstanding_orders: "" }]);
          }


          setPreviewData(response); // Set data for preview as well
          setIsLoading(false);
        })
        .catch((error) => {
          toast.error("Failed to load Form 57 for editing.");
          console.error("Error loading Form 57:", error);
          setIsLoading(false);
          setIsEditMode(false);
        });
    } else {
      setIsEditMode(false);
      setEntries([
        {
          id: 1,
          date: "",
          voucher: "",
          receipts: "",
          issues: "",
          balance: "",
          outstanding_orders: "",
        },
      ]);
    }
  }, [formId]);


  const handleEntryChange = (
    id: number,
    field: keyof LedgerEntry,
    value: string
  ) => {
    setEntries((prev) => {
      const updatedEntries = prev.map((entry) =>
        entry.id === id ? { ...entry, [field]: value } : entry
      );

      const lastEntry = updatedEntries[updatedEntries.length - 1];
      const isLastEntryCompleteEnoughToAddNew =
        (lastEntry.date && lastEntry.date !== "") ||
        (lastEntry.voucher && lastEntry.voucher !== "") ||
        (lastEntry.receipts !== "" && lastEntry.receipts !== null) || // Check for non-empty string or non-null
        (lastEntry.issues !== "" && lastEntry.issues !== null) ||
        (lastEntry.balance !== "" && lastEntry.balance !== null) ||
        (lastEntry.outstanding_orders && lastEntry.outstanding_orders !== "");


      if (isLastEntryCompleteEnoughToAddNew && id === lastEntry.id) {
           return [
               ...updatedEntries,
               {
                   id: prev.length > 0 ? (prev[prev.length - 1].id + 1) : 1,
                   date: "",
                   voucher: "",
                   receipts: "",
                   issues: "",
                   balance: "",
                   outstanding_orders: "",
               },
           ];
       }

      return updatedEntries;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => { // Made async for API call
    e.preventDefault();
    setIsLoading(true); // Start loading

    // 1. Filter out empty rows (where all fields are empty) AND transform data for backend
    const submittedEntries = entries.filter(
      (entry) =>
        entry.date ||
        entry.voucher ||
        entry.receipts || // Check all fields
        entry.issues ||
        entry.balance ||
        entry.outstanding_orders
    ).map(entry => ({
        // Ensure numbers are converted, null for empty strings
        id: entry.id, // Keep the ID for updates
        date: entry.date,
        voucher: entry.voucher,
        receipts: entry.receipts === "" ? null : Number(entry.receipts), // Convert to Number or null
        issues: entry.issues === "" ? null : Number(entry.issues),
        balance: entry.balance === "" ? null : Number(entry.balance),
        outstanding_orders: entry.outstanding_orders, // Ensure this field is included
    }));

    // 2. Compile the main form data payload
    const payload: FormDataForAPI = {
      description,
      price: price === "" ? null : Number(price), // Convert price to Number or null
      reorder_level: reorderLevel === "" ? null : Number(reorderLevel), // Convert reorderLevel to Number or null
      reorder_amount: reorderAmount === "" ? null : Number(reorderAmount), // Convert reorderAmount to Number or null
      office: formType, // This is where the 'formType' prop goes to 'office'
      ledger_entries: submittedEntries,
    };

    console.log("Payload being sent to backend:", payload); // For debugging

    // 3. Send data to backend (using your Server.ts methods)
    try {
      let response: Form57DataFromAPI;
      if (isEditMode && formId) {
        response = await Server.updateForm57(formId, payload);
        toast.success("Form 57 updated successfully!");
      } else {
        response = await Server.createForm57(payload);
        toast.success("Form 57 submitted successfully!");
      }
      setPreviewData(response); // Update preview data with saved data (which includes backend IDs, timestamps)
      setShowPreview(true); // Show the preview
      if (onSubmissionSuccess) {
        onSubmissionSuccess(response.id); // Notify parent of success with the new/updated ID
      }
    } catch (error) {
      toast.error("Failed to submit Form 57. Please try again.");
      console.error("Form 57 submission error:", error);
    } finally {
      setIsLoading(false); // Stop loading regardless of success or failure
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleResetForm = () => {
    setDescription("");
    setPrice("");
    setReorderLevel("");
    setReorderAmount("");
    setEntries([
      {
        id: 1,
        date: "",
        voucher: "",
        receipts: "",
        issues: "",
        balance: "",
        outstanding_orders: "",
      },
    ]);
    setShowPreview(false);
    setPreviewData(null);
    setIsEditMode(false);
    toast.info("Form has been reset");
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-96">Loading Form 57...</div>;
  }

  return (
    // ... (rest of your JSX remains the same)
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">
                  FORM 57 - ORDNANCE LEDGER CARD
                </p>
                {formType && <p className="text-md text-gray-700 mt-2">Office: {formType}</p>}
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Item Information */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Price</Label>
                    <Input
                      id="price"
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reorderLevel">Re-order Level</Label>
                    <Input
                      id="reorderLevel"
                      type="number"
                      value={reorderLevel}
                      onChange={(e) => setReorderLevel(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reorderAmount">Re-order Amount</Label>
                    <Input
                      id="reorderAmount"
                      type="number"
                      value={reorderAmount}
                      onChange={(e) => setReorderAmount(e.target.value)}
                    />
                  </div>
                </div>

                {/* Ledger Table */}
                <div className="mb-6">
                  <div className="grid grid-cols-6 gap-2 font-semibold border-b pb-2 mb-2">
                    <div>Date</div>
                    <div>Voucher</div>
                    <div>Receipts</div>
                    <div>Issues</div>
                    <div>Balance</div>
                    <div>Outstanding Orders</div>
                  </div>

                  {entries.map((entry) => (
                    <div
                      key={entry.id}
                      className="grid grid-cols-6 gap-2 items-center border-b py-2"
                    >
                      <Input
                        type="date"
                        value={entry.date}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "date", e.target.value)
                        }
                      />
                      <Input
                        value={entry.voucher}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "voucher", e.target.value)
                        }
                      />
                      <Input
                        type="number"
                        value={entry.receipts || ""}
                        onChange={(e) =>
                          handleEntryChange(
                            entry.id!,
                            "receipts",
                            e.target.value
                          )
                        }
                      />
                      <Input
                        type="number"
                        value={entry.issues || ""}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "issues", e.target.value)
                        }
                      />
                      <Input
                        type="number"
                        value={entry.balance || ""}
                        onChange={(e) =>
                          handleEntryChange(entry.id!, "balance", e.target.value)
                        }
                      />
                      <Input
                         value={entry.outstanding_orders}
                         onChange={(e) =>
                           handleEntryChange(entry.id!, "outstanding_orders", e.target.value)
                         }
                      />
                    </div>
                  ))}
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleResetForm}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        const currentFormData: Form57DataFromAPI = {
                            id: formId || 0,
                            description,
                            price: Number(price),
                            reorder_level: Number(reorderLevel),
                            reorder_amount: Number(reorderAmount),
                            office: formType,
                            ledger_entries: entries.filter(e => Object.values(e).some(v => v !== "" && v !== null)).map(entry => ({
                                ...entry,
                                receipts: entry.receipts === "" ? null : Number(entry.receipts),
                                issues: entry.issues === "" ? null : Number(entry.issues),
                                balance: entry.balance === "" ? null : Number(entry.balance),
                            })),
                            created_by: 0,
                            created_at: new Date().toISOString(),
                            updated_at: new Date().toISOString(),
                        };
                        setPreviewData(currentFormData);
                        setShowPreview(true);
                      }}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? "Submitting..." : (isEditMode ? "Update Ledger" : "Submit Ledger")}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          previewData && (
            <Form57Pdf
              formData={previewData}
              onBack={() => setShowPreview(false)}
              onPrint={handlePrint}
            />
          )
        )}
      </div>
    </>
  );
};

export default Form57;