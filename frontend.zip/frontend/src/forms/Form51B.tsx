import { Input } from "@/components/ui/input"; // Assuming this is a custom Input component
import { Trash, Plus, ChevronDown, ChevronUp } from "lucide-react";
import React, { useState, useMemo } from "react"; // Import useMemo
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Server from "@/server/Server";
import { toast } from "sonner";

interface ClothingItem {
  category: string;
  item_name: string;
  quantity: number;
}

const ClothingCardForm = ({ clothingItems, approveDelete }) => {
  const [issuances, setIssuances] = useState([
    {
      id: Date.now(),
      serialNo: "",
      date: "",
      clNo: "",
      selectedItems: [],
      isOpen: true, // New: track if issuance is expanded
    },
  ]);

  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>(
    {}
  );

  const [formData, setFormData] = useState({
    forceNo: "",
    gender: "M", // Consider making this a dropdown if relevant for your form
    dateAttested: "",
    branch: "",
    name: "",
    initials: "",
    certClNo: "",
    sccNo: "",
    issuedByDate: "",
    issuedBySignature: "",
    issuedBy: "",
  });

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleIssuanceChange = (id, field, value) => {
    setIssuances((prev) =>
      prev.map((issuance) =>
        issuance.id === id ? { ...issuance, [field]: value } : issuance
      )
    );
  };

  const toggleIssuance = (id) => {
    setIssuances((prev) =>
      prev.map((issuance) =>
        issuance.id === id
          ? { ...issuance, isOpen: !issuance.isOpen }
          : issuance
      )
    );
  };

  const toggleCategory = (category) => {
    setOpenCategories((prev) => ({
      ...prev,
      [category]: !prev[category],
    }));
  };

  const toggleItemSelection = (issuanceId, category, itemName) => {
    setIssuances((prev) =>
      prev.map((issuance) => {
        if (issuance.id !== issuanceId) return issuance;

        const itemKey = `${category}|${itemName}`;
        const selectedItems = issuance.selectedItems.includes(itemKey)
          ? issuance.selectedItems.filter((i) => i !== itemKey)
          : [...issuance.selectedItems, itemKey];

        return { ...issuance, selectedItems };
      })
    );
  };

  const addIssuance = () => {
    setIssuances((prev) => [
      ...prev,
      {
        id: Date.now(),
        serialNo: "",
        date: "",
        clNo: "",
        selectedItems: [],
        isOpen: true,
      },
    ]);
  };
  // Replace the current clothingItems structure with this transformed version
// const transformedClothingItems = useMemo(() => {
//   const categories: Record<string, string[]> = {};
  
//   clothingItems.forEach((item: ClothingItem) => {
//     if (!categories[item.category]) {
//       categories[item.category] = [];
//     }
//     categories[item.category].push(item.item_name);
//   });
  
//   return categories;
// }, [clothingItems]);

// Then use transformedClothingItems instead of clothingItems in the component

  const removeIssuance = (id) => {
    setIssuances((prev) => prev.filter((issuance) => issuance.id !== id));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const submissionData = {
      ...formData,
      issuances: issuances.map((issuance) => ({
        serialNo: issuance.serialNo,
        date: issuance.date,
        clNo: issuance.clNo,
        selectedItems: issuance.selectedItems.map((item) => {
          const [category, itemName] = item.split("|");
          return {
            category,
            item_name: itemName,
            // You might want to include quantity here if needed
          };
        }),
      })),
    };
    Server.addOfficer(submissionData)
      .then(() => {
        toast.success("Successfully added Officer");
      })
      .catch((error) => {
        console.log(error);
        toast.error("An error occured", error);
      });
    console.log("Form submitted:", submissionData);
  };

  // --- New: Memoized and sorted clothing items and categories ---
  const sortedClothingCategories = useMemo(() => {
    return Object.entries(clothingItems).sort(([catA], [catB]) =>
      catA.localeCompare(catB)
    );
  }, [clothingItems]);

  const getSortedItemsForCategory = useMemo(
    () => (category) => {
      return clothingItems[category]
        ? [...clothingItems[category]].sort((a, b) => a.localeCompare(b))
        : [];
    },
    [clothingItems]
  );
  // --- End New ---

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white border border-black rounded-lg shadow-sm">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold">Z.R.P.</h2>
        <h3 className="text-lg font-semibold">CLOTHING CARD</h3>
        <p className="text-sm">FORM 51</p>
      </div>

      <div className="flex justify-center mb-6">
        <div className="flex items-center">
          <span className="mr-2 font-medium">FORCE No.</span>
          {/* Note: Your custom Input component might not correctly handle `label={undefined}`. 
              If it expects a label prop, you might need to adjust it or pass an empty string. */}
          <Input
            // className="w-48"
            name="forceNo"
            value={formData.forceNo}
            onChange={handleFormChange}
            label="" // Pass an empty string for the label
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Input
          label="Date attested:"
          type="date"
          name="dateAttested"
          value={formData.dateAttested}
          onChange={handleFormChange}
        />
        <Input
          label="Branch:"
          name="branch"
          value={formData.branch}
          onChange={handleFormChange}
        />
        <Input
          label="Name:"
          name="name"
          value={formData.name}
          onChange={handleFormChange}
        />
        <Input
          label="Initials:"
          name="initials"
          value={formData.initials}
          onChange={handleFormChange}
        />
      </div>

      <div className="mb-6 italic">
        <p className="mb-2">
          Certified that I have received all items of kit enumerated hereon and
          as per
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="C.L. No."
            name="certClNo"
            value={formData.certClNo}
            onChange={handleFormChange}
          />
          <Input
            label="S.C.C. No."
            name="sccNo"
            value={formData.sccNo}
            onChange={handleFormChange}
          />
        </div>
      </div>

      {issuances.map((issuance) => (
        <Card key={issuance.id} className="mb-6">
          <CardHeader
            className="bg-gray-50 py-3 px-4 border-b cursor-pointer"
            onClick={() => toggleIssuance(issuance.id)}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                {issuance.isOpen ? (
                  <ChevronUp className="h-4 w-4 mr-2" />
                ) : (
                  <ChevronDown className="h-4 w-4 mr-2" />
                )}
                <CardTitle className="text-sm font-medium">
                  ISSUANCE {issuances.indexOf(issuance) + 1}
                </CardTitle>
              </div>
              <div className="flex space-x-2">
                {issuances.length > 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeIssuance(issuance.id);
                    }}
                  >
                    <Trash className="h-4 w-4 text-red-500" />
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>

          {issuance.isOpen && (
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <Input
                  label="Serial No."
                  name="serialNo"
                  value={issuance.serialNo}
                  onChange={(e) =>
                    handleIssuanceChange(
                      issuance.id,
                      "serialNo",
                      e.target.value
                    )
                  }
                />
                <Input
                  label="Date"
                  type="date"
                  name="date"
                  value={issuance.date}
                  onChange={(e) =>
                    handleIssuanceChange(issuance.id, "date", e.target.value)
                  }
                />
                <Input
                  label="C.L. No."
                  name="clNo"
                  value={issuance.clNo}
                  onChange={(e) =>
                    handleIssuanceChange(issuance.id, "clNo", e.target.value)
                  }
                />
              </div>

              <div className="mb-4">
                <label className="block mb-2 font-medium">Select Items:</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {/* Iterate over sorted categories */}
                  {sortedClothingCategories.map(([category, items]) => (
                    <div
                      key={category}
                      className="border rounded-lg overflow-hidden"
                    >
                      <div
                        className="flex items-center justify-between p-3 bg-gray-50 cursor-pointer"
                        onClick={() => toggleCategory(category)}
                      >
                        <div className="flex items-center">
                          {openCategories[category] ? (
                            <ChevronUp className="h-4 w-4 mr-2" />
                          ) : (
                            <ChevronDown className="h-4 w-4 mr-2" />
                          )}
                          <span className="font-medium">
                            {category}{" "}
                            <span className="text-gray-500">
                              ({items.length})
                            </span>
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            // approveDelete(category); // This approveDelete is meant for items
                            // If you want to delete a whole category, you need to implement that logic.
                            // For now, it's safer not to have a category-level delete unless `approveDelete` handles it.
                          }}
                        >
                          {/* <Trash className="h-4 w-4 text-red-500" /> */}
                          {/* Removed trash icon for category for now, as approveDelete likely targets individual items */}
                        </Button>
                      </div>

                      {openCategories[category] && (
                        <div className="p-3 space-y-2">
                          {/* Iterate over sorted items within the category */}
                          {getSortedItemsForCategory(category).map(
                            (itemName) => (
                              <div
                                key={itemName}
                                className="flex items-center justify-between"
                              >
                                <div className="flex items-center space-x-2">
                                  <input
                                    type="checkbox"
                                    checked={issuance.selectedItems.includes(
                                      `${category}|${itemName}`
                                    )}
                                    onChange={() =>
                                      toggleItemSelection(
                                        issuance.id,
                                        category,
                                        itemName
                                      )
                                    }
                                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                  />
                                  <label className="text-sm">{itemName}</label>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    approveDelete(category, itemName);
                                  }}
                                >
                                  <Trash className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {issuance.selectedItems.length > 0 && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <h5 className="font-medium mb-2">Selected Items:</h5>
                  <ul className="list-disc list-inside">
                    {issuance.selectedItems
                      .slice()
                      .sort((a, b) => {
                        const itemA = a.split("|")[1];
                        const itemB = b.split("|")[1];
                        return itemA.localeCompare(itemB);
                      })
                      .map((item, index) => {
                        const [, itemName] = item.split("|");
                        return (
                          <li key={index} className="text-sm">
                            {itemName}
                          </li>
                        );
                      })}
                  </ul>
                </div>
              )}
            </CardContent>
          )}
        </Card>
      ))}

      <Button
        onClick={addIssuance}
        variant="outline"
        className="w-full mb-6 bg-blue-500 text-white"
      >
        <Plus className="h-4 w-4 mr-2 " />
        Add Another Issuance
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Input
          label="Date:"
          type="date"
          name="issuedByDate"
          value={formData.issuedByDate}
          onChange={handleFormChange}
        />
        <Input
          label="Signature:"
          name="issuedBySignature"
          value={formData.issuedBySignature}
          onChange={handleFormChange}
        />
        <Input
          label="Issued By:"
          name="issuedBy"
          value={formData.issuedBy}
          onChange={handleFormChange}
        />
      </div>

      <Button onClick={handleSubmit} className="w-full">
        Submit Form
      </Button>
    </div>
  );
};

// Helper component for labeled inputs (kept as provided, but note comments)
// Consider using a proper UI library's Input component if available (e.g., Shadcn UI's)
const Input = ({ label, ...props }) => (
  <div>
    {label && <label className="block text-sm font-medium mb-1">{label}</label>}
    <input
      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
      {...props}
    />
  </div>
);

export default ClothingCardForm;
