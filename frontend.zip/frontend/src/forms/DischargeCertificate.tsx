import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { List, Printer, Search } from "lucide-react";
import { toast } from "sonner";
import DischargeCertificatePdf from "@/formPdfs/DischargeCertificatePdf";
import Server from "@/server/Server";

const DischargeCertificate = () => {
  const [memberInfo, setMemberInfo] = useState({
    no: "",
    rank: "",
    name: "",
    station: "",
  });

  const [dischargeInfo, setDischargeInfo] = useState({
    reasons: "",
    date: "",
  });

  const [repaymentInfo, setRepaymentInfo] = useState({
    icDate: "",
    iv: "",
    ivDate: "",
    acvConfirmed: false,
    total: "",
    noOutstanding: false,
  });

  const [kitDeficiencies, setKitDeficiencies] = useState({
    articlesListed: "",
    date: "",
    sum: "",
    noDeficiencies: false,
  });

  const [summary, setSummary] = useState({
    kitRepayment: "",
    deficiencies: "",
  });

  const [showPreview, setShowPreview] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Create form data object
    const formData = {
      memberInfo,
      dischargeInfo,
      repaymentInfo,
      kitDeficiencies,
      summary,
    };

    // Submit to server
    Server.addDischargeCertificate(formData)
      .then(() => {
        toast.success("Discharge certificate successfully submitted");
        setShowPreview(true);
      })
      .catch((error) => {
        toast.error(error.message || "Failed to submit discharge certificate");
      });
  };

  const handlePrint = () => {
    window.print();
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [requisitionVouchers, setRequisitonVouchers] = useState([]);

  const filteredVouchers = requisitionVouchers.filter((voucher) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      String(voucher.voucher_no).toLowerCase().includes(searchLower) ||
      String(voucher.station).toLowerCase().includes(searchLower)
    );
  });
  const staticFormData = {
    memberInfo: {
      no: "F-12345",
      rank: "Sergeant",
      name: "John Banda",
      station: "ZRP Harare Central",
    },
    dischargeInfo: {
      reasons: "Completion of service",
      date: "2025-06-30",
    },
    repaymentInfo: {
      icDate: "IC-2025-001",
      iv: "IV-2025-001",
      ivDate: "2025-06-15",
      acvConfirmed: true,
      total: "$450.00",
      noOutstanding: false,
    },
    kitDeficiencies: {
      articlesListed: "2 x Boots, 1 x Belt",
      date: "2025-06-20",
      sum: "120.00",
      noDeficiencies: false,
    },
    summary: {
      kitRepayment: "$450.00",
      deficiencies: "$120.00",
    },
  };

  // Sample data for recent reports table
  const recentReports = [
    {
      voucher_no: "DC-2025-001",
      station: "ZRP Harare Central",
      issue_date: "2025-05-10",
      status: "Completed",
    },
    {
      voucher_no: "DC-2025-002",
      station: "ZRP Bulawayo",
      issue_date: "2025-05-15",
      status: "Completed",
    },
    {
      voucher_no: "DC-2025-003",
      station: "ZRP Mutare",
      issue_date: "2025-05-20",
      status: "Pending",
    },
  ];

  useEffect(() => {
    setRequisitonVouchers(recentReports);
  }, []);

  const formData = {
    memberInfo,
    dischargeInfo,
    repaymentInfo,
    kitDeficiencies,
    summary
  };

  return (
    <>
      <div className="flex">
        {!showPreview ? (
          <Card className="w-full max-w-6xl mx-auto bg-white shadow-sm mr-2">
            <CardHeader className="pb-0">
              <div className="text-center">
                <h1 className="text-2xl font-bold text-blue-900">Z.R.P.</h1>
                <p className="text-sm text-gray-600">CERTIFICATE</p>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <form onSubmit={handleSubmit}>
                {/* Member Information */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <Label>NO.</Label>
                    <Input
                      value={memberInfo.no}
                      onChange={(e) =>
                        setMemberInfo({ ...memberInfo, no: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label>RANK</Label>
                    <Input
                      value={memberInfo.rank}
                      onChange={(e) =>
                        setMemberInfo({ ...memberInfo, rank: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label>NAME</Label>
                    <Input
                      value={memberInfo.name}
                      onChange={(e) =>
                        setMemberInfo({ ...memberInfo, name: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label>STATION</Label>
                    <Input
                      value={memberInfo.station}
                      onChange={(e) =>
                        setMemberInfo({
                          ...memberInfo,
                          station: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <Label>REASONS FOR DISCHARGE</Label>
                  <Input
                    value={dischargeInfo.reasons}
                    onChange={(e) =>
                      setDischargeInfo({
                        ...dischargeInfo,
                        reasons: e.target.value,
                      })
                    }
                  />
                </div>

                <div className="mb-4">
                  <Label>DATE OF DISCHARGE</Label>
                  <Input
                    type="date"
                    value={dischargeInfo.date}
                    onChange={(e) =>
                      setDischargeInfo({
                        ...dischargeInfo,
                        date: e.target.value,
                      })
                    }
                  />
                </div>

                {/* 1. REPAYMENT */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4">1. REPAYMENT</h3>
                  <p className="mb-4">
                    Certified that recovery is necessary in respect of articles
                    issued on repayment to the above member and which credit
                    voucher had been passed to Staff Officer (Finance) as
                    detailed below.
                  </p>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label>I.C</Label>
                      <Input
                        value={repaymentInfo.icDate}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            icDate: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>DATE</Label>
                      <Input
                        type="date"
                        value={repaymentInfo.ivDate}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            ivDate: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label>I.V</Label>
                      <Input
                        value={repaymentInfo.iv}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            iv: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>DATE</Label>
                      <Input
                        type="date"
                        value={repaymentInfo.ivDate}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            ivDate: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={repaymentInfo.acvConfirmed}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            acvConfirmed: e.target.checked,
                          })
                        }
                      />
                      <Label>
                        a) A.C.V. passed to Staff Officer (Finance) that
                        required confirmation that deduction has been effected.
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Label>b) I.V</Label>
                      <Input
                        className="inline w-32"
                        value={repaymentInfo.iv}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            iv: e.target.value,
                          })
                        }
                      />
                      <Label>DATE</Label>
                      <Input
                        type="date"
                        className="inline w-32"
                        value={repaymentInfo.ivDate}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            ivDate: e.target.value,
                          })
                        }
                      />
                      <Label>TOTAL</Label>
                      <Input
                        className="inline w-32"
                        value={repaymentInfo.total}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            total: e.target.value,
                          })
                        }
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={repaymentInfo.noOutstanding}
                        onChange={(e) =>
                          setRepaymentInfo({
                            ...repaymentInfo,
                            noOutstanding: e.target.checked,
                          })
                        }
                      />
                      <Label>
                        Certified that there are no outstanding issue on
                        repayment to above member for which credit voucher has
                        not been passed to Staff Officer (Finance).
                      </Label>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="font-semibold">I/C CLOTHING SECTION</p>
                  </div>
                </div>

                {/* 2. KIT DEFICIENCES */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4">2. KIT DEFICIENCES</h3>
                  <p className="mb-4">
                    I have been advised by Officer In charge Ordnance that the
                    above member has handed in kit and equipment in terms of
                    appendices 19, 20, 21 Standing Orders and that:
                  </p>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={!kitDeficiencies.noDeficiencies}
                        onChange={(e) =>
                          setKitDeficiencies({
                            ...kitDeficiencies,
                            noDeficiencies: !e.target.checked,
                          })
                        }
                      />
                      <Label>
                        a). THE ARTICLES LISTED{" "}
                        <Input
                          className="inline w-32"
                          value={kitDeficiencies.articlesListed}
                          onChange={(e) =>
                            setKitDeficiencies({
                              ...kitDeficiencies,
                              articlesListed: e.target.value,
                            })
                          }
                        />{" "}
                        Date{" "}
                        <Input
                          type="date"
                          className="inline w-32"
                          value={kitDeficiencies.date}
                          onChange={(e) =>
                            setKitDeficiencies({
                              ...kitDeficiencies,
                              date: e.target.value,
                            })
                          }
                        />
                        For the sum of $
                        <Input
                          className="inline w-32"
                          value={kitDeficiencies.sum}
                          onChange={(e) =>
                            setKitDeficiencies({
                              ...kitDeficiencies,
                              sum: e.target.value,
                            })
                          }
                        />
                        are deficiencies or unserviceable.
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={kitDeficiencies.noDeficiencies}
                        onChange={(e) =>
                          setKitDeficiencies({
                            ...kitDeficiencies,
                            noDeficiencies: e.target.checked,
                          })
                        }
                      />
                      <Label>
                        b). There are no deficiencies. No recovery action
                        therefore required.
                      </Label>
                    </div>
                  </div>

                  <div className="text-right">
                    <Label>DATE</Label>
                    <Input
                      type="date"
                      className="inline w-48"
                      value={kitDeficiencies.date}
                      onChange={(e) =>
                        setKitDeficiencies({
                          ...kitDeficiencies,
                          date: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>

                {/* SUMMARY */}
                <div className="mb-6 border p-4 rounded">
                  <h3 className="font-bold mb-4 text-center">SUMMARY</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>KIT ON REPAYMENTS STOPPAGE VIDE PARA 1</Label>
                      <Input
                        value={summary.kitRepayment}
                        onChange={(e) =>
                          setSummary({
                            ...summary,
                            kitRepayment: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>DEFICIENCES VIDE PARA 2</Label>
                      <Input
                        value={summary.deficiencies}
                        onChange={(e) =>
                          setSummary({
                            ...summary,
                            deficiencies: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-between mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => toast.info("Form reset")}
                  >
                    Reset Form
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowPreview(true)}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print Preview
                    </Button>
                    <Button type="submit">Submit Certificate</Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <DischargeCertificatePdf
            formData={formData}
            // formData={staticFormData}
            onBack={() => setShowPreview(false)}
            onPrint={handlePrint}
          />
        )}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              Recent Reports
            </h3>

            <div className="relative flex items-center">
              <input
                aria-label="Search"
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                id="search"
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by report no, station..."
                type="text"
                value={searchTerm}
              />
              <button className="absolute right-3 text-gray-500 hover:text-blue-600">
                <Search />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Certificate No.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Supplier
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date Received
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredVouchers.length > 0 ? (
                    filteredVouchers.map((voucher, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {voucher.voucher_no}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {voucher.issue_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completed
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        className="px-6 py-4 text-sm text-gray-500 text-center"
                        colSpan="4"
                      >
                        {requisitionVouchers.length === 0
                          ? "No recent reports found"
                          : "No matching reports found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <a
              className="inline-flex items-center px-4 py-2 border border-blue-500 text-blue-500 rounded-md hover:bg-blue-50 transition-colors gap-2"
              href="#"
            >
              <List /> View All Reports
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default DischargeCertificate;
