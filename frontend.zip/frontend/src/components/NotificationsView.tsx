// components/Notifications.tsx
import React, { useEffect, useState } from "react";
import PendingEndorsementsSection from "@/officeforms/officer-in-charge/PendingEndorsementsSection";
import LowStockAlerts from "@/officeforms/officer-in-charge/LowStockAlerts";
import PendingForm109Section from "@/officeforms/receivingbay/PendingForm109Section";
import PendingForm163Requests from "@/officeforms/bulkstores/Pending163Request";
import Form227Transactions from "@/officeforms/cadex/DamagedStock227";
import PendingForm109s from "@/officeforms/cadex/PendingForm109s";
import PendingForm163s from "@/officeforms/cadex/PendingForm163";
import Server from "@/server/Server";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

interface NotificationsProps {
  office: string | null;
}

interface LowStockItem {
  name: string;
  count: number;
}

interface PendingForm109 {
  id: string;
  supplier: string;
  date: string;
  items: number;
}

interface PendingForm163 {
  id: string;
  requester: string;
  date: string;
  items: number;
}

interface DamagedStockItem {
  id: string;
  itemName: string;
  quantity: number;
  reason: string;
}

interface NotificationData {
  pendingEndorsements?: number;
  lowStockItems?: LowStockItem[];
  pendingForm109s?: PendingForm109[];
  pendingForm163s?: PendingForm163[];
  damagedStockItems?: DamagedStockItem[];
}

const Notifications: React.FC<NotificationsProps> = ({ office }) => {
  const [data, setData] = useState<NotificationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate()

  useEffect(() => {
    const fetchNotificationData = async () => {
      if (!office) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);
        // const response = await Server.notificationsStats(office);
        // setData(response.data);
      } catch (err) {
        console.error("Failed to fetch notification data:", err);
        setError("Failed to load notifications");
        toast.error("Could not load notification data");
      } finally {
        setLoading(false);
      }
    };

    fetchNotificationData();
  }, [office]);

  if (loading) {
    return (
      <div className="mb-6 space-y-4 grid grid-cols-1 md:grid-cols-2 gap-5">
        {[...Array(2)].map((_, i) => (
          <Skeleton key={i} className="h-32 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-lg">
        {error} - Please try again later
      </div>
    );
  }

  if (!office) {
    return (
      <p className="text-gray-500 italic">
        Select an office to view notifications
      </p>
    );
  }

  switch (office) {
    case "Officer in Charge":
      return (
        <div className="mb-6 grid grid-cols-1 gap-6">
          <PendingEndorsementsSection
            count={data?.pendingEndorsements || 0}
            onClick={() => navigate("/all-forms-109")}
          />
          <LowStockAlerts items={data?.lowStockItems || []} />
        </div>
      );

    case "Receiving Bay":
      return (
        <div className="mb-6 space-y-4">
          <PendingForm109Section forms={data?.pendingForm109s || []} />
        </div>
      );

    case "Bulk Officer":
      return (
        <div className="mb-6 space-y-4">
          <PendingForm163Requests requests={data?.pendingForm163s || []} />
        </div>
      );

    case "Cadex":
      return (
        <div className="mb-6 space-y-4">
          <Form227Transactions items={data?.damagedStockItems || []} />
          <PendingForm109s forms={data?.pendingForm109s || []} />
          <PendingForm163s requests={data?.pendingForm163s || []} />
        </div>
      );

    default:
      return (
        <p className="text-gray-500 italic">No notifications available.</p>
      );
  }
};

export default Notifications;
